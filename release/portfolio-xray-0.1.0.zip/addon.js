import { jsxs as o, jsx as t, Fragment as Z } from "react/jsx-runtime";
import { useState as $, useRef as Ae, useCallback as F, useEffect as L, useMemo as Se } from "react";
const Ce = [
  { id: "overview", label: "Overview", icon: "◈" },
  { id: "holdings", label: "Holdings", icon: "▤" },
  { id: "xray", label: "X-Ray", icon: "⌁" },
  { id: "etf-data", label: "ETF Data", icon: "◫" }
];
function De({ page: e, onPageChange: n, accounts: i, children: a }) {
  return /* @__PURE__ */ o("div", { className: "app-shell", children: [
    /* @__PURE__ */ o("aside", { className: "sidebar", children: [
      /* @__PURE__ */ o("div", { className: "brand", children: [
        /* @__PURE__ */ t("div", { className: "brand-mark", children: "X" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ t("strong", { children: "Portfolio X-Ray" }),
          /* @__PURE__ */ t("span", { children: "Wealthfolio addon" })
        ] })
      ] }),
      /* @__PURE__ */ t("nav", { className: "main-nav", "aria-label": "Portfolio X-Ray pages", children: Ce.map((s) => /* @__PURE__ */ o("button", { className: `nav-item ${e === s.id ? "nav-active" : ""}`, onClick: () => n(s.id), children: [
        /* @__PURE__ */ t("span", { className: "nav-icon", children: s.icon }),
        s.label
      ] }, s.id)) }),
      /* @__PURE__ */ o("div", { className: "sidebar-bottom", children: [
        /* @__PURE__ */ o("button", { className: `nav-item ${e === "settings" ? "nav-active" : ""}`, onClick: () => n("settings"), children: [
          /* @__PURE__ */ t("span", { className: "nav-icon", children: "⚙" }),
          "Settings"
        ] }),
        /* @__PURE__ */ o("div", { className: "account-summary", children: [
          /* @__PURE__ */ t("span", { className: "eyebrow", children: "Included accounts" }),
          /* @__PURE__ */ t("strong", { children: i.length }),
          /* @__PURE__ */ t("span", { children: i.length === 1 ? "account selected" : "accounts selected" })
        ] }),
        /* @__PURE__ */ o("div", { className: "local-first", children: [
          /* @__PURE__ */ t("span", { className: "pulse-dot" }),
          "Local-first data"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ t("main", { className: "main-content", children: a })
  ] });
}
function U(e) {
  return e == null || !Number.isFinite(e) ? "Incomplete" : new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 2 }).format(e);
}
function Ee(e, n) {
  if (e == null || !Number.isFinite(e)) return "—";
  try {
    return new Intl.NumberFormat("en-AU", { style: "currency", currency: n, maximumFractionDigits: 2 }).format(e);
  } catch {
    return `${n} ${e.toFixed(2)}`;
  }
}
function K(e) {
  return e == null || !Number.isFinite(e) ? "—" : `${(e * 100).toFixed(1)}%`;
}
function Ie(e) {
  return new Intl.NumberFormat("en-AU", { maximumFractionDigits: 6 }).format(e);
}
function R({ value: e, tone: n }) {
  return /* @__PURE__ */ t("span", { className: `status-badge status-${n ?? e.toLowerCase().replace(/\s+/g, "-")}`, children: e });
}
function H({ label: e, value: n, detail: i, icon: a, tone: s }) {
  return /* @__PURE__ */ o("div", { className: `metric-card ${s ? `metric-${s}` : ""}`, children: [
    /* @__PURE__ */ o("div", { className: "metric-card-top", children: [
      /* @__PURE__ */ t("span", { className: "metric-icon", children: a }),
      /* @__PURE__ */ t("span", { className: "eyebrow", children: e })
    ] }),
    /* @__PURE__ */ t("div", { className: "metric-value", children: n }),
    i && /* @__PURE__ */ t("div", { className: "metric-detail", children: i })
  ] });
}
function Te({ warnings: e }) {
  return e.length ? /* @__PURE__ */ t("div", { className: "warning-stack", children: e.map((n) => /* @__PURE__ */ o("div", { className: `warning-card warning-${n.severity}`, children: [
    /* @__PURE__ */ t("div", { className: "warning-mark", children: n.severity === "critical" ? "!" : "i" }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ t("strong", { children: n.title }),
      /* @__PURE__ */ t("p", { children: n.detail })
    ] })
  ] }, n.id)) }) : null;
}
const _ = ["#65d6a7", "#7ca7ff", "#f8c86b", "#e18cff", "#ff927d", "#62d3e8", "#a9b7c9"];
function re({ title: e, subtitle: n, rows: i, valueLabel: a = "Value" }) {
  const s = Math.max(...i.map((r) => r.value), 1);
  return /* @__PURE__ */ o("div", { className: "panel chart-panel", children: [
    /* @__PURE__ */ o("div", { className: "panel-heading", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("h2", { children: e }),
        /* @__PURE__ */ t("p", { children: n })
      ] }),
      /* @__PURE__ */ t("span", { className: "chart-note", children: "Top 10" })
    ] }),
    i.length === 0 ? /* @__PURE__ */ t("div", { className: "empty-chart", children: "No valued holdings yet." }) : /* @__PURE__ */ t("div", { className: "chart-list", children: i.map((r, c) => /* @__PURE__ */ o("div", { className: "chart-row", children: [
      /* @__PURE__ */ o("div", { className: "chart-row-head", children: [
        /* @__PURE__ */ t("span", { className: "legend-dot", style: { background: r.color ?? _[c % _.length] } }),
        " ",
        /* @__PURE__ */ t("span", { className: "chart-label", children: r.label }),
        /* @__PURE__ */ t("span", { className: "chart-value", children: r.weight === null ? "—" : `${(r.weight * 100).toFixed(1)}%` })
      ] }),
      /* @__PURE__ */ t("div", { className: "chart-track", children: /* @__PURE__ */ t("span", { style: { width: `${Math.max(2, r.value / s * 100)}%`, background: r.color ?? _[c % _.length] } }) }),
      /* @__PURE__ */ o("div", { className: "chart-meta", children: [
        /* @__PURE__ */ t("span", { children: a }),
        /* @__PURE__ */ t("strong", { children: U(r.value) }),
        r.meta && /* @__PURE__ */ t("span", { children: r.meta })
      ] })
    ] }, r.key)) })
  ] });
}
function X({ eyebrow: e, title: n, detail: i, action: a }) {
  return /* @__PURE__ */ o("div", { className: "section-header", children: [
    /* @__PURE__ */ o("div", { children: [
      e && /* @__PURE__ */ t("div", { className: "eyebrow", children: e }),
      /* @__PURE__ */ t("h1", { children: n }),
      i && /* @__PURE__ */ t("p", { children: i })
    ] }),
    a
  ] });
}
function j({ icon: e, title: n, detail: i, action: a }) {
  return /* @__PURE__ */ o("div", { className: "empty-state", children: [
    /* @__PURE__ */ t("div", { className: "empty-icon", children: e }),
    /* @__PURE__ */ t("h2", { children: n }),
    /* @__PURE__ */ t("p", { children: i }),
    a
  ] });
}
function I({ children: e, onClick: n, variant: i = "secondary", disabled: a = !1, type: s = "button" }) {
  return /* @__PURE__ */ t("button", { className: `button button-${i}`, onClick: n, disabled: a, type: s, children: e });
}
function ae({ children: e }) {
  return /* @__PURE__ */ t("div", { className: "table-shell", children: /* @__PURE__ */ t("table", { children: e }) });
}
function $e({ checked: e, onChange: n, label: i }) {
  return /* @__PURE__ */ o("label", { className: "toggle-row", children: [
    i && /* @__PURE__ */ t("span", { children: i }),
    /* @__PURE__ */ t("button", { type: "button", className: `toggle ${e ? "toggle-on" : ""}`, "aria-pressed": e, onClick: () => n(!e), children: /* @__PURE__ */ t("span", {}) })
  ] });
}
function Ue(e, n = 10) {
  if (e.length <= n) return e.map((s) => ({ key: s.key, label: s.label, value: s.valueAud, weight: s.weight, meta: s.type }));
  const i = e.slice(0, n), a = e.slice(n);
  return [
    ...i.map((s) => ({ key: s.key, label: s.label, value: s.valueAud, weight: s.weight, meta: s.type })),
    { key: "other", label: "Other", value: a.reduce((s, r) => s + r.valueAud, 0), weight: a.every((s) => s.weight !== null) ? a.reduce((s, r) => s + (r.weight ?? 0), 0) : null, meta: "View-only aggregation" }
  ];
}
function Fe(e, n = 10) {
  if (e.length <= n) return e.map((s) => ({ key: s.key, label: s.label, value: s.totalAud, weight: s.portfolioWeight, meta: s.type }));
  const i = e.slice(0, n), a = e.slice(n);
  return [
    ...i.map((s) => ({ key: s.key, label: s.label, value: s.totalAud, weight: s.portfolioWeight, meta: s.type })),
    { key: "other", label: "Other", value: a.reduce((s, r) => s + r.totalAud, 0), weight: a.every((s) => s.portfolioWeight !== null) ? a.reduce((s, r) => s + (r.portfolioWeight ?? 0), 0) : null, meta: "View-only aggregation" }
  ];
}
function z(e) {
  return (e ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim().replace(/\s+/g, "_");
}
function de(e) {
  if (e.instrumentKey?.trim()) return `instrument:${e.instrumentKey.trim()}`;
  const n = z(e.mic), i = z(e.symbol);
  return n && i ? `${n}:${i}` : i && e.currency ? `provider:${z(e.currency)}:${i}` : null;
}
function ie(e) {
  const n = z(e.isin);
  if (n) return { key: `isin:${n}`, confidence: "high" };
  const i = z(e.mic), a = z(e.symbol);
  if (i && a) return { key: `mic:${i}:${a}`, confidence: "high" };
  const s = z(e.country), r = z(e.currency);
  if (a && s && r)
    return { key: `ticker:${a}:${s}:${r}`, confidence: "medium" };
  const c = z(e.name);
  return c ? { key: `name:${c}`, confidence: "low" } : { key: null, confidence: "unmapped" };
}
function ze(e, n) {
  return e ? n[e] ?? e : null;
}
const Ke = 3;
function ee(e, n) {
  return n ? e ? e === n ? e : "Mixed/Conflicting" : n : e;
}
function Pe(e) {
  return e === "fixed-income" ? "fixed-income" : e === "derivative" ? "derivative" : e === "cash" ? "cash" : e === "etf" ? "etf" : e === "stock" ? "stock" : "other";
}
function ue(e) {
  const n = /* @__PURE__ */ new Map(), i = e.snapshots, a = e.aliases ?? {}, s = e.holdings.reduce((l, h) => l + (h.audValue ?? 0), 0);
  let r = 0, c = 0;
  function u(l) {
    const h = n.get(l.key);
    if (h) {
      l.direct ? h.directAud += l.amountAud : h.viaEtfsAud += l.amountAud, h.totalAud += l.amountAud, h.sources.push(l.source), h.sector = ee(h.sector, l.sector), h.country = ee(h.country, l.country), h.status = ee(h.status, l.status);
      return;
    }
    n.set(l.key, {
      key: l.key,
      label: l.label,
      type: l.type,
      directAud: l.direct ? l.amountAud : 0,
      viaEtfsAud: l.direct ? 0 : l.amountAud,
      totalAud: l.amountAud,
      portfolioWeight: null,
      sector: l.sector,
      country: l.country,
      status: l.status,
      sources: [l.source]
    });
  }
  function f(l, h, D, m, p) {
    const v = {
      kind: p === "ETF-specific residual" ? "residual" : "opaque",
      holdingId: l.id,
      accountId: l.accountId,
      accountName: l.accountName,
      etfKey: l.etfKey ?? D,
      etfSymbol: l.ticker,
      amountAud: h,
      reason: p
    };
    u({ key: D, label: m, type: "etf", amountAud: h, source: v, status: p });
  }
  function x(l, h, D) {
    const m = de({ symbol: l, mic: h, currency: D });
    if (m && i.has(m)) return m;
    const p = l?.trim().toUpperCase();
    return p ? [...i.keys()].find((v) => v.toUpperCase().endsWith(`:${p}`)) ?? null : null;
  }
  function N(l, h, D, m, p) {
    const v = i.get(h);
    if (!v)
      return f(l, D, `opaque-etf:${h}`, `${l.ticker} · Opaque ETF`, "Missing constituent snapshot"), { coveredValueAud: 0 };
    let d = 0;
    for (const y of v.holdings) {
      const w = D * y.weight;
      if (w === 0) continue;
      const T = y.underlyingType === "etf" ? x(y.symbol, y.mic, y.currency) : null;
      if (T) {
        if (m.includes(T)) {
          f(l, w, `opaque-etf:${T}`, `${y.symbol ?? y.name} · Opaque ETF`, "Cycle detected");
          continue;
        }
        if (p >= Ke) {
          f(l, w, `opaque-etf:${T}`, `${y.symbol ?? y.name} · Opaque ETF`, "Maximum recursion depth reached");
          continue;
        }
        d += N(l, T, w, [...m, T], p + 1).coveredValueAud;
        continue;
      }
      const P = ze(ie(y).key, a) ?? `unclassified:${y.name.trim().toUpperCase()}`, g = Pe(y.underlyingType ?? "other"), C = {
        kind: "etf",
        holdingId: l.id,
        accountId: l.accountId,
        accountName: l.accountName,
        etfKey: h,
        etfSymbol: l.ticker,
        amountAud: w,
        path: [...m, y.symbol ?? y.name]
      };
      u({
        key: P,
        label: y.name,
        type: g,
        amountAud: w,
        source: C,
        sector: y.sector,
        country: y.country
      }), d += w;
    }
    const S = Math.max(0, 1 - v.weightSum);
    return S > 1e-7 && f(
      l,
      D * S,
      `residual-etf:${h}`,
      `${l.ticker} · ETF residual`,
      "ETF-specific residual"
    ), { coveredValueAud: d };
  }
  for (const l of e.holdings) {
    if (l.audValue === null) continue;
    if (l.type === "etf") {
      if (c += l.audValue, !l.etfKey || !i.has(l.etfKey)) {
        f(
          l,
          l.audValue,
          `opaque-etf:${l.etfKey ?? l.id}`,
          `${l.ticker} · Opaque ETF`,
          "Missing constituent snapshot"
        );
        continue;
      }
      r += N(l, l.etfKey, l.audValue, [l.etfKey], 0).coveredValueAud;
      continue;
    }
    const h = l.identityKey ?? `unclassified:${l.id}`, D = {
      kind: "direct",
      holdingId: l.id,
      accountId: l.accountId,
      accountName: l.accountName,
      amountAud: l.audValue
    };
    u({
      key: h,
      label: l.name,
      type: l.type,
      amountAud: l.audValue,
      direct: !0,
      source: D,
      status: l.status === "valued" ? void 0 : l.status
    }), l.type !== "cash" && (c += l.audValue, r += l.audValue);
  }
  const b = e.totalAud ?? s, k = [...n.values()].map((l) => ({
    ...l,
    portfolioWeight: b > 0 && !e.totalAud ? null : b > 0 ? l.totalAud / b : null
  })).sort((l, h) => h.totalAud - l.totalAud), A = k.reduce((l, h) => l + h.totalAud, 0);
  return {
    rows: k,
    totalAud: b,
    coveredValueAud: r,
    eligibleValueAud: c,
    coverage: c > 0 ? r / c : null,
    valueConservationDelta: A - s,
    incomplete: e.totalAud === null || e.holdings.some((l) => l.status === "unvalued" || l.status === "unsupported-currency" || l.status === "unsupported-position")
  };
}
const Re = 0.96, Ve = 1.005;
function Me(e) {
  const n = [];
  let i = [], a = "", s = !1;
  for (let r = 0; r < e.length; r += 1) {
    const c = e[r], u = e[r + 1];
    c === '"' ? s && u === '"' ? (a += '"', r += 1) : s = !s : c === "," && !s ? (i.push(a.trim()), a = "") : (c === `
` || c === "\r") && !s ? (c === "\r" && u === `
` && (r += 1), i.push(a.trim()), i.some((f) => f.length > 0) && n.push(i), i = [], a = "") : a += c;
  }
  return i.push(a.trim()), i.some((r) => r.length > 0) && n.push(i), n;
}
function Oe(e) {
  const n = e.trim();
  if (!n) return { weight: null, unit: "mixed" };
  const i = Number(n.replace(/%$/, ""));
  return !Number.isFinite(i) || i < 0 ? { weight: null, unit: "mixed" } : n.endsWith("%") ? { weight: i / 100, unit: "percentage" } : i <= 1 ? { weight: i, unit: "fraction" } : { weight: i / 100, unit: "bare-percentage" };
}
function G(e) {
  const n = e.holdings.reduce((a, s) => a + s.weight, 0), i = e.holdings.some(
    (a) => !Number.isFinite(a.weight) || a.weight < 0
  );
  if (!e.holdings.length || i)
    return {
      accepted: !1,
      status: "rejected",
      message: "Snapshot must contain at least one constituent with non-negative weights."
    };
  if (n < Re || n > Ve)
    return {
      accepted: !1,
      status: "rejected",
      message: `Weight sum ${(n * 100).toFixed(2)}% is outside the accepted 98%–100.5% range.`
    };
  if (n > 1) {
    const a = e.holdings.map((s) => ({
      ...s,
      weight: s.weight / n
    }));
    return {
      accepted: !0,
      status: "normalized",
      message: `Weight sum ${(n * 100).toFixed(2)}% was proportionally normalized to 100%.`,
      snapshot: { ...e, holdings: a, weightSum: 1, normalized: !0 }
    };
  }
  return {
    accepted: !0,
    status: n < 1 ? "residual" : "accepted",
    message: n < 1 ? `Accepted with ${(1 - n) * 100 < 1 ? ((1 - n) * 100).toFixed(2) : ((1 - n) * 100).toFixed(1)}% residual.` : "Snapshot weights sum to 100%.",
    snapshot: { ...e, weightSum: n, normalized: e.normalized ?? !1 }
  };
}
function pe(e, n) {
  const i = Me(e), s = (i.shift() ?? []).map((p) => p.toLowerCase().replace(/\s+/g, "")), r = (p) => s.indexOf(p), c = r("symbol"), u = r("name"), f = r("weight"), x = [];
  c < 0 && u < 0 && x.push("symbol or name"), f < 0 && x.push("weight");
  const N = [], b = [], k = /* @__PURE__ */ new Set();
  for (const [p, v] of i.entries()) {
    const d = (T) => {
      const P = r(T);
      return P >= 0 ? v[P]?.trim() : "";
    }, S = d("symbol") || void 0, y = d("name") || S || "", w = Oe(d("weight"));
    w.unit !== "mixed" && k.add(w.unit), y || b.push(`Row ${p + 2}: symbol or name is required.`), w.weight === null && b.push(`Row ${p + 2}: weight is invalid.`), !(!y || w.weight === null) && N.push({
      symbol: S,
      name: y,
      weight: w.weight,
      isin: d("isin") || void 0,
      mic: d("mic") || void 0,
      country: d("country") || void 0,
      currency: d("currency") || void 0,
      sector: d("sector") || void 0,
      assetClass: d("assetclass") || void 0
    });
  }
  const A = /* @__PURE__ */ new Map();
  for (const p of N) {
    const v = ie(p).key;
    v && A.set(v, (A.get(v) ?? 0) + 1);
  }
  const l = [...A.entries()].filter(([, p]) => p > 1).map(([p]) => p);
  l.length && b.push("Duplicate identities will be kept visible for review.");
  const h = N.reduce((p, v) => p + v.weight, 0), D = {
    schemaVersion: 1,
    ...n,
    holdings: N,
    weightSum: h,
    normalized: !1,
    sourceMode: "manual"
  }, m = G(D);
  return {
    rows: N,
    detectedUnit: k.size === 1 ? [...k][0] : (k.size === 0, "mixed"),
    weightSum: h,
    missingFields: x,
    duplicateIdentities: l,
    issues: b,
    validation: m
  };
}
function We(e) {
  const n = ["symbol", "name", "weight", "isin", "mic", "country", "currency", "sector", "assetClass"], i = (a) => {
    const s = a === void 0 ? "" : String(a);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [
    n.join(","),
    ...e.holdings.map((a) => [
      a.symbol,
      a.name,
      a.weight,
      a.isin,
      a.mic,
      a.country,
      a.currency,
      a.sector,
      a.assetClass
    ].map(i).join(","))
  ].join(`
`);
}
function qe(e, n = Date.now()) {
  if (!e) return "Missing";
  const i = Date.parse(e.fetchedAt);
  if (!Number.isFinite(i)) return "Invalid";
  const a = Math.max(0, n - i);
  return a <= 1440 * 60 * 1e3 ? "Fresh" : a <= 10080 * 60 * 1e3 ? "Stale" : a <= 720 * 60 * 60 * 1e3 ? "Warning" : "Critical";
}
const Le = 300 * 1e3;
function he(e) {
  return e?.trim().toUpperCase() ?? "";
}
function je(e, n, i) {
  if (e == null || !Number.isFinite(e))
    return { audValue: null, supported: !1, reason: "No usable market value" };
  const a = he(n);
  return a === "AUD" ? { audValue: e, supported: !0 } : a === "USD" && i && Number.isFinite(i.rate) && i.rate > 0 ? { audValue: e * i.rate, supported: !0 } : a === "USD" ? { audValue: null, supported: !1, reason: "Missing valid USD/AUD quote" } : {
    audValue: null,
    supported: !1,
    reason: `Unsupported currency: ${a || "unknown"}`
  };
}
function Xe(e, n = Date.now()) {
  const i = Date.parse(e);
  if (!Number.isFinite(i)) return null;
  const a = Math.max(0, n - i);
  return a < 600 * 1e3 ? "Fresh" : a <= 1800 * 1e3 ? "Stale" : "Warning";
}
function He(e, n = Date.now()) {
  if (!e) return "Not available";
  const i = Date.parse(e);
  if (!Number.isFinite(i)) return "Unknown time";
  const a = Math.max(0, Math.floor((n - i) / 1e3));
  if (a < 60) return "just now";
  const s = Math.floor(a / 60);
  if (s < 60) return `${s} min ago`;
  const r = Math.floor(s / 60);
  return r < 24 ? `${r} hr ago` : `${Math.floor(r / 24)} d ago`;
}
function _e(e) {
  return e != null && Number.isFinite(e) ? e : null;
}
function Be(e, n, i) {
  if (i) return i;
  if (e.holdingType === "cash") return "cash";
  const a = n?.instrumentType?.toUpperCase() ?? "";
  return a.includes("ETF") || a.includes("MUTUAL") ? "etf" : a.includes("BOND") || a.includes("FIXED") ? "fixed-income" : a.includes("OPTION") || a.includes("DERIVATIVE") ? "derivative" : a.includes("EQUITY") || a.includes("STOCK") ? "stock" : ((n?.kind?.toUpperCase() ?? "") === "INVESTMENT" && n?.symbol, "unknown");
}
function Je(e, n, i, a, s) {
  const r = he(e.localCurrency), c = _e(e.marketValue?.local), u = e.quantity, f = Be(e, i, s), x = je(c, r, a), N = i?.symbol || e.instrument?.symbol || (f === "cash" ? r : "Unmapped"), b = i?.name || e.instrument?.name || (f === "cash" ? `${r} cash` : "Unmapped instrument"), k = f === "cash" ? { key: `cash:${r}` } : ie({
    isin: i?.isin,
    mic: i?.mic,
    symbol: i?.symbol || e.instrument?.symbol,
    currency: r,
    name: b
  }), A = f === "etf" ? de({
    instrumentKey: i?.instrumentKey,
    mic: i?.mic,
    symbol: N,
    currency: r
  }) : null;
  let l = "valued", h;
  return u < 0 || f === "cash" && c !== null && c < 0 ? (l = "unsupported-position", h = "Negative quantity or cash is not supported in v1") : c === null ? (l = "unvalued", h = "Wealthfolio did not provide a usable market value") : x.supported ? f === "unknown" && (l = "unknown-instrument", h = "Instrument type is unresolved; add a local type override") : (l = x.reason?.startsWith("Unsupported currency") ? "unsupported-currency" : "unvalued", h = x.reason), {
    id: e.id,
    accountId: n.id,
    accountName: n.name,
    ticker: N,
    name: b,
    type: f,
    quantity: u,
    localCurrency: r,
    nativeValue: c,
    audValue: x.audValue,
    priceUpdatedAt: e.asOfDate || null,
    identityKey: k.key,
    etfKey: A,
    profileId: e.instrument?.id ?? null,
    status: l,
    issue: h,
    sourceHoldingId: e.id
  };
}
function Ge(e) {
  const n = [], i = /* @__PURE__ */ new Map();
  for (const u of e) {
    const f = i.get(u.status) ?? [];
    f.push(u), i.set(u.status, f);
  }
  const a = i.get("unsupported-currency") ?? [];
  if (a.length) {
    const u = [...new Set(a.map((f) => f.localCurrency))].join(", ");
    n.push({
      id: "unsupported-currency",
      severity: "critical",
      title: "Unsupported currency",
      detail: `${u} holdings remain visible but are excluded from AUD totals until supported.`,
      holdingIds: a.map((f) => f.id)
    });
  }
  const s = i.get("unvalued") ?? [];
  s.length && n.push({
    id: "unvalued",
    severity: "critical",
    title: "Portfolio total is incomplete",
    detail: `${s.length} holding${s.length === 1 ? " has" : "s have"} no usable AUD value. Missing data is never replaced with zero.`,
    holdingIds: s.map((u) => u.id)
  });
  const r = i.get("unsupported-position") ?? [];
  r.length && n.push({
    id: "unsupported-position",
    severity: "critical",
    title: "Unsupported portfolio position",
    detail: "Negative quantity, short positions, or negative cash stop percentage-based X-Ray calculations.",
    holdingIds: r.map((u) => u.id)
  });
  const c = i.get("unknown-instrument") ?? [];
  return c.length && n.push({
    id: "unknown-instrument",
    severity: "warning",
    title: "Instrument type needs review",
    detail: `${c.length} instrument${c.length === 1 ? " is" : "s are"} visible as Unknown until a local override is supplied.`,
    holdingIds: c.map((u) => u.id)
  }), n;
}
function Ye(e, n) {
  const i = /* @__PURE__ */ new Map();
  for (const a of e) {
    if (a.audValue === null || !a.identityKey) continue;
    const s = i.get(a.identityKey);
    if (s) {
      s.valueAud += a.audValue;
      continue;
    }
    i.set(a.identityKey, {
      key: a.identityKey,
      label: a.type === "cash" ? `${a.localCurrency} cash` : a.ticker,
      type: a.type,
      valueAud: a.audValue,
      weight: n && n > 0 ? a.audValue / n : null,
      status: a.status === "valued" ? void 0 : a.status
    });
  }
  return [...i.values()].map((a) => ({ ...a, weight: n && n > 0 ? a.valueAud / n : null })).sort((a, s) => s.valueAud - a.valueAud);
}
function ge(e, n) {
  const i = e.reduce((u, f) => u + (f.audValue ?? 0), 0), a = e.some((u) => u.status === "unvalued" || u.status === "unsupported-currency"), s = e.some((u) => u.status === "unsupported-position"), r = e.length > 0 && !a && !s ? i : null, c = Ge(e);
  return {
    holdings: e,
    selectedAccountIds: n,
    totalAud: r,
    supportedValueAud: i,
    valuedHoldingCount: e.filter((u) => u.audValue !== null).length,
    incomplete: r === null,
    warnings: c,
    instrumentAllocation: Ye(e, r),
    etfs: [...new Map(
      e.filter((u) => u.type === "etf" && u.etfKey).map((u) => [u.etfKey, {
        etfKey: u.etfKey,
        profileId: u.profileId,
        symbol: u.ticker,
        name: u.name,
        currency: u.localCurrency
      }])
    ).values()]
  };
}
function Qe(e, n) {
  return e ? {
    id: e.id,
    name: e.name || n || e.displayCode || "Unmapped instrument",
    symbol: e.instrumentSymbol || e.displayCode || n || "",
    mic: e.instrumentExchangeMic || void 0,
    instrumentKey: e.instrumentKey || void 0,
    instrumentType: e.instrumentType || void 0,
    currency: e.quoteCcy,
    kind: e.kind
  } : null;
}
const me = "etf.index.v1", se = 18e4;
function B(e) {
  return [...e].map((n) => /[A-Za-z0-9]/.test(n) ? n : `_x${n.codePointAt(0)?.toString(16)}_`).join("");
}
function Ze(e) {
  const n = [];
  for (let i = 0; i < e.length; i += se) n.push(e.slice(i, i + se));
  return n;
}
async function J(e) {
  const n = await e.api.storage.get(me);
  if (!n) return {};
  try {
    const i = JSON.parse(n);
    return i && typeof i == "object" ? i : {};
  } catch {
    return {};
  }
}
async function oe(e, n) {
  await e.api.storage.set(me, JSON.stringify(n));
}
class q {
  constructor(n) {
    this.ctx = n;
  }
  ctx;
  async list() {
    const n = await J(this.ctx), i = [];
    for (const a of Object.values(n)) {
      const s = await this.readEntry(a);
      s && i.push({ etfKey: a.etfKey, version: a.version, snapshot: s, updatedAt: a.updatedAt });
    }
    return i;
  }
  async get(n) {
    const a = (await J(this.ctx))[n];
    if (!a) return null;
    const s = await this.readEntry(a);
    return s ? { etfKey: n, version: a.version, snapshot: s, updatedAt: a.updatedAt } : null;
  }
  async readEntry(n) {
    const i = `etf.snapshot.v1.${B(n.etfKey)}.${n.version}`, a = [];
    for (let s = 0; s < n.chunkCount; s += 1) {
      const r = await this.ctx.api.storage.get(`${i}.${s}`);
      if (r === null) return null;
      a.push(r);
    }
    try {
      const s = JSON.parse(a.join(""));
      return G(s).snapshot ?? null;
    } catch {
      return null;
    }
  }
  async save(n, i = {}) {
    const a = G(n);
    if (!a.accepted || !a.snapshot) throw new Error(a.message);
    const s = await J(this.ctx), r = s[n.etfKey];
    if (i.expectedVersion !== void 0 && r && i.expectedVersion !== r.version)
      throw new Error("ETF snapshot changed elsewhere; reload before saving Manual data.");
    if (r?.sourceMode === "manual" && n.sourceMode !== "manual")
      throw new Error("Automatic refresh cannot overwrite a newer Manual snapshot.");
    const c = (r?.version ?? 0) + 1, u = JSON.stringify(a.snapshot), f = Ze(u), x = `etf.snapshot.v1.${B(n.etfKey)}.${c}`;
    for (const [b, k] of f.entries())
      await this.ctx.api.storage.set(`${x}.${b}`, k);
    const N = (/* @__PURE__ */ new Date()).toISOString();
    if (s[n.etfKey] = {
      etfKey: n.etfKey,
      version: c,
      chunkCount: f.length,
      updatedAt: N,
      sourceMode: n.sourceMode
    }, await oe(this.ctx, s), r) {
      const b = `etf.snapshot.v1.${B(r.etfKey)}.${r.version}`;
      for (let k = 0; k < r.chunkCount; k += 1)
        await this.ctx.api.storage.delete(`${b}.${k}`);
    }
    return { etfKey: n.etfKey, version: c, snapshot: a.snapshot, updatedAt: N };
  }
  async disable(n) {
    const i = await J(this.ctx), a = i[n];
    if (!a) return;
    const s = `etf.snapshot.v1.${B(a.etfKey)}.${a.version}`;
    for (let r = 0; r < a.chunkCount; r += 1)
      await this.ctx.api.storage.delete(`${s}.${r}`);
    delete i[n], await oe(this.ctx, i);
  }
}
const fe = "settings.v1", Y = {
  schemaVersion: 1,
  selectionInitialized: !1,
  selectedAccountIds: [],
  acknowledgedAccountIds: [],
  liveFxPolling: !0,
  providerModes: {},
  pinnedProviders: {},
  typeOverrides: {},
  aliases: {}
};
function ve(e) {
  if (!e || typeof e != "object") return { ...Y };
  const n = e, i = (r) => r === "stock" || r === "etf" || r === "cash" || r === "fixed-income" || r === "derivative" || r === "other" || r === "unknown", a = Object.fromEntries(
    Object.entries(n.typeOverrides ?? {}).filter(([, r]) => i(r))
  ), s = Object.fromEntries(
    Object.entries(n.providerModes ?? {}).filter(([, r]) => r === "auto" || r === "pinned")
  );
  return {
    ...Y,
    ...n,
    schemaVersion: 1,
    selectionInitialized: !!n.selectionInitialized,
    selectedAccountIds: Array.isArray(n.selectedAccountIds) ? n.selectedAccountIds.filter((r) => typeof r == "string") : [],
    acknowledgedAccountIds: Array.isArray(n.acknowledgedAccountIds) ? n.acknowledgedAccountIds.filter((r) => typeof r == "string") : [],
    liveFxPolling: n.liveFxPolling !== !1,
    providerModes: s,
    pinnedProviders: typeof n.pinnedProviders == "object" && n.pinnedProviders ? n.pinnedProviders : {},
    typeOverrides: a,
    aliases: typeof n.aliases == "object" && n.aliases ? n.aliases : {}
  };
}
async function et(e) {
  const n = await e.api.storage.get(fe);
  if (!n) return { ...Y };
  try {
    return ve(JSON.parse(n));
  } catch {
    return { ...Y };
  }
}
async function O(e, n) {
  await e.api.storage.set(fe, JSON.stringify(ve(n)));
}
function tt(e, n) {
  const i = new Set(n.map((c) => c.id));
  if (!e.selectionInitialized) {
    const c = n.map((u) => u.id);
    return {
      settings: {
        ...e,
        selectionInitialized: !0,
        selectedAccountIds: c,
        acknowledgedAccountIds: c
      },
      selectedAccounts: n,
      newlyIncludedAccounts: []
    };
  }
  const a = new Set(e.acknowledgedAccountIds), s = new Set(e.selectedAccountIds.filter((c) => i.has(c))), r = n.filter((c) => !a.has(c.id));
  for (const c of r)
    s.add(c.id), a.add(c.id);
  return {
    settings: {
      ...e,
      selectedAccountIds: [...s],
      acknowledgedAccountIds: [...a]
    },
    selectedAccounts: n.filter((c) => s.has(c.id)),
    newlyIncludedAccounts: r
  };
}
function nt(e, n) {
  return { ...e, selectionInitialized: !0, selectedAccountIds: [...new Set(n)] };
}
const te = "fx.quote.usd-aud", ye = "twelvedata.apiKey";
function Q(e) {
  return typeof e == "number" && Number.isFinite(e) && e > 0;
}
function at(e) {
  if (!e) return null;
  try {
    const n = JSON.parse(e);
    if (n.pair === "USD/AUD" && Q(n.rate) && typeof n.fetchedAt == "string")
      return {
        pair: "USD/AUD",
        rate: n.rate,
        fetchedAt: n.fetchedAt,
        provider: n.provider === "wealthfolio" ? "wealthfolio" : "twelvedata"
      };
  } catch {
    return null;
  }
  return null;
}
function it(e) {
  const n = e.find(
    (a) => a.fromCurrency.toUpperCase() === "USD" && a.toCurrency.toUpperCase() === "AUD" && Q(a.rate)
  );
  if (n)
    return { pair: "USD/AUD", rate: n.rate, fetchedAt: n.timestamp, provider: "wealthfolio" };
  const i = e.find(
    (a) => a.fromCurrency.toUpperCase() === "AUD" && a.toCurrency.toUpperCase() === "USD" && Q(a.rate)
  );
  return i ? { pair: "USD/AUD", rate: 1 / i.rate, fetchedAt: i.timestamp, provider: "wealthfolio" } : null;
}
async function rt(e, n) {
  const i = `https://api.twelvedata.com/exchange_rate?symbol=${encodeURIComponent("USD/AUD")}&apikey=${encodeURIComponent(n)}`, a = await e.api.network.request({ method: "GET", url: i });
  if (a.status < 200 || a.status >= 300) throw new Error(`Twelve Data returned ${a.status}`);
  const s = JSON.parse(a.body), r = typeof s.rate == "string" ? Number(s.rate) : s.rate;
  if (!Q(r)) throw new Error(s.message || "Twelve Data returned an invalid USD/AUD rate");
  return { pair: "USD/AUD", rate: r, fetchedAt: (/* @__PURE__ */ new Date()).toISOString(), provider: "twelvedata" };
}
class st {
  constructor(n) {
    this.ctx = n;
  }
  ctx;
  async getSharedQuote() {
    return at(await this.ctx.api.storage.get(te));
  }
  async getQuote(n = {}) {
    const i = await this.getSharedQuote();
    if (i && Date.now() - Date.parse(i.fetchedAt) < Le && !n.force) return i;
    const s = await this.ctx.api.secrets.get(ye);
    if (s)
      try {
        const r = await rt(this.ctx, s);
        return await this.ctx.api.storage.set(te, JSON.stringify(r)), r;
      } catch (r) {
        this.ctx.api.logger.warn(`USD/AUD provider failed: ${r instanceof Error ? r.message : "unknown error"}`);
      }
    try {
      const r = it(await this.ctx.api.exchangeRates.getAll());
      if (r)
        return await this.ctx.api.storage.set(te, JSON.stringify(r)), r;
    } catch (r) {
      this.ctx.api.logger.warn(`Wealthfolio FX fallback failed: ${r instanceof Error ? r.message : "unknown error"}`);
    }
    return i;
  }
}
function ot(e) {
  const n = typeof e == "number" ? e : Number(String(e ?? "").replace(/%$/, ""));
  return !Number.isFinite(n) || n < 0 ? null : n > 1 ? n / 100 : n;
}
function lt(e, n, i, a) {
  const s = {
    schemaVersion: 1,
    etfKey: e.etfKey,
    provider: n,
    asOfDate: a || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    holdings: i,
    weightSum: i.reduce((c, u) => c + u.weight, 0),
    normalized: !1,
    sourceMode: "automatic"
  }, r = G(s);
  if (!r.accepted || !r.snapshot) throw new Error(r.message);
  return r.snapshot;
}
async function be(e, n) {
  const i = await e.api.network.request({ method: "GET", url: n });
  if (i.status < 200 || i.status >= 300) throw new Error(`Provider returned ${i.status}`);
  return i.body;
}
class ct {
  constructor(n, i) {
    this.ctx = n, this.apiKey = i;
  }
  ctx;
  apiKey;
  id = "alpha-vantage";
  async canHandle(n) {
    return !!(this.apiKey && n.symbol);
  }
  async fetchHoldings(n) {
    if (!this.apiKey) throw new Error("Alpha Vantage API key is not configured");
    const i = `https://www.alphavantage.co/query?function=ETF_PROFILE&symbol=${encodeURIComponent(n.symbol)}&apikey=${encodeURIComponent(this.apiKey)}`, a = JSON.parse(await be(this.ctx, i));
    if (!a.holdings?.length) throw new Error(a.Information || a.Note || a.message || "Alpha Vantage returned no holdings");
    const s = [];
    for (const r of a.holdings) {
      const c = ot(r.weight), u = String(r.name ?? r.description ?? r.symbol ?? "").trim();
      !u || c === null || s.push({
        symbol: String(r.symbol ?? "").trim() || void 0,
        name: u,
        weight: c,
        country: String(r.country ?? "").trim() || void 0,
        sector: String(r.sector ?? "").trim() || void 0,
        assetClass: String(r.asset_type ?? r.assetClass ?? "").trim() || void 0,
        underlyingType: String(r.asset_type ?? "").toLowerCase().includes("etf") ? "etf" : "stock"
      });
    }
    return lt(n, this.id, s, a.last_updated);
  }
}
class le {
  constructor(n, i, a) {
    this.id = n, this.ctx = i, this.hostPrefix = a;
  }
  id;
  ctx;
  hostPrefix;
  async canHandle(n) {
    return !!n.providerSymbol?.startsWith(`${this.id}:`);
  }
  async fetchHoldings(n) {
    const i = n.providerSymbol?.slice(this.id.length + 1);
    if (!i) throw new Error(`${this.id} public identifier is missing`);
    const a = `${this.hostPrefix}${encodeURIComponent(i)}`, s = await be(this.ctx, a), r = pe(s, {
      etfKey: n.etfKey,
      provider: this.id,
      asOfDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    if (!r.validation.accepted || !r.validation.snapshot) throw new Error(r.validation.message);
    return r.validation.snapshot;
  }
}
function dt(e, n) {
  return [
    new le("ishares", e, "https://www.ishares.com/us/products/"),
    new le("betashares", e, "https://www.betashares.com.au/fund/"),
    new ct(e, n.alphaVantageApiKey)
  ];
}
async function ut(e, n, i) {
  if (i.cached && i.mode === "auto") {
    const r = Date.parse(i.cached.fetchedAt);
    if (Number.isFinite(r) && Date.now() - r <= 1440 * 60 * 1e3)
      return { snapshot: i.cached, provider: i.cached.provider };
  }
  const a = i.mode === "pinned" ? n.filter((r) => r.id === i.pinnedProvider) : n;
  let s = "No provider can handle this ETF";
  for (const r of a)
    try {
      if (!await r.canHandle(e)) continue;
      return { snapshot: await r.fetchHoldings(e), provider: r.id };
    } catch (c) {
      s = c instanceof Error ? c.message : "Provider failed";
    }
  return { snapshot: i.cached ?? null, provider: i.cached?.provider ?? null, failureReason: s };
}
function pt(e) {
  return {
    id: e.id,
    name: e.name,
    currency: e.currency,
    isActive: e.isActive,
    isArchived: e.isArchived
  };
}
async function ht(e) {
  return (await e.api.accounts.getAll()).filter((i) => i.isActive && !i.isArchived).map(pt);
}
async function gt(e, n, i) {
  const a = n.filter((u) => i.includes(u.id)), s = await Promise.all(
    a.map(async (u) => ({
      account: u,
      holdings: await e.api.portfolio.getHoldings(u.id)
    }))
  ), r = /* @__PURE__ */ new Map(), c = [];
  for (const u of s)
    for (const f of u.holdings) {
      const x = f.instrument?.id;
      let N = null;
      if (x) {
        if (!r.has(x))
          try {
            const b = await e.api.assets.getProfile(x);
            r.set(x, Qe(b, f.instrument?.symbol));
          } catch {
            r.set(x, null);
          }
        N = r.get(x) ?? null;
      }
      c.push({ holding: f, account: u.account, profile: N });
    }
  return c;
}
async function mt(e) {
  return (await e.api.settings.get()).baseCurrency.toUpperCase();
}
const ft = {
  schemaVersion: 1,
  selectionInitialized: !1,
  selectedAccountIds: [],
  acknowledgedAccountIds: [],
  liveFxPolling: !0,
  providerModes: {},
  pinnedProviders: {},
  typeOverrides: {},
  aliases: {}
}, vt = ge([], []), yt = ue({ holdings: [], snapshots: /* @__PURE__ */ new Map(), totalAud: null });
function bt() {
  return {
    loading: !0,
    error: null,
    baseCurrency: null,
    activeAccounts: [],
    selectedAccounts: [],
    settings: ft,
    holdings: [],
    portfolio: vt,
    exposure: yt,
    fxQuote: null,
    snapshots: /* @__PURE__ */ new Map(),
    etfData: [],
    newlyIncludedAccounts: [],
    hasTwelveDataKey: !1,
    hasAlphaVantageKey: !1,
    lastLoadedAt: null
  };
}
function xt(e) {
  const [n, i] = $(bt), [a, s] = $(0), r = Ae(!0), c = F(async (m = {}) => {
    i((p) => ({ ...p, loading: !0, error: null }));
    try {
      const [p, v, d, S, y] = await Promise.all([
        ht(e),
        et(e),
        mt(e),
        e.api.secrets.get(ye).then((E) => !!E),
        e.api.secrets.get("alphaVantage.apiKey").then((E) => !!E)
      ]), w = tt(v, p);
      JSON.stringify(w.settings) !== JSON.stringify(v) && await O(e, w.settings);
      const T = await new st(e).getQuote({ force: m.forceFx }), g = (await gt(e, p, w.settings.selectedAccountIds)).map((E) => {
        const M = E.profile?.instrumentKey || E.profile?.id || E.holding.instrument?.id;
        return Je(E.holding, E.account, E.profile, T, M ? w.settings.typeOverrides[M] : void 0);
      }), C = ge(g, w.settings.selectedAccountIds), V = await new q(e).list(), W = new Map(V.map((E) => [E.etfKey, E.snapshot])), xe = ue({
        holdings: g,
        snapshots: W,
        totalAud: C.totalAud,
        aliases: w.settings.aliases
      }), we = C.etfs.map((E) => {
        const M = W.get(E.etfKey) ?? null, ke = V.find((Ne) => Ne.etfKey === E.etfKey);
        return {
          asset: E,
          snapshot: M,
          version: ke?.version,
          status: qe(M),
          resolvedWeight: M?.weightSum ?? 0,
          failureReason: M?.failureReason
        };
      });
      r.current && i({
        loading: !1,
        error: null,
        baseCurrency: d,
        activeAccounts: p,
        selectedAccounts: w.selectedAccounts,
        settings: w.settings,
        holdings: g,
        portfolio: C,
        exposure: xe,
        fxQuote: T,
        snapshots: W,
        etfData: we,
        newlyIncludedAccounts: w.newlyIncludedAccounts,
        hasTwelveDataKey: S,
        hasAlphaVantageKey: y,
        lastLoadedAt: (/* @__PURE__ */ new Date()).toISOString()
      });
    } catch (p) {
      r.current && i((v) => ({
        ...v,
        loading: !1,
        error: p instanceof Error ? p.message : "Unable to read Wealthfolio data"
      }));
    }
  }, [e]);
  L(() => (r.current = !0, c(), () => {
    r.current = !1;
  }), [c, a]), L(() => {
    let m = !1;
    const p = [];
    async function v() {
      const d = await Promise.all([
        e.api.events.portfolio.onUpdateComplete(() => {
          c();
        }),
        e.api.events.market.onSyncComplete(() => {
          c();
        })
      ]);
      m ? d.forEach((S) => S()) : p.push(...d);
    }
    return v(), () => {
      m = !0, p.forEach((d) => d());
    };
  }, [e, c]), L(() => {
    if (!n.settings.liveFxPolling) return;
    const m = () => {
      document.visibilityState === "visible" && c();
    }, p = window.setInterval(m, 300 * 1e3);
    return document.addEventListener("visibilitychange", m), () => {
      window.clearInterval(p), document.removeEventListener("visibilitychange", m);
    };
  }, [c, n.settings.liveFxPolling]);
  const u = F(async (m, p) => {
    await new q(e).save(m, { expectedVersion: p }), s((v) => v + 1);
  }, [e]), f = F(async (m) => {
    await new q(e).disable(m), s((p) => p + 1);
  }, [e]), x = F(async (m) => {
    const p = n.portfolio.etfs.find((w) => w.etfKey === m);
    if (!p) return;
    const v = await new q(e).get(m), [d] = await Promise.all([e.api.secrets.get("alphaVantage.apiKey")]), S = dt(e, { alphaVantageApiKey: d }), y = await ut(p, S, {
      mode: n.settings.providerModes[m] ?? "auto",
      pinnedProvider: n.settings.pinnedProviders[m],
      cached: v?.snapshot
    });
    if (!y.snapshot) throw new Error(y.failureReason ?? "No ETF provider could resolve this fund");
    await new q(e).save({ ...y.snapshot, failureReason: y.failureReason }, { expectedVersion: v?.version }), s((w) => w + 1);
  }, [e, n.portfolio.etfs, n.settings.pinnedProviders, n.settings.providerModes]), N = F(async (m) => {
    const p = nt(n.settings, m);
    await O(e, p), s((v) => v + 1);
  }, [e, n.settings]), b = F(async (m, p) => {
    p.trim() ? await e.api.secrets.set(m, p.trim()) : await e.api.secrets.delete(m), s((v) => v + 1);
  }, [e]), k = F(async (m) => {
    await e.api.secrets.delete(m), s((p) => p + 1);
  }, [e]), A = F(async (m) => {
    const p = { ...n.settings, liveFxPolling: m };
    await O(e, p), i((v) => ({ ...v, settings: p }));
  }, [e, n.settings]), l = F(async (m, p) => {
    const v = { ...n.settings, typeOverrides: { ...n.settings.typeOverrides, [m]: p } };
    await O(e, v), s((d) => d + 1);
  }, [e, n.settings]), h = F(async (m, p) => {
    const v = { ...n.settings, providerModes: { ...n.settings.providerModes, [m]: p } };
    await O(e, v), i((d) => ({ ...d, settings: v }));
  }, [e, n.settings]), D = F(async (m, p) => {
    const v = { ...n.settings, pinnedProviders: { ...n.settings.pinnedProviders, [m]: p } };
    await O(e, v), i((d) => ({ ...d, settings: v }));
  }, [e, n.settings]);
  return Se(() => ({
    ...n,
    refresh: c,
    refreshEtf: x,
    saveSnapshot: u,
    disableSnapshot: f,
    saveAccountSelection: N,
    saveSecret: b,
    deleteSecret: k,
    setLiveFxPolling: A,
    setTypeOverride: l,
    setProviderMode: h,
    setPinnedProvider: D
  }), [
    n,
    c,
    x,
    u,
    f,
    N,
    b,
    k,
    A,
    l,
    h,
    D
  ]);
}
function wt({
  ctx: e,
  portfolio: n,
  exposure: i,
  fxQuote: a,
  etfData: s,
  baseCurrency: r,
  selectedAccounts: c,
  newlyIncludedAccounts: u,
  onNavigatePerformance: f,
  onRefreshFx: x,
  onGoToSettings: N
}) {
  const b = a ? Xe(a.fetchedAt) : null, k = [...n.warnings];
  r && r !== "AUD" && k.unshift({ id: "base-currency", severity: "critical", title: "Wealthfolio base currency is not AUD", detail: `Portfolio X-Ray is designed for AUD valuation. Current Wealthfolio base currency: ${r}.` }), !a && n.holdings.some((h) => h.localCurrency === "USD") && k.unshift({ id: "missing-fx", severity: "critical", title: "USD/AUD quote unavailable", detail: "USD holdings remain visible in native currency, but AUD totals and percentages are incomplete. Configure Twelve Data or refresh Wealthfolio rates." }), u.length && k.unshift({ id: "new-accounts", severity: "info", title: "New active account included", detail: `${u.map((h) => h.name).join(", ")} was included for X-Ray analysis. You can change this in Settings.` });
  const A = n.holdings.length === 0, l = !A && n.totalAud === null;
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ t(X, { eyebrow: "Portfolio intelligence", title: "Overview", detail: `${c.length} selected account${c.length === 1 ? "" : "s"} · current values from Wealthfolio`, action: /* @__PURE__ */ t(I, { onClick: x, variant: "quiet", children: "↻ Refresh X-Ray" }) }),
    A ? /* @__PURE__ */ t(j, { icon: "◈", title: "No holdings in the selected accounts", detail: "Choose active Wealthfolio accounts in Settings to begin your Portfolio X-Ray.", action: /* @__PURE__ */ t(I, { onClick: N, variant: "primary", children: "Open Settings" }) }) : /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("div", { className: "metric-grid", children: [
        /* @__PURE__ */ t(H, { label: "Total portfolio", value: n.totalAud === null ? "Incomplete" : U(n.totalAud), detail: l ? "Missing values remain visible" : "Supported holdings and cash in AUD", icon: "◎", tone: l ? "warning" : "green" }),
        /* @__PURE__ */ t(H, { label: "USD / AUD", value: a ? a.rate.toFixed(4) : "—", detail: a ? `${a.provider === "twelvedata" ? "Twelve Data" : "Wealthfolio"} · ${He(a.fetchedAt)}` : "No usable quote", icon: "↗", tone: b === "Warning" ? "warning" : "blue" }),
        /* @__PURE__ */ t(H, { label: "ETFs", value: String(s.length), detail: `${s.filter((h) => h.snapshot).length} with constituent data`, icon: "◫", tone: "purple" }),
        /* @__PURE__ */ t(H, { label: "Look-through coverage", value: i.coverage === null ? "—" : K(i.coverage), detail: i.eligibleValueAud > 0 ? `${U(i.coveredValueAud)} of eligible value` : "Cash excluded from coverage", icon: "⌁", tone: i.coverage !== null && i.coverage >= 0.95 ? "green" : "warning" })
      ] }),
      b && /* @__PURE__ */ o("div", { className: "quote-strip", children: [
        /* @__PURE__ */ t("span", { className: "quote-live-dot" }),
        /* @__PURE__ */ o("strong", { children: [
          "USD/AUD ",
          b.toLowerCase()
        ] }),
        /* @__PURE__ */ t("span", { children: a?.provider === "twelvedata" ? "Twelve Data" : "Wealthfolio fallback" }),
        /* @__PURE__ */ o("span", { children: [
          "Fetched ",
          a ? new Date(a.fetchedAt).toLocaleString() : "—"
        ] }),
        /* @__PURE__ */ t("button", { onClick: x, children: "Refresh" })
      ] }),
      /* @__PURE__ */ t(Te, { warnings: k }),
      /* @__PURE__ */ o("div", { className: "chart-grid", children: [
        /* @__PURE__ */ t(re, { title: "Instrument Allocation", subtitle: "What instruments did you buy? ETFs stay intact.", rows: Ue(n.instrumentAllocation), valueLabel: "AUD value" }),
        /* @__PURE__ */ t(re, { title: "True Exposure", subtitle: "What companies and asset classes move with you?", rows: Fe(i.rows), valueLabel: "Exposure" })
      ] }),
      /* @__PURE__ */ o("div", { className: "insight-row", children: [
        /* @__PURE__ */ o("div", { className: "panel insight-card", children: [
          /* @__PURE__ */ t("div", { className: "insight-icon", children: "✓" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("span", { className: "eyebrow", children: "Value conservation" }),
            /* @__PURE__ */ t("strong", { children: Math.abs(i.valueConservationDelta) < 0.5 ? "Balanced" : "Needs review" }),
            /* @__PURE__ */ t("p", { children: Math.abs(i.valueConservationDelta) < 0.5 ? "Every supported dollar is represented in True Exposure." : `${U(Math.abs(i.valueConservationDelta))} is not reconciled.` })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "panel insight-card", children: [
          /* @__PURE__ */ t("div", { className: "insight-icon", children: "↗" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("span", { className: "eyebrow", children: "Native performance" }),
            /* @__PURE__ */ t("strong", { children: "Keep benchmarks in Wealthfolio" }),
            /* @__PURE__ */ t("p", { children: "Portfolio X-Ray never replaces Wealthfolio's TWR, IRR, or benchmark engine." }),
            /* @__PURE__ */ t(I, { onClick: f, variant: "quiet", children: "Open Performance →" })
          ] })
        ] })
      ] })
    ] }),
    k.length > 0 && !A && /* @__PURE__ */ o("div", { className: "page-footnote", children: [
      /* @__PURE__ */ t(R, { value: "Disclosure", tone: "neutral" }),
      " X-Ray calculations use only supported, valued holdings; unresolved value remains visible in residual or opaque buckets."
    ] }),
    /* @__PURE__ */ t("span", { className: "visually-hidden", children: e.api ? "Wealthfolio connected" : "" })
  ] });
}
function kt({ portfolio: e, onGoToSettings: n }) {
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ t(X, { eyebrow: "Audit trail", title: "Holdings", detail: "Account-level rows stay untouched so every value can be traced back to Wealthfolio.", action: /* @__PURE__ */ o("span", { className: "data-source-pill", children: [
      /* @__PURE__ */ t("span", { className: "pulse-dot" }),
      "Wealthfolio source"
    ] }) }),
    e.holdings.length === 0 ? /* @__PURE__ */ t(j, { icon: "▤", title: "No holdings to show", detail: "Select at least one active Wealthfolio account to see its raw holdings.", action: /* @__PURE__ */ t(I, { onClick: n, variant: "primary", children: "Choose accounts" }) }) : /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
      /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("strong", { children: [
            e.holdings.length,
            " holding",
            e.holdings.length === 1 ? "" : "s"
          ] }),
          /* @__PURE__ */ t("span", { children: "Same ticker in two accounts remains two rows." })
        ] }),
        /* @__PURE__ */ t("span", { className: "table-toolbar-note", children: "Portfolio weights use current AUD total only when complete" })
      ] }),
      /* @__PURE__ */ o(ae, { children: [
        /* @__PURE__ */ t("thead", { children: /* @__PURE__ */ o("tr", { children: [
          /* @__PURE__ */ t("th", { children: "Ticker" }),
          /* @__PURE__ */ t("th", { children: "Name" }),
          /* @__PURE__ */ t("th", { children: "Account" }),
          /* @__PURE__ */ t("th", { children: "Type" }),
          /* @__PURE__ */ t("th", { className: "numeric", children: "Quantity" }),
          /* @__PURE__ */ t("th", { children: "Currency" }),
          /* @__PURE__ */ t("th", { className: "numeric", children: "Native value" }),
          /* @__PURE__ */ t("th", { className: "numeric", children: "AUD value" }),
          /* @__PURE__ */ t("th", { className: "numeric", children: "Weight" }),
          /* @__PURE__ */ t("th", { children: "Price updated" }),
          /* @__PURE__ */ t("th", { children: "Status" })
        ] }) }),
        /* @__PURE__ */ t("tbody", { children: e.holdings.map((i) => /* @__PURE__ */ t(Nt, { holding: i, totalAud: e.totalAud }, i.id)) })
      ] })
    ] })
  ] });
}
function Nt({ holding: e, totalAud: n }) {
  const i = e.audValue !== null && n && n > 0 && e.status === "valued" ? e.audValue / n : null, a = e.status === "valued" ? "good" : e.status === "unsupported-position" || e.status === "unsupported-currency" ? "critical" : "warning";
  return /* @__PURE__ */ o("tr", { children: [
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("strong", { className: "ticker-cell", children: e.ticker }) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("span", { className: "name-cell", children: e.name }) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ o("span", { className: "account-cell", children: [
      /* @__PURE__ */ t("span", { className: "account-avatar", children: e.accountName.slice(0, 1).toUpperCase() }),
      e.accountName
    ] }) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("span", { className: "type-label", children: e.type }) }),
    /* @__PURE__ */ t("td", { className: "numeric", children: Ie(e.quantity) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("span", { className: "currency-label", children: e.localCurrency }) }),
    /* @__PURE__ */ t("td", { className: "numeric", children: Ee(e.nativeValue, e.localCurrency) }),
    /* @__PURE__ */ t("td", { className: "numeric value-strong", children: e.audValue === null ? "—" : U(e.audValue) }),
    /* @__PURE__ */ t("td", { className: "numeric", children: K(i) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("span", { className: "date-cell", children: e.priceUpdatedAt ? new Date(e.priceUpdatedAt).toLocaleDateString() : "—" }) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t(R, { value: e.status === "valued" ? "Valued" : e.status.replace(/-/g, " "), tone: a }) })
  ] });
}
function At({ exposure: e, hasHoldings: n, onGoToSettings: i }) {
  const [a, s] = $(null), r = e.rows.find((c) => c.key === a) ?? null;
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ t(X, { eyebrow: "Economic exposure", title: "X-Ray", detail: "Direct holdings and ETF-derived exposure are consolidated into one canonical view.", action: /* @__PURE__ */ o("div", { className: "coverage-pill", children: [
      /* @__PURE__ */ t("span", { children: "Coverage" }),
      /* @__PURE__ */ t("strong", { children: K(e.coverage) })
    ] }) }),
    n ? e.rows.length === 0 ? /* @__PURE__ */ t(j, { icon: "⌁", title: "Exposure is incomplete", detail: "No holding has a usable AUD value yet. Native values remain available on Holdings." }) : /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("div", { className: "xray-summary", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ t("span", { className: "eyebrow", children: "Resolved value" }),
          /* @__PURE__ */ t("strong", { children: U(e.coveredValueAud) }),
          /* @__PURE__ */ o("span", { children: [
            "of ",
            U(e.eligibleValueAud),
            " eligible investable value"
          ] })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ t("span", { className: "eyebrow", children: "Reconciliation" }),
          /* @__PURE__ */ t("strong", { className: Math.abs(e.valueConservationDelta) < 0.5 ? "text-green" : "text-warning", children: Math.abs(e.valueConservationDelta) < 0.5 ? "Balanced" : U(Math.abs(e.valueConservationDelta)) }),
          /* @__PURE__ */ t("span", { children: "including cash, residuals, and opaque ETFs" })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
        /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ o("strong", { children: [
              e.rows.length,
              " canonical exposure",
              e.rows.length === 1 ? "" : "s"
            ] }),
            /* @__PURE__ */ t("span", { children: "Sources opens account- and ETF-level contributions." })
          ] }),
          /* @__PURE__ */ t("span", { className: "table-toolbar-note", children: "Cash is excluded from Coverage" })
        ] }),
        /* @__PURE__ */ o(ae, { children: [
          /* @__PURE__ */ t("thead", { children: /* @__PURE__ */ o("tr", { children: [
            /* @__PURE__ */ t("th", { children: "Ticker / bucket" }),
            /* @__PURE__ */ t("th", { children: "Security / bucket" }),
            /* @__PURE__ */ t("th", { className: "numeric", children: "Direct" }),
            /* @__PURE__ */ t("th", { className: "numeric", children: "Via ETFs" }),
            /* @__PURE__ */ t("th", { className: "numeric", children: "Total exposure" }),
            /* @__PURE__ */ t("th", { className: "numeric", children: "Portfolio %" }),
            /* @__PURE__ */ t("th", { children: "Sources" }),
            /* @__PURE__ */ t("th", { children: "Sector" }),
            /* @__PURE__ */ t("th", { children: "Country" }),
            /* @__PURE__ */ t("th", { children: "Status" })
          ] }) }),
          /* @__PURE__ */ t("tbody", { children: e.rows.map((c) => /* @__PURE__ */ t(St, { row: c, selected: c.key === a, onSelect: () => s(c.key === a ? null : c.key) }, c.key)) })
        ] })
      ] }),
      r && /* @__PURE__ */ t(Ct, { row: r, onClose: () => s(null) })
    ] }) : /* @__PURE__ */ t(j, { icon: "⌁", title: "Nothing to X-Ray yet", detail: "Add holdings to the selected Wealthfolio accounts, then return here.", action: /* @__PURE__ */ t(I, { onClick: i, variant: "primary", children: "Choose accounts" }) })
  ] });
}
function St({ row: e, selected: n, onSelect: i }) {
  const a = e.sources.some((s) => s.kind === "opaque" || s.kind === "residual") ? "warning" : "good";
  return /* @__PURE__ */ o("tr", { className: n ? "row-selected" : "", children: [
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("strong", { className: "ticker-cell", children: e.key.startsWith("opaque-") || e.key.startsWith("residual-") ? "—" : e.label.slice(0, 10).toUpperCase() }) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t("span", { className: "name-cell", children: e.label }) }),
    /* @__PURE__ */ t("td", { className: "numeric", children: e.directAud ? U(e.directAud) : "—" }),
    /* @__PURE__ */ t("td", { className: "numeric", children: e.viaEtfsAud ? U(e.viaEtfsAud) : "—" }),
    /* @__PURE__ */ t("td", { className: "numeric value-strong", children: U(e.totalAud) }),
    /* @__PURE__ */ t("td", { className: "numeric", children: K(e.portfolioWeight) }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ o("button", { className: "source-button", onClick: i, children: [
      /* @__PURE__ */ t("span", { className: "source-count", children: e.sources.length }),
      " View Sources"
    ] }) }),
    /* @__PURE__ */ t("td", { children: e.sector ?? "—" }),
    /* @__PURE__ */ t("td", { children: e.country ?? "—" }),
    /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t(R, { value: e.status ?? (e.type === "cash" ? "Cash" : "Resolved"), tone: e.status ? a : "good" }) })
  ] });
}
function Ct({ row: e, onClose: n }) {
  const i = e.sources.filter((r) => r.kind === "direct"), a = e.sources.filter((r) => r.kind === "etf"), s = e.sources.filter((r) => r.kind === "residual" || r.kind === "opaque");
  return /* @__PURE__ */ o("div", { className: "source-drawer panel", children: [
    /* @__PURE__ */ o("div", { className: "drawer-head", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("span", { className: "eyebrow", children: "Exposure sources" }),
        /* @__PURE__ */ t("h2", { children: e.label }),
        /* @__PURE__ */ t("strong", { children: U(e.totalAud) })
      ] }),
      /* @__PURE__ */ t(I, { onClick: n, variant: "quiet", children: "Close" })
    ] }),
    /* @__PURE__ */ o("div", { className: "source-columns", children: [
      /* @__PURE__ */ t(ne, { title: "Direct", sources: i.map((r) => ({ label: r.accountName, amountAud: r.amountAud })) }),
      /* @__PURE__ */ t(ne, { title: "Via ETFs", sources: a.map((r) => ({ label: `${r.etfSymbol}${r.path.length > 1 ? ` · ${r.path.join(" → ")}` : ""}`, amountAud: r.amountAud })) }),
      /* @__PURE__ */ t(ne, { title: "Residual / opaque", sources: s.map((r) => ({ label: r.reason, amountAud: r.amountAud })) })
    ] })
  ] });
}
function ne({ title: e, sources: n }) {
  return /* @__PURE__ */ o("div", { className: "source-group", children: [
    /* @__PURE__ */ t("span", { className: "eyebrow", children: e }),
    n.length === 0 ? /* @__PURE__ */ t("p", { className: "muted", children: "None" }) : n.map((i, a) => /* @__PURE__ */ o("div", { className: "source-line", children: [
      /* @__PURE__ */ t("span", { children: i.label }),
      /* @__PURE__ */ t("strong", { children: U(i.amountAud) })
    ] }, `${i.label}-${a}`))
  ] });
}
function Dt({
  etfData: e,
  onRefreshEtf: n,
  onSaveSnapshot: i,
  onDisableSnapshot: a
}) {
  const [s, r] = $(e[0]?.asset.etfKey ?? ""), [c, u] = $(""), [f, x] = $(null), [N, b] = $(!1), [k, A] = $(null), l = e.find((d) => d.asset.etfKey === s) ?? e[0] ?? null;
  L(() => {
    !l && e[0] && r(e[0].asset.etfKey);
  }, [e, l]);
  const h = () => {
    if (!l) return;
    const d = pe(c, {
      etfKey: l.asset.etfKey,
      provider: "manual",
      asOfDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    x(d), A(null);
  }, D = async () => {
    if (!(!l || !f?.validation.snapshot)) {
      b(!0), A(null);
      try {
        await i(f.validation.snapshot, l.version), A("Manual snapshot saved. It is now the pinned local source for this ETF."), x(null), u("");
      } catch (d) {
        A(d instanceof Error ? d.message : "Unable to save the snapshot");
      } finally {
        b(!1);
      }
    }
  }, m = async () => {
    if (l) {
      b(!0), A(null);
      try {
        await n(l.asset.etfKey), A("ETF data refreshed from the configured resolver.");
      } catch (d) {
        A(d instanceof Error ? d.message : "ETF refresh failed; the last valid snapshot is still active.");
      } finally {
        b(!1);
      }
    }
  }, p = () => {
    if (!l?.snapshot) return;
    const d = new Blob([We(l.snapshot)], { type: "text/csv;charset=utf-8" }), S = URL.createObjectURL(d), y = document.createElement("a");
    y.href = S, y.download = `${l.asset.symbol.toLowerCase()}-holdings.csv`, y.click(), URL.revokeObjectURL(S);
  }, v = (d) => {
    if (!d) return;
    const S = new FileReader();
    S.onload = () => u(typeof S.result == "string" ? S.result : ""), S.readAsText(d);
  };
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ t(X, { eyebrow: "Look-through sources", title: "ETF Data", detail: "Keep provider snapshots separate from current portfolio values. As-of date and fetched time are always distinct.", action: /* @__PURE__ */ t("span", { className: "data-source-pill", children: "Local cache · 24 hr TTL" }) }),
    e.length ? /* @__PURE__ */ o(Z, { children: [
      /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
        /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ o("strong", { children: [
              e.length,
              " ETF",
              e.length === 1 ? "" : "s"
            ] }),
            /* @__PURE__ */ t("span", { children: "Refresh only missing or stale automatic snapshots." })
          ] }),
          /* @__PURE__ */ t("span", { className: "table-toolbar-note", children: "Manual CSV paste works in self-hosted Web/Docker" })
        ] }),
        /* @__PURE__ */ o(ae, { children: [
          /* @__PURE__ */ t("thead", { children: /* @__PURE__ */ o("tr", { children: [
            /* @__PURE__ */ t("th", { children: "ETF" }),
            /* @__PURE__ */ t("th", { children: "Provider" }),
            /* @__PURE__ */ t("th", { children: "Holdings" }),
            /* @__PURE__ */ t("th", { children: "As of" }),
            /* @__PURE__ */ t("th", { children: "Fetched" }),
            /* @__PURE__ */ t("th", { children: "Resolved weight" }),
            /* @__PURE__ */ t("th", { children: "Status" }),
            /* @__PURE__ */ t("th", { children: "Actions" })
          ] }) }),
          /* @__PURE__ */ t("tbody", { children: e.map((d) => /* @__PURE__ */ o("tr", { className: l?.asset.etfKey === d.asset.etfKey ? "row-selected" : "", onClick: () => r(d.asset.etfKey), children: [
            /* @__PURE__ */ o("td", { children: [
              /* @__PURE__ */ t("strong", { className: "ticker-cell", children: d.asset.symbol }),
              /* @__PURE__ */ t("span", { className: "table-subtext", children: d.asset.name })
            ] }),
            /* @__PURE__ */ t("td", { children: d.snapshot?.provider ?? "—" }),
            /* @__PURE__ */ t("td", { children: d.snapshot ? d.snapshot.holdings.length : "—" }),
            /* @__PURE__ */ t("td", { children: d.snapshot?.asOfDate ?? "—" }),
            /* @__PURE__ */ t("td", { children: d.snapshot ? new Date(d.snapshot.fetchedAt).toLocaleString() : "—" }),
            /* @__PURE__ */ t("td", { children: K(d.resolvedWeight) }),
            /* @__PURE__ */ t("td", { children: /* @__PURE__ */ t(R, { value: d.status, tone: Et(d.status) }) }),
            /* @__PURE__ */ t("td", { children: /* @__PURE__ */ o("div", { className: "row-actions", children: [
              /* @__PURE__ */ t(I, { onClick: () => {
                r(d.asset.etfKey), n(d.asset.etfKey);
              }, variant: "quiet", children: "Refresh" }),
              /* @__PURE__ */ t(I, { onClick: () => {
                r(d.asset.etfKey);
              }, variant: "quiet", children: "View" })
            ] }) })
          ] }, d.asset.etfKey)) })
        ] })
      ] }),
      l && /* @__PURE__ */ o("div", { className: "etf-workspace", children: [
        /* @__PURE__ */ o("div", { className: "panel etf-detail-card", children: [
          /* @__PURE__ */ o("div", { className: "detail-heading", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "Selected ETF" }),
              /* @__PURE__ */ o("h2", { children: [
                l.asset.symbol,
                " ",
                /* @__PURE__ */ t("span", { children: l.asset.name })
              ] })
            ] }),
            /* @__PURE__ */ o("div", { className: "row-actions", children: [
              /* @__PURE__ */ t(I, { onClick: () => {
                m();
              }, variant: "secondary", disabled: N, children: "↻ Refresh" }),
              l.snapshot && /* @__PURE__ */ t(I, { onClick: p, variant: "quiet", children: "Export CSV" }),
              l.snapshot && /* @__PURE__ */ t(I, { onClick: () => {
                l && a(l.asset.etfKey);
              }, variant: "danger", children: "Disable snapshot" })
            ] })
          ] }),
          l.snapshot ? /* @__PURE__ */ o("div", { className: "snapshot-meta", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "Provider" }),
              /* @__PURE__ */ t("strong", { children: l.snapshot.provider })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "As of" }),
              /* @__PURE__ */ t("strong", { children: l.snapshot.asOfDate })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "Fetched" }),
              /* @__PURE__ */ t("strong", { children: new Date(l.snapshot.fetchedAt).toLocaleString() })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "Weight outcome" }),
              /* @__PURE__ */ t("strong", { children: l.snapshot.normalized ? "Normalized" : l.snapshot.weightSum < 1 ? `${K(1 - l.snapshot.weightSum)} residual` : "100% resolved" })
            ] })
          ] }) : /* @__PURE__ */ o("div", { className: "missing-inline", children: [
            /* @__PURE__ */ t(R, { value: "Missing", tone: "warning" }),
            /* @__PURE__ */ t("span", { children: "No valid snapshot yet. Paste the issuer holdings CSV to preserve the ETF as an opaque exposure until resolved." })
          ] }),
          l.snapshot && /* @__PURE__ */ o("div", { className: "underlying-preview", children: [
            /* @__PURE__ */ t("span", { className: "eyebrow", children: "Current constituents" }),
            /* @__PURE__ */ t("div", { className: "mini-constituents", children: l.snapshot.holdings.slice(0, 8).map((d) => /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { children: d.symbol ?? "—" }),
              /* @__PURE__ */ t("strong", { children: d.name }),
              /* @__PURE__ */ t("em", { children: K(d.weight) })
            ] }, `${d.symbol}-${d.name}`)) }),
            l.snapshot.holdings.length > 8 && /* @__PURE__ */ o("span", { className: "muted", children: [
              "+ ",
              l.snapshot.holdings.length - 8,
              " more retained in the snapshot"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "panel csv-card", children: [
          /* @__PURE__ */ o("div", { className: "detail-heading", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ t("span", { className: "eyebrow", children: "Universal fallback" }),
              /* @__PURE__ */ t("h2", { children: "Import or paste CSV" }),
              /* @__PURE__ */ o("p", { children: [
                "Required: ",
                /* @__PURE__ */ t("code", { children: "symbol" }),
                " or ",
                /* @__PURE__ */ t("code", { children: "name" }),
                ", plus ",
                /* @__PURE__ */ t("code", { children: "weight" }),
                ". Fractional values, percentages, and bare percentages are previewed before saving."
              ] })
            ] }),
            /* @__PURE__ */ o("label", { className: "file-button", children: [
              "Choose file",
              /* @__PURE__ */ t("input", { type: "file", accept: ".csv,text/csv", onChange: (d) => v(d.target.files?.[0]) })
            ] })
          ] }),
          /* @__PURE__ */ t("textarea", { value: c, onChange: (d) => u(d.target.value), placeholder: `symbol,name,weight,isin,mic,country,currency,sector,assetClass
NVDA,NVIDIA Corp,0.084,US67066G1040,XNAS,US,USD,Technology,Equity`, rows: 8 }),
          /* @__PURE__ */ o("div", { className: "form-actions", children: [
            /* @__PURE__ */ t(I, { onClick: h, variant: "secondary", disabled: !c.trim(), children: "Preview" }),
            f?.validation.accepted && /* @__PURE__ */ t(I, { onClick: () => {
              D();
            }, variant: "primary", disabled: N, children: N ? "Saving…" : "Save Manual Snapshot" })
          ] }),
          f && /* @__PURE__ */ t(It, { preview: f }),
          k && /* @__PURE__ */ t("div", { className: "inline-message", children: k })
        ] })
      ] })
    ] }) : /* @__PURE__ */ t(j, { icon: "◫", title: "No ETFs in the selected accounts", detail: "ETF Data appears when Wealthfolio reports an ETF holding. Direct securities do not need constituent data." })
  ] });
}
function Et(e) {
  return e === "Fresh" ? "good" : e === "Critical" || e === "Invalid" ? "critical" : e === "Missing" || e === "Warning" || e === "Stale" ? "warning" : "neutral";
}
function It({ preview: e }) {
  return /* @__PURE__ */ o("div", { className: "csv-preview", children: [
    /* @__PURE__ */ o("div", { className: "preview-summary", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("span", { className: "eyebrow", children: "Parsed rows" }),
        /* @__PURE__ */ t("strong", { children: e.rows.length })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("span", { className: "eyebrow", children: "Detected unit" }),
        /* @__PURE__ */ t("strong", { children: e.detectedUnit })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("span", { className: "eyebrow", children: "Weight sum" }),
        /* @__PURE__ */ t("strong", { children: K(e.weightSum) })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ t("span", { className: "eyebrow", children: "Outcome" }),
        /* @__PURE__ */ t(R, { value: e.validation.status, tone: e.validation.accepted ? "good" : "critical" })
      ] })
    ] }),
    e.missingFields.length > 0 && /* @__PURE__ */ o("p", { className: "preview-error", children: [
      "Missing columns: ",
      e.missingFields.join(", ")
    ] }),
    e.issues.length > 0 && /* @__PURE__ */ t("p", { className: "preview-warning", children: e.issues.join(" ") }),
    e.validation.message && /* @__PURE__ */ t("p", { className: e.validation.accepted ? "preview-note" : "preview-error", children: e.validation.message }),
    /* @__PURE__ */ t("div", { className: "preview-table", children: /* @__PURE__ */ o("table", { children: [
      /* @__PURE__ */ t("thead", { children: /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ t("th", { children: "Symbol" }),
        /* @__PURE__ */ t("th", { children: "Name" }),
        /* @__PURE__ */ t("th", { children: "Weight" }),
        /* @__PURE__ */ t("th", { children: "Country" }),
        /* @__PURE__ */ t("th", { children: "Sector" })
      ] }) }),
      /* @__PURE__ */ t("tbody", { children: e.rows.slice(0, 12).map((n, i) => /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ t("td", { children: n.symbol ?? "—" }),
        /* @__PURE__ */ t("td", { children: n.name }),
        /* @__PURE__ */ t("td", { children: K(n.weight) }),
        /* @__PURE__ */ t("td", { children: n.country ?? "—" }),
        /* @__PURE__ */ t("td", { children: n.sector ?? "—" })
      ] }, `${n.symbol}-${n.name}-${i}`)) })
    ] }) })
  ] });
}
const Tt = ["stock", "etf", "cash", "fixed-income", "derivative", "other", "unknown"];
function $t({
  activeAccounts: e,
  selectedAccounts: n,
  settings: i,
  holdings: a,
  etfData: s,
  hasTwelveDataKey: r,
  hasAlphaVantageKey: c,
  onSaveAccountSelection: u,
  onSaveSecret: f,
  onDeleteSecret: x,
  onSetLiveFxPolling: N,
  onSetTypeOverride: b,
  onSetProviderMode: k,
  onSetPinnedProvider: A
}) {
  const [l, h] = $(n.map((g) => g.id)), [D, m] = $(""), [p, v] = $(""), [d, S] = $(null);
  L(() => h(n.map((g) => g.id)), [n]);
  const y = async () => {
    await u(l), S("Account selection saved.");
  }, w = async (g, C, V) => {
    await f(g, C), S(`${V} key saved securely through Wealthfolio.`), g.includes("twelvedata") ? m("") : v("");
  }, T = async (g, C) => {
    await x(g), S(`${C} key removed.`);
  }, P = a.filter((g) => g.status === "unknown-instrument" || g.type === "unknown");
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ t(X, { eyebrow: "Addon-owned preferences", title: "Settings", detail: "Only Portfolio X-Ray configuration lives here. Wealthfolio remains the source of truth for accounts, holdings, prices, and performance." }),
    /* @__PURE__ */ o("div", { className: "settings-grid", children: [
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ t("div", { className: "settings-icon", children: "◎" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("h2", { children: "Included accounts" }),
            /* @__PURE__ */ t("p", { children: "New active accounts are included once. Explicit deselections remain deselected." })
          ] })
        ] }),
        /* @__PURE__ */ t("div", { className: "account-select-list", children: e.length === 0 ? /* @__PURE__ */ t("p", { className: "muted", children: "No active Wealthfolio accounts found." }) : e.map((g) => /* @__PURE__ */ o("label", { className: "account-select", children: [
          /* @__PURE__ */ t("input", { type: "checkbox", checked: l.includes(g.id), onChange: (C) => h((V) => C.target.checked ? [...V, g.id] : V.filter((W) => W !== g.id)) }),
          /* @__PURE__ */ t("span", { className: "account-avatar", children: g.name.slice(0, 1).toUpperCase() }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ t("strong", { children: g.name }),
            /* @__PURE__ */ o("em", { children: [
              g.currency,
              " · ",
              g.isActive ? "Active" : "Inactive"
            ] })
          ] }),
          /* @__PURE__ */ t("span", { className: "checkmark", children: "✓" })
        ] }, g.id)) }),
        /* @__PURE__ */ t("div", { className: "form-actions", children: /* @__PURE__ */ t(I, { onClick: () => {
          y();
        }, variant: "primary", children: "Save account selection" }) })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ t("div", { className: "settings-icon", children: "↗" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("h2", { children: "Live USD / AUD" }),
            /* @__PURE__ */ t("p", { children: "Refresh while Portfolio X-Ray is visible. The quote is shared through addon storage for five-minute reuse." })
          ] })
        ] }),
        /* @__PURE__ */ t($e, { checked: i.liveFxPolling, onChange: (g) => {
          N(g);
        }, label: "Enable visible-page polling" }),
        /* @__PURE__ */ o("div", { className: "privacy-note", children: [
          /* @__PURE__ */ t("span", { className: "pulse-dot" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("strong", { children: "Provider-safe request" }),
            /* @__PURE__ */ t("p", { children: "External requests include only USD/AUD and provider authentication — never account, quantity, value, cost basis, or transaction data." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ t("div", { className: "settings-icon", children: "⌘" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("h2", { children: "Provider keys" }),
            /* @__PURE__ */ o("p", { children: [
              "Optional keys are stored through ",
              /* @__PURE__ */ t("code", { children: "ctx.api.secrets" }),
              ". Missing keys never block cached or Manual CSV data."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ t(ce, { label: "Twelve Data", hasKey: r, value: D, onChange: m, onSave: () => {
          w("twelvedata.apiKey", D, "Twelve Data");
        }, onRemove: () => {
          T("twelvedata.apiKey", "Twelve Data");
        } }),
        /* @__PURE__ */ t(ce, { label: "Alpha Vantage", hasKey: c, value: p, onChange: v, onSave: () => {
          w("alphaVantage.apiKey", p, "Alpha Vantage");
        }, onRemove: () => {
          T("alphaVantage.apiKey", "Alpha Vantage");
        } })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ t("div", { className: "settings-icon", children: "◫" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("h2", { children: "ETF provider modes" }),
            /* @__PURE__ */ t("p", { children: "Auto follows cache → issuer → Alpha Vantage → Manual. Pinned mode never silently changes source." })
          ] })
        ] }),
        s.length === 0 ? /* @__PURE__ */ t("p", { className: "muted", children: "ETF provider controls appear when ETFs are held." }) : /* @__PURE__ */ t("div", { className: "provider-list", children: s.map((g) => /* @__PURE__ */ o("div", { className: "provider-row", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("strong", { children: g.asset.symbol }),
            /* @__PURE__ */ t("span", { children: g.snapshot?.provider ?? "No snapshot" })
          ] }),
          /* @__PURE__ */ o("select", { value: i.providerModes[g.asset.etfKey] ?? "auto", onChange: (C) => {
            k(g.asset.etfKey, C.target.value);
          }, children: [
            /* @__PURE__ */ t("option", { value: "auto", children: "Auto" }),
            /* @__PURE__ */ t("option", { value: "pinned", children: "Pinned" })
          ] }),
          (i.providerModes[g.asset.etfKey] ?? "auto") === "pinned" && /* @__PURE__ */ o("select", { value: i.pinnedProviders[g.asset.etfKey] ?? "alpha-vantage", onChange: (C) => {
            A(g.asset.etfKey, C.target.value);
          }, children: [
            /* @__PURE__ */ t("option", { value: "ishares", children: "iShares" }),
            /* @__PURE__ */ t("option", { value: "betashares", children: "Betashares" }),
            /* @__PURE__ */ t("option", { value: "alpha-vantage", children: "Alpha Vantage" })
          ] }),
          /* @__PURE__ */ t(R, { value: g.status, tone: g.status === "Fresh" ? "good" : "warning" })
        ] }, g.asset.etfKey)) })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ t("div", { className: "settings-icon", children: "⌁" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("h2", { children: "Type overrides" }),
            /* @__PURE__ */ t("p", { children: "Use a local override when an instrument profile is unresolved. Overrides affect only X-Ray classification." })
          ] })
        ] }),
        P.length === 0 ? /* @__PURE__ */ t("p", { className: "muted", children: "All current instrument types are resolved." }) : /* @__PURE__ */ t("div", { className: "override-list", children: P.map((g) => /* @__PURE__ */ o("div", { className: "override-row", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ t("strong", { children: g.ticker }),
            /* @__PURE__ */ o("span", { children: [
              g.name,
              " · ",
              g.identityKey ?? g.id
            ] })
          ] }),
          /* @__PURE__ */ t("select", { value: i.typeOverrides[g.profileId ?? g.identityKey ?? g.id] ?? g.type, onChange: (C) => {
            b(g.profileId ?? g.identityKey ?? g.id, C.target.value);
          }, children: Tt.map((C) => /* @__PURE__ */ t("option", { value: C, children: C }, C)) })
        ] }, g.id)) })
      ] })
    ] }),
    d && /* @__PURE__ */ t("div", { className: "inline-message", children: d }),
    /* @__PURE__ */ o("div", { className: "settings-footer", children: [
      /* @__PURE__ */ t(R, { value: "Local-first", tone: "good" }),
      /* @__PURE__ */ t("span", { children: "Settings, aliases, Manual datasets, and valid ETF caches are persisted through Wealthfolio addon storage. Secrets never enter JSON, localStorage, or source code." })
    ] })
  ] });
}
function ce({ label: e, hasKey: n, value: i, onChange: a, onSave: s, onRemove: r }) {
  return /* @__PURE__ */ o("div", { className: "secret-field", children: [
    /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ t("span", { children: e }),
      /* @__PURE__ */ t("span", { className: n ? "secret-status secret-set" : "secret-status", children: n ? "Configured" : "Not configured" })
    ] }),
    /* @__PURE__ */ o("div", { className: "secret-input-row", children: [
      /* @__PURE__ */ t("input", { type: "password", value: i, onChange: (c) => a(c.target.value), placeholder: n ? "Enter a new key to replace" : "Paste optional API key", autoComplete: "off" }),
      /* @__PURE__ */ t(I, { onClick: s, variant: "secondary", disabled: !i.trim(), children: "Save" }),
      n && /* @__PURE__ */ t(I, { onClick: r, variant: "quiet", children: "Remove" })
    ] })
  ] });
}
function Ut({ ctx: e }) {
  const [n, i] = $("overview"), a = xt(e), s = () => {
    e.api.navigation.navigate("/performance").catch((c) => {
      e.api.toast.error(c instanceof Error ? c.message : "Unable to open Wealthfolio Performance");
    });
  }, r = a.loading && !a.lastLoadedAt ? /* @__PURE__ */ o("div", { className: "loading-state", children: [
    /* @__PURE__ */ t("div", { className: "loading-orbit", children: "X" }),
    /* @__PURE__ */ t("h2", { children: "Reading Wealthfolio" }),
    /* @__PURE__ */ t("p", { children: "Loading selected accounts, current values, and cached ETF data…" })
  ] }) : a.error && !a.lastLoadedAt ? /* @__PURE__ */ o("div", { className: "error-state", children: [
    /* @__PURE__ */ t("div", { className: "empty-icon", children: "!" }),
    /* @__PURE__ */ t("h2", { children: "Portfolio X-Ray could not load" }),
    /* @__PURE__ */ t("p", { children: a.error }),
    /* @__PURE__ */ t(I, { onClick: () => {
      a.refresh();
    }, variant: "primary", children: "Retry" })
  ] }) : /* @__PURE__ */ o(Z, { children: [
    a.error && /* @__PURE__ */ o("div", { className: "global-error", children: [
      /* @__PURE__ */ t("span", { children: "!" }),
      a.error,
      /* @__PURE__ */ t("button", { onClick: () => {
        a.refresh();
      }, children: "Retry" })
    ] }),
    n === "overview" && /* @__PURE__ */ t(wt, { ctx: e, portfolio: a.portfolio, exposure: a.exposure, fxQuote: a.fxQuote, etfData: a.etfData, baseCurrency: a.baseCurrency, selectedAccounts: a.selectedAccounts, newlyIncludedAccounts: a.newlyIncludedAccounts, onNavigatePerformance: s, onRefreshFx: () => {
      a.refresh({ forceFx: !0 });
    }, onGoToSettings: () => i("settings") }),
    n === "holdings" && /* @__PURE__ */ t(kt, { portfolio: a.portfolio, onGoToSettings: () => i("settings") }),
    n === "xray" && /* @__PURE__ */ t(At, { exposure: a.exposure, hasHoldings: a.portfolio.holdings.length > 0, onGoToSettings: () => i("settings") }),
    n === "etf-data" && /* @__PURE__ */ t(Dt, { etfData: a.etfData, onRefreshEtf: a.refreshEtf, onSaveSnapshot: a.saveSnapshot, onDisableSnapshot: a.disableSnapshot }),
    n === "settings" && /* @__PURE__ */ t($t, { activeAccounts: a.activeAccounts, selectedAccounts: a.selectedAccounts, settings: a.settings, holdings: a.holdings, etfData: a.etfData, hasTwelveDataKey: a.hasTwelveDataKey, hasAlphaVantageKey: a.hasAlphaVantageKey, onSaveAccountSelection: a.saveAccountSelection, onSaveSecret: a.saveSecret, onDeleteSecret: a.deleteSecret, onSetLiveFxPolling: a.setLiveFxPolling, onSetTypeOverride: a.setTypeOverride, onSetProviderMode: a.setProviderMode, onSetPinnedProvider: a.setPinnedProvider })
  ] });
  return /* @__PURE__ */ t(De, { page: n, onPageChange: i, accounts: a.selectedAccounts, children: r });
}
const Ft = '*{box-sizing:border-box}.app-shell{--ink: #e9eef7;--muted: #8794aa;--faint: #5f6c80;--surface: #121a28;--surface-2: #182235;--surface-3: #202d43;--line: rgba(155, 177, 212, .14);--line-strong: rgba(155, 177, 212, .24);--green: #65d6a7;--blue: #7ca7ff;--yellow: #f8c86b;--red: #ff887d;--purple: #d08dff;min-height:100vh;display:flex;background:#0c1320;color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;font-size:14px;line-height:1.45}.app-shell button,.app-shell input,.app-shell select,.app-shell textarea{font:inherit}.app-shell button{cursor:pointer}.app-shell button:disabled{cursor:not-allowed;opacity:.48}.app-shell h1,.app-shell h2,.app-shell p{margin:0}.app-shell h1{font-size:29px;letter-spacing:-.035em;line-height:1.1}.app-shell h2{font-size:16px;letter-spacing:-.02em}.app-shell code{color:#c7d8ff;font-size:.9em}.muted{color:var(--muted)}.text-green{color:var(--green)!important}.text-warning{color:var(--yellow)!important}.visually-hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.sidebar{width:236px;flex:0 0 236px;min-height:100vh;padding:27px 16px 18px;border-right:1px solid var(--line);background:#0e1726;display:flex;flex-direction:column}.brand{display:flex;gap:11px;align-items:center;padding:0 11px 28px}.brand-mark{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;color:#092018;font-weight:800;background:linear-gradient(135deg,#8de6c1,#56b8cf);box-shadow:0 0 0 4px #65d6a714}.brand strong{display:block;font-size:13px;letter-spacing:-.01em}.brand span{display:block;color:var(--faint);font-size:11px;margin-top:1px}.main-nav{display:grid;gap:4px}.nav-item{width:100%;border:0;border-radius:9px;background:transparent;color:var(--muted);padding:10px 12px;text-align:left;display:flex;gap:12px;align-items:center;transition:.15s ease}.nav-item:hover{background:#7ca7ff14;color:var(--ink)}.nav-active{color:var(--ink);background:linear-gradient(90deg,#65d6a726,#65d6a70a);box-shadow:inset 2px 0 var(--green)}.nav-icon{width:16px;text-align:center;color:var(--faint);font-size:16px}.nav-active .nav-icon{color:var(--green)}.sidebar-bottom{margin-top:auto;display:grid;gap:12px}.account-summary{margin:4px 7px 0;padding:14px;border:1px solid var(--line);background:#ffffff06;border-radius:12px}.account-summary strong{display:block;font-size:23px;line-height:1.1;margin:4px 0 2px}.account-summary>span:last-child{color:var(--muted);font-size:11px}.local-first{color:var(--faint);font-size:11px;padding:0 11px;display:flex;gap:7px;align-items:center}.pulse-dot,.quote-live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);display:inline-block;box-shadow:0 0 0 4px #65d6a71a}.main-content{width:calc(100% - 236px);min-width:0;background:radial-gradient(circle at 80% -15%,rgba(65,103,162,.13),transparent 35%),#0c1320}.page-stack{max-width:1440px;margin:0 auto;padding:36px 42px 54px;display:grid;gap:22px}.section-header{display:flex;justify-content:space-between;gap:20px;align-items:flex-end;padding-bottom:5px}.section-header h1{margin-top:5px}.section-header p{color:var(--muted);margin-top:8px}.eyebrow{display:block;color:var(--faint);text-transform:uppercase;font-size:10px;font-weight:700;letter-spacing:.12em}.button{border:1px solid transparent;border-radius:8px;padding:8px 12px;color:var(--ink);white-space:nowrap;transition:.15s ease}.button-primary{color:#082018;background:var(--green);border-color:var(--green);font-weight:700}.button-primary:hover{background:#8ce6c0}.button-secondary{background:var(--surface-3);border-color:var(--line-strong)}.button-secondary:hover,.button-quiet:hover{border-color:#7ca7ff8c;background:#7ca7ff1a}.button-quiet{background:transparent;color:#a8bff3;border-color:var(--line)}.button-danger{background:#ff887d12;color:var(--red);border-color:#ff887d3b}.data-source-pill,.coverage-pill{display:inline-flex;gap:8px;align-items:center;border:1px solid var(--line);border-radius:999px;color:var(--muted);padding:7px 11px;font-size:11px}.coverage-pill{gap:9px;padding:8px 13px}.coverage-pill strong{color:var(--green);font-size:15px}.metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metric-card,.panel{background:linear-gradient(145deg,#1a2639eb,#0f1827f5);border:1px solid var(--line);border-radius:13px}.metric-card{min-height:143px;padding:17px 18px 15px;position:relative;overflow:hidden}.metric-card:after{content:"";position:absolute;width:100px;height:100px;right:-45px;bottom:-50px;border-radius:50%;background:#65d6a714}.metric-card-top{display:flex;gap:9px;align-items:center}.metric-icon{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;color:var(--green);background:#65d6a71a;font-size:14px}.metric-blue .metric-icon{color:var(--blue);background:#7ca7ff1a}.metric-purple .metric-icon{color:var(--purple);background:#d08dff1a}.metric-warning .metric-icon{color:var(--yellow);background:#f8c86b1a}.metric-value{margin-top:21px;font-size:27px;font-weight:700;letter-spacing:-.04em}.metric-detail{color:var(--muted);font-size:11px;margin-top:5px}.quote-strip{display:flex;align-items:center;gap:9px;color:var(--muted);font-size:11px;border:1px solid var(--line);border-radius:9px;padding:9px 12px;background:#65d6a709}.quote-strip strong{color:var(--ink);font-size:12px}.quote-strip button{margin-left:auto;border:0;background:transparent;color:#a8bff3;font-size:11px}.warning-stack{display:grid;gap:8px}.warning-card{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:10px;padding:11px 13px;background:#f8c86b0b}.warning-card strong{font-size:12px}.warning-card p{margin-top:2px;color:var(--muted);font-size:12px}.warning-mark{flex:0 0 19px;width:19px;height:19px;border-radius:50%;display:grid;place-items:center;color:var(--yellow);background:#f8c86b21;font-weight:800;font-size:11px}.warning-critical{border-color:#ff887d33;background:#ff887d0b}.warning-critical .warning-mark{color:var(--red);background:#ff887d21}.warning-info{border-color:#7ca7ff33;background:#7ca7ff0b}.warning-info .warning-mark{color:var(--blue);background:#7ca7ff21}.chart-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.chart-panel{padding:19px;min-height:310px}.panel-heading,.table-toolbar,.detail-heading,.settings-heading{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.panel-heading p,.settings-heading p,.detail-heading p{color:var(--muted);font-size:12px;margin-top:4px}.chart-note{color:var(--faint);font-size:10px;border:1px solid var(--line);padding:4px 7px;border-radius:5px}.chart-list{margin-top:21px;display:grid;gap:12px}.chart-row-head{display:flex;align-items:center;gap:7px;font-size:12px}.legend-dot{width:7px;height:7px;border-radius:2px;flex:0 0 7px}.chart-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chart-value{margin-left:auto;color:var(--ink);font-weight:700}.chart-track{height:5px;margin-top:7px;background:#ffffff0f;border-radius:5px;overflow:hidden}.chart-track span{display:block;height:100%;min-width:3px;border-radius:inherit}.chart-meta{display:flex;gap:7px;color:var(--faint);font-size:10px;margin-top:4px}.chart-meta strong{margin-left:auto;color:var(--muted);font-weight:600}.empty-chart{min-height:210px;display:grid;place-items:center;color:var(--muted)}.insight-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}.insight-card{display:flex;gap:12px;padding:16px}.insight-icon{width:29px;height:29px;border-radius:9px;flex:0 0 29px;display:grid;place-items:center;color:var(--green);background:#65d6a71a}.insight-card strong{display:block;margin-top:3px}.insight-card p{color:var(--muted);font-size:11px;margin:4px 0 9px}.page-footnote{display:flex;align-items:center;gap:8px;color:var(--faint);font-size:11px}.table-panel{overflow:hidden}.table-toolbar{padding:17px 19px;align-items:center;border-bottom:1px solid var(--line)}.table-toolbar strong{display:block}.table-toolbar span{display:block;color:var(--muted);font-size:11px;margin-top:3px}.table-toolbar-note{color:var(--faint)!important;margin-top:0!important;text-align:right}.table-shell{overflow-x:auto}.table-shell table{width:100%;border-collapse:collapse;font-size:12px;min-width:1100px}.table-shell th{color:var(--faint);text-transform:uppercase;letter-spacing:.09em;font-size:9px;font-weight:700;text-align:left;padding:11px 14px;background:#070e1940;white-space:nowrap}.table-shell td{border-top:1px solid rgba(155,177,212,.09);padding:13px 14px;color:var(--muted);vertical-align:middle;white-space:nowrap}.table-shell tbody tr{transition:background .12s ease}.table-shell tbody tr:hover,.table-shell tbody tr.row-selected{background:#7ca7ff0e}.numeric{text-align:right!important}.ticker-cell{color:var(--ink);letter-spacing:.025em}.name-cell{color:#b8c5d8;max-width:185px;display:inline-block;overflow:hidden;text-overflow:ellipsis;vertical-align:bottom}.account-cell{display:inline-flex;gap:7px;align-items:center;color:#b8c5d8}.account-avatar{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:7px;background:#263550;color:#a9c3f5;font-size:10px;font-weight:700}.type-label,.currency-label{color:#9eafd0;text-transform:capitalize}.value-strong{color:var(--ink)!important;font-weight:600}.date-cell{color:var(--faint);font-size:11px}.status-badge{display:inline-flex;border-radius:999px;padding:4px 7px;text-transform:capitalize;color:var(--muted);background:#9bb1d41a;font-size:10px;line-height:1;white-space:nowrap}.status-good,.status-valued,.status-fresh,.status-accepted{color:var(--green);background:#65d6a71a}.status-warning,.status-stale,.status-residual,.status-missing{color:var(--yellow);background:#f8c86b1a}.status-critical,.status-unsupported-currency,.status-unsupported-position,.status-rejected,.status-invalid{color:var(--red);background:#ff887d1a}.status-normalized{color:var(--blue);background:#7ca7ff1a}.row-actions{display:flex;gap:5px}.row-actions .button{padding:5px 7px;font-size:11px}.source-button{border:0;background:transparent;color:#a8bff3;padding:0;display:inline-flex;gap:6px;align-items:center}.source-count{display:grid;place-items:center;width:20px;height:20px;border-radius:6px;background:#7ca7ff1f;color:var(--blue);font-size:10px}.table-subtext{display:block;max-width:160px;overflow:hidden;text-overflow:ellipsis;color:var(--faint);font-size:10px;margin-top:2px}.xray-summary{display:grid;grid-template-columns:1fr 1fr;gap:12px}.xray-summary>div{border:1px solid var(--line);border-radius:10px;padding:14px 16px;background:#65d6a709}.xray-summary strong{display:block;margin-top:4px;font-size:20px;letter-spacing:-.03em}.xray-summary span:last-child{display:block;color:var(--muted);font-size:11px;margin-top:2px}.source-drawer{padding:20px}.drawer-head{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:16px;border-bottom:1px solid var(--line)}.drawer-head h2{margin-top:3px}.drawer-head strong{display:block;margin-top:4px;font-size:22px;color:var(--green)}.source-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;padding-top:18px}.source-group{display:grid;gap:8px;align-content:start}.source-line{display:flex;justify-content:space-between;gap:10px;color:var(--muted);font-size:12px;border-bottom:1px dashed var(--line);padding-bottom:7px}.source-line strong{color:var(--ink);font-weight:600}.etf-workspace{display:grid;grid-template-columns:1fr 1fr;gap:14px}.etf-detail-card,.csv-card{padding:19px;min-width:0}.detail-heading h2{margin-top:4px}.detail-heading h2 span{color:var(--muted);font-weight:400;font-size:13px}.snapshot-meta{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:16px 0;margin-top:14px;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}.snapshot-meta strong{display:block;font-size:12px;margin-top:3px;color:#c3d0e2}.missing-inline{display:flex;gap:9px;align-items:center;margin-top:19px;padding:10px;border-radius:8px;background:#f8c86b0e;color:var(--muted);font-size:12px}.underlying-preview{padding-top:16px}.mini-constituents{display:grid;gap:5px;margin-top:9px}.mini-constituents>div{display:grid;grid-template-columns:48px minmax(0,1fr) 43px;gap:7px;align-items:center;padding:5px 0;border-bottom:1px solid rgba(155,177,212,.08);font-size:11px}.mini-constituents span{color:#a8bff3}.mini-constituents strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted);font-weight:500}.mini-constituents em{text-align:right;color:var(--ink);font-style:normal}.file-button{display:inline-flex;align-items:center;border:1px solid var(--line-strong);color:#a8bff3;background:var(--surface-3);border-radius:8px;padding:8px 11px;cursor:pointer;font-size:11px}.file-button input{display:none}.csv-card textarea{resize:vertical;width:100%;margin-top:17px;padding:12px;min-height:162px;color:#c6d5eb;background:#0c1421;border:1px solid var(--line-strong);border-radius:8px;outline:0;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}.csv-card textarea:focus{border-color:#7ca7ffb3;box-shadow:0 0 0 3px #7ca7ff14}.form-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}.csv-preview{margin-top:16px;padding-top:15px;border-top:1px solid var(--line)}.preview-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.preview-summary strong{display:block;color:var(--ink);font-size:14px;margin-top:3px}.preview-error,.preview-warning,.preview-note{border-radius:7px;padding:8px 10px;margin-top:10px!important;font-size:11px}.preview-error{color:var(--red);background:#ff887d12}.preview-warning{color:var(--yellow);background:#f8c86b12}.preview-note{color:var(--green);background:#65d6a712}.preview-table{overflow-x:auto;margin-top:12px;max-height:240px}.preview-table table{width:100%;border-collapse:collapse;font-size:11px}.preview-table th{color:var(--faint);text-align:left;font-size:9px;text-transform:uppercase;padding:7px 5px}.preview-table td{border-top:1px solid var(--line);padding:7px 5px;color:var(--muted);white-space:nowrap}.inline-message{color:var(--green);border:1px solid rgba(101,214,167,.2);background:#65d6a70f;border-radius:8px;padding:9px 11px;font-size:12px}.settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.settings-card{padding:19px;min-width:0}.settings-heading{align-items:flex-start}.settings-heading>div:last-child{flex:1}.settings-icon{width:29px;height:29px;border-radius:8px;display:grid;place-items:center;flex:0 0 29px;color:var(--blue);background:#7ca7ff1c}.account-select-list{display:grid;gap:6px;margin-top:17px}.account-select{display:flex;align-items:center;gap:9px;padding:9px;border:1px solid var(--line);border-radius:8px;cursor:pointer}.account-select:hover{border-color:var(--line-strong);background:#ffffff05}.account-select input{accent-color:var(--green)}.account-select>span:nth-of-type(2){display:grid}.account-select strong{font-size:12px}.account-select em{color:var(--faint);font-size:10px;font-style:normal;margin-top:1px}.checkmark{margin-left:auto;color:var(--green);opacity:0}.account-select input:checked~.checkmark{opacity:1}.privacy-note{display:flex;gap:10px;align-items:flex-start;margin-top:20px;padding:11px;border-radius:8px;border:1px solid rgba(101,214,167,.16);background:#65d6a70b}.privacy-note p{color:var(--muted);font-size:11px;margin-top:3px}.toggle-row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:19px;color:#b9c6d9;font-size:12px}.toggle{width:36px;height:20px;padding:2px;border-radius:999px;border:0;background:#324158;text-align:left}.toggle span{width:16px;height:16px;display:block;border-radius:50%;background:#8b98aa;transition:.15s ease}.toggle-on{background:#65d6a773}.toggle-on span{transform:translate(16px);background:var(--green)}.secret-field{margin-top:17px}.secret-field label{display:flex;justify-content:space-between;color:#b8c5d8;font-size:11px}.secret-status{color:var(--faint);font-size:10px}.secret-set{color:var(--green)}.secret-input-row{display:flex;gap:6px;margin-top:6px}.secret-input-row input{min-width:0;flex:1;color:var(--ink);background:#0c1421;border:1px solid var(--line-strong);border-radius:7px;padding:8px 9px;outline:0}.secret-input-row input:focus{border-color:#7ca7ffb3}.secret-input-row .button{padding:7px 9px;font-size:11px}.provider-list,.override-list{display:grid;gap:7px;margin-top:17px}.provider-row,.override-row{display:flex;align-items:center;gap:7px;padding:9px;border:1px solid var(--line);border-radius:8px}.provider-row>div:first-child,.override-row>div:first-child{min-width:0;margin-right:auto;display:grid}.provider-row strong,.override-row strong{font-size:12px}.provider-row span,.override-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--faint);font-size:10px}.provider-row select,.override-row select{color:#c2d0e4;background:var(--surface-3);border:1px solid var(--line-strong);border-radius:6px;padding:6px;font-size:11px}.settings-footer{color:var(--faint);display:flex;gap:8px;align-items:center;font-size:11px}.empty-state,.loading-state,.error-state{min-height:380px;display:grid;place-items:center;align-content:center;text-align:center;border:1px dashed var(--line-strong);border-radius:13px;padding:30px}.empty-icon{width:52px;height:52px;display:grid;place-items:center;border-radius:16px;color:var(--green);background:#65d6a71a;font-size:26px;margin-bottom:14px}.empty-state h2,.loading-state h2,.error-state h2{font-size:18px}.empty-state p,.loading-state p,.error-state p{max-width:420px;color:var(--muted);margin:7px 0 16px}.loading-orbit{width:52px;height:52px;display:grid;place-items:center;color:#082018;background:var(--green);border-radius:16px;font-weight:800;animation:orbit 1.35s ease-in-out infinite;margin-bottom:15px}@keyframes orbit{0%,to{transform:translateY(0) rotate(-5deg)}50%{transform:translateY(-5px) rotate(5deg)}}.global-error{margin:0 0 -7px;color:var(--red);background:#ff887d14;border:1px solid rgba(255,136,125,.2);border-radius:8px;padding:9px 11px;font-size:12px;display:flex;gap:8px;align-items:center}.global-error span{width:17px;height:17px;display:grid;place-items:center;border-radius:50%;background:#ff887d2b}.global-error button{margin-left:auto;color:#ffb3aa;background:transparent;border:0;font-size:11px}@media(max-width:1100px){.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.etf-workspace,.settings-grid{grid-template-columns:1fr}}@media(max-width:760px){.app-shell{display:block}.sidebar{width:100%;min-height:auto;padding:14px;border-right:0;border-bottom:1px solid var(--line)}.brand{padding:0 5px 12px}.main-nav{display:flex;overflow-x:auto}.nav-item{width:auto;white-space:nowrap;padding:8px 10px}.sidebar-bottom{margin-top:8px;display:flex;align-items:center}.sidebar-bottom>.nav-item{width:auto}.account-summary,.local-first{display:none}.main-content{width:100%}.page-stack{padding:23px 16px 38px}.section-header{align-items:flex-start;flex-direction:column}.metric-grid,.chart-grid,.insight-row,.xray-summary,.source-columns{grid-template-columns:1fr}.metric-card{min-height:125px}.snapshot-meta,.preview-summary{grid-template-columns:repeat(2,1fr)}}';
function zt(e) {
  if (e.querySelector("style[data-portfolio-xray]")) return () => {
  };
  const i = e.createElement("style");
  return i.dataset.portfolioXray = "true", i.textContent = Ft, e.head.appendChild(i), () => i.remove();
}
const Rt = (e) => {
  const n = zt(e.ui.root.ownerDocument);
  return e.router.add({
    id: "portfolio-xray",
    path: "",
    component: () => /* @__PURE__ */ t(Ut, { ctx: e })
  }), { disable: n };
};
export {
  Rt as default,
  Rt as enable
};
//# sourceMappingURL=addon.js.map
