import { jsxs as o, jsx as n, Fragment as ce } from "react/jsx-runtime";
import { useState as $, useRef as Oe, useCallback as F, useEffect as B, useMemo as We } from "react";
const qe = [
  { id: "overview", label: "Overview", icon: "◈" },
  { id: "holdings", label: "Holdings", icon: "▤" },
  { id: "xray", label: "X-Ray", icon: "⌁" },
  { id: "etf-data", label: "ETF Data", icon: "◫" }
];
function Le({ page: e, onPageChange: t, accounts: i, children: a }) {
  return /* @__PURE__ */ o("div", { className: "app-shell", children: [
    /* @__PURE__ */ o("aside", { className: "sidebar", children: [
      /* @__PURE__ */ o("div", { className: "brand", children: [
        /* @__PURE__ */ n("div", { className: "brand-mark", children: "X" }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ n("strong", { children: "Portfolio X-Ray" }),
          /* @__PURE__ */ n("span", { children: "Wealthfolio addon" })
        ] })
      ] }),
      /* @__PURE__ */ n("nav", { className: "main-nav", "aria-label": "Portfolio X-Ray pages", children: qe.map((s) => /* @__PURE__ */ o("button", { className: `nav-item ${e === s.id ? "nav-active" : ""}`, onClick: () => t(s.id), children: [
        /* @__PURE__ */ n("span", { className: "nav-icon", children: s.icon }),
        s.label
      ] }, s.id)) }),
      /* @__PURE__ */ o("div", { className: "sidebar-bottom", children: [
        /* @__PURE__ */ o("button", { className: `nav-item ${e === "settings" ? "nav-active" : ""}`, onClick: () => t("settings"), children: [
          /* @__PURE__ */ n("span", { className: "nav-icon", children: "⚙" }),
          "Settings"
        ] }),
        /* @__PURE__ */ o("div", { className: "account-summary", children: [
          /* @__PURE__ */ n("span", { className: "eyebrow", children: "Included accounts" }),
          /* @__PURE__ */ n("strong", { children: i.length }),
          /* @__PURE__ */ n("span", { children: i.length === 1 ? "account selected" : "accounts selected" })
        ] }),
        /* @__PURE__ */ o("div", { className: "local-first", children: [
          /* @__PURE__ */ n("span", { className: "pulse-dot" }),
          "Local-first data"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ n("main", { className: "main-content", children: a })
  ] });
}
function U(e) {
  return e == null || !Number.isFinite(e) ? "Incomplete" : new Intl.NumberFormat("en-AU", { style: "currency", currency: "AUD", maximumFractionDigits: 2 }).format(e);
}
function je(e, t) {
  if (e == null || !Number.isFinite(e)) return "—";
  try {
    return new Intl.NumberFormat("en-AU", { style: "currency", currency: t, maximumFractionDigits: 2 }).format(e);
  } catch {
    return `${t} ${e.toFixed(2)}`;
  }
}
function V(e) {
  return e == null || !Number.isFinite(e) ? "—" : `${(e * 100).toFixed(1)}%`;
}
function Xe(e) {
  return new Intl.NumberFormat("en-AU", { maximumFractionDigits: 6 }).format(e);
}
function q({ value: e, tone: t }) {
  return /* @__PURE__ */ n("span", { className: `status-badge status-${t ?? e.toLowerCase().replace(/\s+/g, "-")}`, children: e });
}
function ne({ label: e, value: t, detail: i, icon: a, tone: s }) {
  return /* @__PURE__ */ o("div", { className: `metric-card ${s ? `metric-${s}` : ""}`, children: [
    /* @__PURE__ */ o("div", { className: "metric-card-top", children: [
      /* @__PURE__ */ n("span", { className: "metric-icon", children: a }),
      /* @__PURE__ */ n("span", { className: "eyebrow", children: e })
    ] }),
    /* @__PURE__ */ n("div", { className: "metric-value", children: t }),
    i && /* @__PURE__ */ n("div", { className: "metric-detail", children: i })
  ] });
}
function He({ warnings: e }) {
  return e.length ? /* @__PURE__ */ n("div", { className: "warning-stack", children: e.map((t) => /* @__PURE__ */ o("div", { className: `warning-card warning-${t.severity}`, children: [
    /* @__PURE__ */ n("div", { className: "warning-mark", children: t.severity === "critical" ? "!" : "i" }),
    /* @__PURE__ */ o("div", { children: [
      /* @__PURE__ */ n("strong", { children: t.title }),
      /* @__PURE__ */ n("p", { children: t.detail })
    ] })
  ] }, t.id)) }) : null;
}
const ae = ["#65d6a7", "#7ca7ff", "#f8c86b", "#e18cff", "#ff927d", "#62d3e8", "#a9b7c9"];
function fe({ title: e, subtitle: t, rows: i, valueLabel: a = "Value" }) {
  const s = Math.max(...i.map((r) => r.value), 1);
  return /* @__PURE__ */ o("div", { className: "panel chart-panel", children: [
    /* @__PURE__ */ o("div", { className: "panel-heading", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("h2", { children: e }),
        /* @__PURE__ */ n("p", { children: t })
      ] }),
      /* @__PURE__ */ n("span", { className: "chart-note", children: "Top 10" })
    ] }),
    i.length === 0 ? /* @__PURE__ */ n("div", { className: "empty-chart", children: "No valued holdings yet." }) : /* @__PURE__ */ n("div", { className: "chart-list", children: i.map((r, c) => /* @__PURE__ */ o("div", { className: "chart-row", children: [
      /* @__PURE__ */ o("div", { className: "chart-row-head", children: [
        /* @__PURE__ */ n("span", { className: "legend-dot", style: { background: r.color ?? ae[c % ae.length] } }),
        " ",
        /* @__PURE__ */ n("span", { className: "chart-label", children: r.label }),
        /* @__PURE__ */ n("span", { className: "chart-value", children: r.weight === null ? "—" : `${(r.weight * 100).toFixed(1)}%` })
      ] }),
      /* @__PURE__ */ n("div", { className: "chart-track", children: /* @__PURE__ */ n("span", { style: { width: `${Math.max(2, r.value / s * 100)}%`, background: r.color ?? ae[c % ae.length] } }) }),
      /* @__PURE__ */ o("div", { className: "chart-meta", children: [
        /* @__PURE__ */ n("span", { children: a }),
        /* @__PURE__ */ n("strong", { children: U(r.value) }),
        r.meta && /* @__PURE__ */ n("span", { children: r.meta })
      ] })
    ] }, r.key)) })
  ] });
}
function Q({ eyebrow: e, title: t, detail: i, action: a }) {
  return /* @__PURE__ */ o("div", { className: "section-header", children: [
    /* @__PURE__ */ o("div", { children: [
      e && /* @__PURE__ */ n("div", { className: "eyebrow", children: e }),
      /* @__PURE__ */ n("h1", { children: t }),
      i && /* @__PURE__ */ n("p", { children: i })
    ] }),
    a
  ] });
}
function Y({ icon: e, title: t, detail: i, action: a }) {
  return /* @__PURE__ */ o("div", { className: "empty-state", children: [
    /* @__PURE__ */ n("div", { className: "empty-icon", children: e }),
    /* @__PURE__ */ n("h2", { children: t }),
    /* @__PURE__ */ n("p", { children: i }),
    a
  ] });
}
function P({ children: e, onClick: t, variant: i = "secondary", disabled: a = !1, type: s = "button" }) {
  return /* @__PURE__ */ n("button", { className: `button button-${i}`, onClick: t, disabled: a, type: s, children: e });
}
function he({ children: e }) {
  return /* @__PURE__ */ n("div", { className: "table-shell", children: /* @__PURE__ */ n("table", { children: e }) });
}
function _e({ checked: e, onChange: t, label: i }) {
  return /* @__PURE__ */ o("label", { className: "toggle-row", children: [
    i && /* @__PURE__ */ n("span", { children: i }),
    /* @__PURE__ */ n("button", { type: "button", className: `toggle ${e ? "toggle-on" : ""}`, "aria-pressed": e, onClick: () => t(!e), children: /* @__PURE__ */ n("span", {}) })
  ] });
}
function Be(e, t = 10) {
  if (e.length <= t) return e.map((s) => ({ key: s.key, label: s.label, value: s.valueAud, weight: s.weight, meta: s.type }));
  const i = e.slice(0, t), a = e.slice(t);
  return [
    ...i.map((s) => ({ key: s.key, label: s.label, value: s.valueAud, weight: s.weight, meta: s.type })),
    { key: "other", label: "Other", value: a.reduce((s, r) => s + r.valueAud, 0), weight: a.every((s) => s.weight !== null) ? a.reduce((s, r) => s + (r.weight ?? 0), 0) : null, meta: "View-only aggregation" }
  ];
}
function Ge(e, t = 10) {
  if (e.length <= t) return e.map((s) => ({ key: s.key, label: s.label, value: s.totalAud, weight: s.portfolioWeight, meta: s.type }));
  const i = e.slice(0, t), a = e.slice(t);
  return [
    ...i.map((s) => ({ key: s.key, label: s.label, value: s.totalAud, weight: s.portfolioWeight, meta: s.type })),
    { key: "other", label: "Other", value: a.reduce((s, r) => s + r.totalAud, 0), weight: a.every((s) => s.portfolioWeight !== null) ? a.reduce((s, r) => s + (r.portfolioWeight ?? 0), 0) : null, meta: "View-only aggregation" }
  ];
}
function z(e) {
  return (e ?? "").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toUpperCase().replace(/[^A-Z0-9]+/g, " ").trim().replace(/\s+/g, "_");
}
function ke(e) {
  if (e.instrumentKey?.trim()) return `instrument:${e.instrumentKey.trim()}`;
  const t = z(e.mic), i = z(e.symbol);
  return t && i ? `${t}:${i}` : i && e.currency ? `provider:${z(e.currency)}:${i}` : i ? `provider:unknown:${i}` : null;
}
function ge(e) {
  const t = z(e.isin);
  if (t) return { key: `isin:${t}`, confidence: "high" };
  const i = z(e.mic), a = z(e.symbol);
  if (i && a) return { key: `mic:${i}:${a}`, confidence: "high" };
  const s = z(e.country), r = z(e.currency);
  return a && s && r ? { key: `ticker:${a}:${s}:${r}`, confidence: "medium" } : z(e.name) ? { key: null, confidence: "low" } : { key: null, confidence: "unmapped" };
}
function Ne(e, t) {
  return `scope:${z(e.provider)}:${z(e.etfKey)}:${t}`;
}
function Je(e, t, i) {
  return e ? i ? t[Ne(i, e)] ?? t[e] ?? e : t[e] ?? e : null;
}
const Ye = 3;
function de(e, t) {
  return t ? e ? e === t ? e : "Mixed/Conflicting" : t : e;
}
function Qe(e) {
  return e === "fixed-income" ? "fixed-income" : e === "derivative" ? "derivative" : e === "cash" ? "cash" : e === "etf" ? "etf" : e === "stock" ? "stock" : "other";
}
function Ae(e) {
  const t = /* @__PURE__ */ new Map(), i = e.snapshots, a = e.aliases ?? {}, s = e.holdings.reduce((l, m) => l + (m.audValue ?? 0), 0);
  let r = 0, c = 0;
  function u(l) {
    const m = t.get(l.key);
    if (m) {
      l.direct ? m.directAud += l.amountAud : m.viaEtfsAud += l.amountAud, m.totalAud += l.amountAud, m.sources.push(l.source), m.ticker = m.ticker ?? l.ticker, m.sector = de(m.sector, l.sector), m.country = de(m.country, l.country), m.status = de(m.status, l.status);
      return;
    }
    t.set(l.key, {
      key: l.key,
      ticker: l.ticker,
      label: l.label,
      type: l.type,
      directAud: l.direct ? l.amountAud : 0,
      viaEtfsAud: l.direct ? 0 : l.amountAud,
      totalAud: l.amountAud,
      portfolioWeight: null,
      sector: l.sector,
      country: l.country,
      status: l.status,
      sources: [l.source]
    });
  }
  function f(l, m, T, D, N) {
    const S = {
      kind: N === "ETF-specific residual" ? "residual" : "opaque",
      holdingId: l.id,
      accountId: l.accountId,
      accountName: l.accountName,
      etfKey: l.etfKey ?? T,
      etfSymbol: l.ticker,
      amountAud: m,
      reason: N
    };
    u({ key: T, ticker: l.ticker, label: D, type: "etf", amountAud: m, source: S, status: N });
  }
  function y(l, m, T) {
    const D = ke({ symbol: l, mic: m, currency: T });
    return D && i.has(D) ? D : null;
  }
  function k(l, m, T, D, N) {
    const S = i.get(m);
    if (!S)
      return f(l, T, `opaque-etf:${m}`, `${l.ticker} · Opaque ETF`, "Missing constituent snapshot"), { coveredValueAud: 0 };
    let d = 0;
    for (const p of S.holdings) {
      const x = T * p.weight;
      if (x === 0) continue;
      const I = p.underlyingType === "etf" ? y(p.symbol, p.mic, p.currency) : null;
      if (I) {
        if (D.includes(I)) {
          f(l, x, `opaque-etf:${I}`, `${p.symbol ?? p.name} · Opaque ETF`, "Cycle detected");
          continue;
        }
        if (N >= Ye) {
          f(l, x, `opaque-etf:${I}`, `${p.symbol ?? p.name} · Opaque ETF`, "Maximum recursion depth reached");
          continue;
        }
        d += k(l, I, x, [...D, I], N + 1).coveredValueAud;
        continue;
      }
      if (p.underlyingType === "etf") {
        f(
          l,
          x,
          `opaque-etf:${m}:${p.symbol ?? p.name}`,
          `${p.symbol ?? p.name} · Opaque ETF`,
          "Missing nested ETF snapshot"
        );
        continue;
      }
      const K = Je(ge(p).key, a, { provider: S.provider, etfKey: m }) ?? `unmapped:${m}:${p.symbol ?? p.name}:${D.length}`, E = Qe(p.underlyingType ?? "other"), O = {
        kind: "etf",
        holdingId: l.id,
        accountId: l.accountId,
        accountName: l.accountName,
        etfKey: m,
        etfSymbol: l.ticker,
        amountAud: x,
        path: [...D, p.symbol ?? p.name]
      };
      u({
        key: K,
        ticker: p.symbol,
        label: p.name,
        type: E,
        amountAud: x,
        source: O,
        sector: p.sector,
        country: p.country
      }), d += x;
    }
    const g = Math.max(0, 1 - S.weightSum);
    return g > 1e-7 && f(
      l,
      T * g,
      `residual-etf:${m}`,
      `${l.ticker} · ETF residual`,
      "ETF-specific residual"
    ), { coveredValueAud: d };
  }
  for (const l of e.holdings) {
    if (l.audValue === null) continue;
    if (l.type === "etf") {
      if (c += l.audValue, !l.etfKey || !i.has(l.etfKey)) {
        f(
          l,
          l.audValue,
          `opaque-etf:${l.etfKey ?? l.id}`,
          `${l.ticker} · Opaque ETF`,
          "Missing constituent snapshot"
        );
        continue;
      }
      r += k(l, l.etfKey, l.audValue, [l.etfKey], 0).coveredValueAud;
      continue;
    }
    const m = l.identityKey ?? `unclassified:${l.id}`, T = {
      kind: "direct",
      holdingId: l.id,
      accountId: l.accountId,
      accountName: l.accountName,
      amountAud: l.audValue
    };
    u({
      key: m,
      ticker: l.ticker,
      label: l.name,
      type: l.type,
      amountAud: l.audValue,
      direct: !0,
      source: T,
      status: l.status === "valued" ? void 0 : l.status
    }), l.type !== "cash" && (c += l.audValue, r += l.audValue);
  }
  const v = e.totalAud ?? s, b = [...t.values()].map((l) => ({
    ...l,
    portfolioWeight: v > 0 && !e.totalAud ? null : v > 0 ? l.totalAud / v : null
  })).sort((l, m) => m.totalAud - l.totalAud), w = b.reduce((l, m) => l + m.totalAud, 0);
  return {
    rows: b,
    totalAud: v,
    coveredValueAud: r,
    eligibleValueAud: c,
    coverage: c > 0 ? r / c : null,
    valueConservationDelta: w - s,
    incomplete: e.totalAud === null || e.holdings.some((l) => l.status === "unvalued" || l.status === "unsupported-currency" || l.status === "unsupported-position")
  };
}
const Ze = 0.96, et = 1.005;
function Se(e) {
  const t = [];
  let i = [], a = "", s = !1;
  for (let r = 0; r < e.length; r += 1) {
    const c = e[r], u = e[r + 1];
    c === '"' ? s && u === '"' ? (a += '"', r += 1) : s = !s : c === "," && !s ? (i.push(a.trim()), a = "") : (c === `
` || c === "\r") && !s ? (c === "\r" && u === `
` && (r += 1), i.push(a.trim()), i.some((f) => f.length > 0) && t.push(i), i = [], a = "") : a += c;
  }
  return i.push(a.trim()), i.some((r) => r.length > 0) && t.push(i), t;
}
function tt(e) {
  const t = e.trim();
  if (!t) return { weight: null, unit: "mixed" };
  const i = Number(t.replace(/%$/, ""));
  return !Number.isFinite(i) || i < 0 ? { weight: null, unit: "mixed" } : t.endsWith("%") ? { weight: i / 100, unit: "percentage" } : i <= 1 ? { weight: i, unit: "fraction" } : { weight: i / 100, unit: "bare-percentage" };
}
function se(e) {
  const t = e.holdings.reduce((a, s) => a + s.weight, 0), i = e.holdings.some(
    (a) => !Number.isFinite(a.weight) || a.weight < 0
  );
  if (!e.holdings.length || i)
    return {
      accepted: !1,
      status: "rejected",
      message: "Snapshot must contain at least one constituent with non-negative weights."
    };
  if (t < Ze || t > et)
    return {
      accepted: !1,
      status: "rejected",
      message: `Weight sum ${(t * 100).toFixed(2)}% is outside the accepted 98%–100.5% range.`
    };
  if (t > 1) {
    const a = e.holdings.map((s) => ({
      ...s,
      weight: s.weight / t
    }));
    return {
      accepted: !0,
      status: "normalized",
      message: `Weight sum ${(t * 100).toFixed(2)}% was proportionally normalized to 100%.`,
      snapshot: { ...e, holdings: a, weightSum: 1, normalized: !0 }
    };
  }
  return {
    accepted: !0,
    status: t < 1 ? "residual" : "accepted",
    message: t < 1 ? `Accepted with ${(1 - t) * 100 < 1 ? ((1 - t) * 100).toFixed(2) : ((1 - t) * 100).toFixed(1)}% residual.` : "Snapshot weights sum to 100%.",
    snapshot: { ...e, weightSum: t, normalized: e.normalized ?? !1 }
  };
}
function nt(e, t) {
  const i = Se(e), s = (i.shift() ?? []).map((N) => N.toLowerCase().replace(/\s+/g, "")), r = (N) => s.indexOf(N), c = r("symbol"), u = r("name"), f = r("weight"), y = [];
  c < 0 && u < 0 && y.push("symbol or name"), f < 0 && y.push("weight");
  const k = [], v = [], b = /* @__PURE__ */ new Set();
  for (const [N, S] of i.entries()) {
    const d = (I) => {
      const K = r(I);
      return K >= 0 ? S[K]?.trim() : "";
    }, g = d("symbol") || void 0, p = d("name") || g || "", x = tt(d("weight"));
    x.unit !== "mixed" && b.add(x.unit), p || v.push(`Row ${N + 2}: symbol or name is required.`), x.weight === null && v.push(`Row ${N + 2}: weight is invalid.`), !(!p || x.weight === null) && k.push({
      symbol: g,
      name: p,
      weight: x.weight,
      isin: d("isin") || void 0,
      mic: d("mic") || void 0,
      country: d("country") || void 0,
      currency: d("currency") || void 0,
      sector: d("sector") || void 0,
      assetClass: d("assetclass") || void 0
    });
  }
  const w = /* @__PURE__ */ new Map();
  for (const N of k) {
    const S = ge(N).key;
    S && w.set(S, (w.get(S) ?? 0) + 1);
  }
  const l = [...w.entries()].filter(([, N]) => N > 1).map(([N]) => N);
  l.length && v.push("Duplicate identities will be kept visible for review.");
  const m = k.reduce((N, S) => N + S.weight, 0), T = {
    schemaVersion: 1,
    ...t,
    holdings: k,
    weightSum: m,
    normalized: !1,
    sourceMode: "manual"
  }, D = se(T);
  return {
    rows: k,
    detectedUnit: b.size === 1 ? [...b][0] : (b.size === 0, "mixed"),
    weightSum: m,
    missingFields: y,
    duplicateIdentities: l,
    issues: v,
    validation: D
  };
}
function at(e) {
  const t = ["symbol", "name", "weight", "isin", "mic", "country", "currency", "sector", "assetClass"], i = (a) => {
    const s = a === void 0 ? "" : String(a);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  return [
    t.join(","),
    ...e.holdings.map((a) => [
      a.symbol,
      a.name,
      a.weight,
      a.isin,
      a.mic,
      a.country,
      a.currency,
      a.sector,
      a.assetClass
    ].map(i).join(","))
  ].join(`
`);
}
function it(e, t = Date.now()) {
  if (!e) return "Missing";
  const i = Date.parse(e.fetchedAt);
  if (!Number.isFinite(i)) return "Invalid";
  const a = Math.max(0, t - i);
  return a <= 1440 * 60 * 1e3 ? "Fresh" : a <= 10080 * 60 * 1e3 ? "Stale" : a <= 720 * 60 * 60 * 1e3 ? "Warning" : "Critical";
}
const rt = 300 * 1e3;
function Ce(e) {
  return e?.trim().toUpperCase() ?? "";
}
function st(e, t, i) {
  if (e == null || !Number.isFinite(e))
    return { audValue: null, supported: !1, reason: "No usable market value" };
  const a = Ce(t);
  return a === "AUD" ? { audValue: e, supported: !0 } : a === "USD" && i && Number.isFinite(i.rate) && i.rate > 0 ? { audValue: e * i.rate, supported: !0 } : a === "USD" ? { audValue: null, supported: !1, reason: "Missing valid USD/AUD quote" } : {
    audValue: null,
    supported: !1,
    reason: `Unsupported currency: ${a || "unknown"}`
  };
}
function ot(e, t = Date.now()) {
  const i = Date.parse(e);
  if (!Number.isFinite(i)) return null;
  const a = Math.max(0, t - i);
  return a < 600 * 1e3 ? "Fresh" : a <= 1800 * 1e3 ? "Stale" : "Warning";
}
function lt(e, t = Date.now()) {
  if (!e) return "Not available";
  const i = Date.parse(e);
  if (!Number.isFinite(i)) return "Unknown time";
  const a = Math.max(0, Math.floor((t - i) / 1e3));
  if (a < 60) return "just now";
  const s = Math.floor(a / 60);
  if (s < 60) return `${s} min ago`;
  const r = Math.floor(s / 60);
  return r < 24 ? `${r} hr ago` : `${Math.floor(r / 24)} d ago`;
}
function ct(e) {
  return e != null && Number.isFinite(e) ? e : null;
}
function dt(e, t, i) {
  if (i) return i;
  if (e.holdingType === "cash") return "cash";
  const a = t?.instrumentType?.toUpperCase() ?? "";
  return a.includes("ETF") || a.includes("MUTUAL") ? "etf" : a.includes("BOND") || a.includes("FIXED") ? "fixed-income" : a.includes("OPTION") || a.includes("DERIVATIVE") ? "derivative" : a.includes("EQUITY") || a.includes("STOCK") ? "stock" : ((t?.kind?.toUpperCase() ?? "") === "INVESTMENT" && t?.symbol, "unknown");
}
function ut(e, t, i, a, s) {
  const r = Ce(e.localCurrency), c = ct(e.marketValue?.local), u = e.quantity, f = dt(e, i, s), y = st(c, r, a), k = i?.symbol || e.instrument?.symbol || (f === "cash" ? r : "Unmapped"), v = i?.name || e.instrument?.name || (f === "cash" ? `${r} cash` : "Unmapped instrument"), b = f === "cash" ? { key: `cash:${r}` } : ge({
    isin: i?.isin,
    mic: i?.mic,
    symbol: i?.symbol || e.instrument?.symbol,
    currency: r,
    name: v
  }), w = f === "etf" ? ke({
    instrumentKey: i?.instrumentKey,
    mic: i?.mic,
    symbol: k,
    currency: r
  }) : null;
  let l = "valued", m;
  return u < 0 || f === "cash" && c !== null && c < 0 ? (l = "unsupported-position", m = "Negative quantity or cash is not supported in v1") : c === null ? (l = "unvalued", m = "Wealthfolio did not provide a usable market value") : y.supported ? f === "unknown" && (l = "unknown-instrument", m = "Instrument type is unresolved; add a local type override") : (l = y.reason?.startsWith("Unsupported currency") ? "unsupported-currency" : "unvalued", m = y.reason), {
    id: e.id,
    accountId: t.id,
    accountName: t.name,
    ticker: k,
    name: v,
    type: f,
    quantity: u,
    localCurrency: r,
    nativeValue: c,
    audValue: y.audValue,
    priceUpdatedAt: e.asOfDate || null,
    identityKey: b.key,
    etfKey: w,
    profileId: e.instrument?.id ?? null,
    status: l,
    issue: m,
    sourceHoldingId: e.id
  };
}
function pt(e) {
  const t = [], i = /* @__PURE__ */ new Map();
  for (const u of e) {
    const f = i.get(u.status) ?? [];
    f.push(u), i.set(u.status, f);
  }
  const a = i.get("unsupported-currency") ?? [];
  if (a.length) {
    const u = [...new Set(a.map((f) => f.localCurrency))].join(", ");
    t.push({
      id: "unsupported-currency",
      severity: "critical",
      title: "Unsupported currency",
      detail: `${u} holdings remain visible but are excluded from AUD totals until supported.`,
      holdingIds: a.map((f) => f.id)
    });
  }
  const s = i.get("unvalued") ?? [];
  s.length && t.push({
    id: "unvalued",
    severity: "critical",
    title: "Portfolio total is incomplete",
    detail: `${s.length} holding${s.length === 1 ? " has" : "s have"} no usable AUD value. Missing data is never replaced with zero.`,
    holdingIds: s.map((u) => u.id)
  });
  const r = i.get("unsupported-position") ?? [];
  r.length && t.push({
    id: "unsupported-position",
    severity: "critical",
    title: "Unsupported portfolio position",
    detail: "Negative quantity, short positions, or negative cash stop percentage-based X-Ray calculations.",
    holdingIds: r.map((u) => u.id)
  });
  const c = i.get("unknown-instrument") ?? [];
  return c.length && t.push({
    id: "unknown-instrument",
    severity: "warning",
    title: "Instrument type needs review",
    detail: `${c.length} instrument${c.length === 1 ? " is" : "s are"} visible as Unknown until a local override is supplied.`,
    holdingIds: c.map((u) => u.id)
  }), t;
}
function ht(e, t) {
  const i = /* @__PURE__ */ new Map();
  for (const a of e) {
    if (a.audValue === null || !a.identityKey) continue;
    const s = i.get(a.identityKey);
    if (s) {
      s.valueAud += a.audValue;
      continue;
    }
    i.set(a.identityKey, {
      key: a.identityKey,
      label: a.type === "cash" ? `${a.localCurrency} cash` : a.ticker,
      type: a.type,
      valueAud: a.audValue,
      weight: t && t > 0 ? a.audValue / t : null,
      status: a.status === "valued" ? void 0 : a.status
    });
  }
  return [...i.values()].map((a) => ({ ...a, weight: t && t > 0 ? a.valueAud / t : null })).sort((a, s) => s.valueAud - a.valueAud);
}
function Ie(e, t) {
  const i = e.reduce((u, f) => u + (f.audValue ?? 0), 0), a = e.some((u) => u.status === "unvalued" || u.status === "unsupported-currency"), s = e.some((u) => u.status === "unsupported-position"), r = e.length > 0 && !a && !s ? i : null, c = pt(e);
  return {
    holdings: e,
    selectedAccountIds: t,
    totalAud: r,
    supportedValueAud: i,
    valuedHoldingCount: e.filter((u) => u.audValue !== null).length,
    incomplete: r === null,
    warnings: c,
    instrumentAllocation: ht(e, r),
    etfs: [...new Map(
      e.filter((u) => u.type === "etf" && u.etfKey).map((u) => [u.etfKey, {
        etfKey: u.etfKey,
        profileId: u.profileId,
        symbol: u.ticker,
        name: u.name,
        currency: u.localCurrency
      }])
    ).values()]
  };
}
function gt(e, t) {
  return e ? {
    id: e.id,
    name: e.name || t || e.displayCode || "Unmapped instrument",
    symbol: e.instrumentSymbol || e.displayCode || t || "",
    mic: e.instrumentExchangeMic || void 0,
    instrumentKey: e.instrumentKey || void 0,
    instrumentType: e.instrumentType || void 0,
    currency: e.quoteCcy,
    kind: e.kind
  } : null;
}
const Ee = "etf.index.v1", ve = 18e4;
function ie(e) {
  return [...e].map((t) => /[A-Za-z0-9]/.test(t) ? t : `_x${t.codePointAt(0)?.toString(16)}_`).join("");
}
function mt(e) {
  const t = [];
  for (let i = 0; i < e.length; i += ve) t.push(e.slice(i, i + ve));
  return t;
}
async function re(e) {
  const t = await e.api.storage.get(Ee);
  if (!t) return {};
  try {
    const i = JSON.parse(t);
    return i && typeof i == "object" ? i : {};
  } catch {
    return {};
  }
}
async function ye(e, t) {
  await e.api.storage.set(Ee, JSON.stringify(t));
}
class _ {
  constructor(t) {
    this.ctx = t;
  }
  ctx;
  async list() {
    const t = await re(this.ctx), i = [];
    for (const a of Object.values(t)) {
      const s = await this.readEntry(a);
      i.push({ etfKey: a.etfKey, version: a.version, snapshot: s.snapshot, invalid: s.invalid, failureReason: s.failureReason, updatedAt: a.updatedAt });
    }
    return i;
  }
  async get(t) {
    const a = (await re(this.ctx))[t];
    if (!a) return null;
    const s = await this.readEntry(a);
    return { etfKey: t, version: a.version, snapshot: s.snapshot, invalid: s.invalid, failureReason: s.failureReason, updatedAt: a.updatedAt };
  }
  async readEntry(t) {
    const i = `etf.snapshot.v1.${ie(t.etfKey)}.${t.version}`, a = [];
    for (let s = 0; s < t.chunkCount; s += 1) {
      const r = await this.ctx.api.storage.get(`${i}.${s}`);
      if (r === null) return { snapshot: null, invalid: !0, failureReason: "Cached snapshot chunk is missing" };
      a.push(r);
    }
    try {
      const s = JSON.parse(a.join("")), r = se(s);
      return r.accepted && r.snapshot ? { snapshot: r.snapshot, invalid: !1, failureReason: s.failureReason } : { snapshot: null, invalid: !0, failureReason: r.message };
    } catch {
      return { snapshot: null, invalid: !0, failureReason: "Cached snapshot could not be parsed" };
    }
  }
  async save(t, i = {}) {
    const a = se(t);
    if (!a.accepted || !a.snapshot) throw new Error(a.message);
    const s = await re(this.ctx), r = s[t.etfKey];
    if (i.expectedVersion !== void 0 && r && i.expectedVersion !== r.version)
      throw new Error("ETF snapshot changed elsewhere; reload before saving Manual data.");
    if (r?.sourceMode === "manual" && t.sourceMode !== "manual")
      throw new Error("Automatic refresh cannot overwrite a newer Manual snapshot.");
    const c = (r?.version ?? 0) + 1, u = JSON.stringify(a.snapshot), f = mt(u), y = `etf.snapshot.v1.${ie(t.etfKey)}.${c}`;
    for (const [v, b] of f.entries())
      await this.ctx.api.storage.set(`${y}.${v}`, b);
    const k = (/* @__PURE__ */ new Date()).toISOString();
    if (s[t.etfKey] = {
      etfKey: t.etfKey,
      version: c,
      chunkCount: f.length,
      updatedAt: k,
      sourceMode: t.sourceMode
    }, await ye(this.ctx, s), r) {
      const v = `etf.snapshot.v1.${ie(r.etfKey)}.${r.version}`;
      for (let b = 0; b < r.chunkCount; b += 1)
        await this.ctx.api.storage.delete(`${v}.${b}`);
    }
    return { etfKey: t.etfKey, version: c, snapshot: a.snapshot, updatedAt: k };
  }
  async disable(t) {
    const i = await re(this.ctx), a = i[t];
    if (!a) return;
    const s = `etf.snapshot.v1.${ie(a.etfKey)}.${a.version}`;
    for (let r = 0; r < a.chunkCount; r += 1)
      await this.ctx.api.storage.delete(`${s}.${r}`);
    delete i[t], await ye(this.ctx, i);
  }
}
const De = "settings.v1", oe = {
  schemaVersion: 1,
  selectionInitialized: !1,
  selectedAccountIds: [],
  acknowledgedAccountIds: [],
  liveFxPolling: !0,
  providerModes: {},
  pinnedProviders: {},
  providerIdentities: {},
  typeOverrides: {},
  aliases: {}
};
function Te(e) {
  if (!e || typeof e != "object") return { ...oe };
  const t = e, i = (r) => r === "stock" || r === "etf" || r === "cash" || r === "fixed-income" || r === "derivative" || r === "other" || r === "unknown", a = Object.fromEntries(
    Object.entries(t.typeOverrides ?? {}).filter(([, r]) => i(r))
  ), s = Object.fromEntries(
    Object.entries(t.providerModes ?? {}).filter(([, r]) => r === "auto" || r === "pinned")
  );
  return {
    ...oe,
    ...t,
    schemaVersion: 1,
    selectionInitialized: !!t.selectionInitialized,
    selectedAccountIds: Array.isArray(t.selectedAccountIds) ? t.selectedAccountIds.filter((r) => typeof r == "string") : [],
    acknowledgedAccountIds: Array.isArray(t.acknowledgedAccountIds) ? t.acknowledgedAccountIds.filter((r) => typeof r == "string") : [],
    liveFxPolling: t.liveFxPolling !== !1,
    providerModes: s,
    pinnedProviders: typeof t.pinnedProviders == "object" && t.pinnedProviders ? t.pinnedProviders : {},
    providerIdentities: typeof t.providerIdentities == "object" && t.providerIdentities ? t.providerIdentities : {},
    typeOverrides: a,
    aliases: typeof t.aliases == "object" && t.aliases ? t.aliases : {}
  };
}
async function ft(e) {
  const t = await e.api.storage.get(De);
  if (!t) return { ...oe };
  try {
    return Te(JSON.parse(t));
  } catch {
    return { ...oe };
  }
}
async function M(e, t) {
  await e.api.storage.set(De, JSON.stringify(Te(t)));
}
function vt(e, t) {
  const i = new Set(t.map((c) => c.id));
  if (!e.selectionInitialized) {
    const c = t.map((u) => u.id);
    return {
      settings: {
        ...e,
        selectionInitialized: !0,
        selectedAccountIds: c,
        acknowledgedAccountIds: c
      },
      selectedAccounts: t,
      newlyIncludedAccounts: []
    };
  }
  const a = new Set(e.acknowledgedAccountIds), s = new Set(e.selectedAccountIds.filter((c) => i.has(c))), r = t.filter((c) => !a.has(c.id));
  for (const c of r)
    s.add(c.id), a.add(c.id);
  return {
    settings: {
      ...e,
      selectedAccountIds: [...s],
      acknowledgedAccountIds: [...a]
    },
    selectedAccounts: t.filter((c) => s.has(c.id)),
    newlyIncludedAccounts: r
  };
}
function yt(e, t) {
  return { ...e, selectionInitialized: !0, selectedAccountIds: [...new Set(t)] };
}
const ue = "fx.quote.usd-aud", $e = "twelvedata.apiKey";
async function bt(e, t) {
  try {
    return await e.api.secrets.get(t);
  } catch (i) {
    return e.api.logger.warn(`Secret access unavailable for ${t}: ${i instanceof Error ? i.message : "permission denied"}`), null;
  }
}
function le(e) {
  return typeof e == "number" && Number.isFinite(e) && e > 0;
}
function xt(e) {
  if (!e) return null;
  try {
    const t = JSON.parse(e);
    if (t.pair === "USD/AUD" && le(t.rate) && typeof t.fetchedAt == "string")
      return {
        pair: "USD/AUD",
        rate: t.rate,
        fetchedAt: t.fetchedAt,
        provider: t.provider === "wealthfolio" ? "wealthfolio" : "twelvedata"
      };
  } catch {
    return null;
  }
  return null;
}
function wt(e) {
  const t = e.find(
    (a) => a.fromCurrency.toUpperCase() === "USD" && a.toCurrency.toUpperCase() === "AUD" && le(a.rate)
  );
  if (t)
    return { pair: "USD/AUD", rate: t.rate, fetchedAt: t.timestamp, provider: "wealthfolio" };
  const i = e.find(
    (a) => a.fromCurrency.toUpperCase() === "AUD" && a.toCurrency.toUpperCase() === "USD" && le(a.rate)
  );
  return i ? { pair: "USD/AUD", rate: 1 / i.rate, fetchedAt: i.timestamp, provider: "wealthfolio" } : null;
}
async function kt(e, t) {
  const i = `https://api.twelvedata.com/exchange_rate?symbol=${encodeURIComponent("USD/AUD")}&apikey=${encodeURIComponent(t)}`, a = await e.api.network.request({ method: "GET", url: i });
  if (a.status < 200 || a.status >= 300) throw new Error(`Twelve Data returned ${a.status}`);
  const s = JSON.parse(a.body), r = typeof s.rate == "string" ? Number(s.rate) : s.rate;
  if (!le(r)) throw new Error(s.message || "Twelve Data returned an invalid USD/AUD rate");
  return { pair: "USD/AUD", rate: r, fetchedAt: (/* @__PURE__ */ new Date()).toISOString(), provider: "twelvedata" };
}
class Nt {
  constructor(t) {
    this.ctx = t;
  }
  ctx;
  async getSharedQuote() {
    return xt(await this.ctx.api.storage.get(ue));
  }
  async getQuote(t = {}) {
    const i = await this.getSharedQuote();
    if (i && Date.now() - Date.parse(i.fetchedAt) < rt && !t.force) return i;
    const s = await bt(this.ctx, $e);
    if (s)
      try {
        const r = await kt(this.ctx, s);
        return await this.ctx.api.storage.set(ue, JSON.stringify(r)), r;
      } catch (r) {
        this.ctx.api.logger.warn(`USD/AUD provider failed: ${r instanceof Error ? r.message : "unknown error"}`);
      }
    try {
      const r = wt(await this.ctx.api.exchangeRates.getAll());
      if (r)
        return await this.ctx.api.storage.set(ue, JSON.stringify(r)), r;
    } catch (r) {
      this.ctx.api.logger.warn(`Wealthfolio FX fallback failed: ${r instanceof Error ? r.message : "unknown error"}`);
    }
    return i;
  }
}
function Pe(e) {
  const t = typeof e == "number" ? e : Number(String(e ?? "").replace(/%$/, ""));
  return !Number.isFinite(t) || t < 0 ? null : t > 1 ? t / 100 : t;
}
function Ke(e) {
  const t = String(e ?? "").toLowerCase();
  return t.includes("etf") || t.includes("fund") ? "etf" : t.includes("bond") || t.includes("fixed") || t.includes("income") ? "fixed-income" : t.includes("derivative") || t.includes("option") || t.includes("future") ? "derivative" : t.includes("cash") || t.includes("currency") ? "cash" : t.includes("equity") || t.includes("equities") || t.includes("stock") ? "stock" : "other";
}
function Fe(e, t, i, a) {
  const s = {
    schemaVersion: 1,
    etfKey: e.etfKey,
    provider: t,
    asOfDate: a || (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
    fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
    holdings: i,
    weightSum: i.reduce((c, u) => c + u.weight, 0),
    normalized: !1,
    sourceMode: "automatic"
  }, r = se(s);
  if (!r.accepted || !r.snapshot) throw new Error(r.message);
  return r.snapshot;
}
async function Ue(e, t) {
  const i = await e.api.network.request({ method: "GET", url: t });
  if (i.status < 200 || i.status >= 300) throw new Error(`Provider returned ${i.status}`);
  return i.body;
}
class At {
  constructor(t, i) {
    this.ctx = t, this.apiKey = i;
  }
  ctx;
  apiKey;
  id = "alpha-vantage";
  async canHandle(t) {
    return !!(this.apiKey && t.symbol);
  }
  async fetchHoldings(t) {
    if (!this.apiKey) throw new Error("Alpha Vantage API key is not configured");
    const i = `https://www.alphavantage.co/query?function=ETF_PROFILE&symbol=${encodeURIComponent(t.symbol)}&apikey=${encodeURIComponent(this.apiKey)}`, a = JSON.parse(await Ue(this.ctx, i));
    if (!a.holdings?.length) throw new Error(a.Information || a.Note || a.message || "Alpha Vantage returned no holdings");
    const s = [];
    for (const r of a.holdings) {
      const c = Pe(r.weight), u = String(r.name ?? r.description ?? r.symbol ?? "").trim();
      !u || c === null || s.push({
        symbol: String(r.symbol ?? "").trim() || void 0,
        name: u,
        weight: c,
        country: String(r.country ?? "").trim() || void 0,
        sector: String(r.sector ?? "").trim() || void 0,
        assetClass: String(r.asset_type ?? r.assetClass ?? "").trim() || void 0,
        underlyingType: Ke(r.asset_type ?? r.assetClass)
      });
    }
    return Fe(t, this.id, s, a.last_updated);
  }
}
class be {
  constructor(t, i, a) {
    this.id = t, this.ctx = i, this.hostPrefix = a;
  }
  id;
  ctx;
  hostPrefix;
  async canHandle(t) {
    return t.providerSymbol ? this.id === "ishares" ? /^\d+$/.test(t.providerSymbol) : /^[A-Za-z0-9]+$/.test(t.providerSymbol) : !1;
  }
  async fetchHoldings(t) {
    const i = t.providerSymbol;
    if (!i) throw new Error(`${this.id} public identifier is missing`);
    const a = this.id === "ishares" ? `${this.hostPrefix}${encodeURIComponent(i)}/latest-holdings.csv` : `${this.hostPrefix}${encodeURIComponent(i.toUpperCase())}_Portfolio_Holdings.csv`, s = await Ue(this.ctx, a);
    return St(s, t, this.id);
  }
}
function St(e, t, i) {
  const a = Se(e), s = a.findIndex((f) => f.some((y) => y.toLowerCase().replace(/\s+/g, "") === "weight(%)"));
  if (s < 0) throw new Error(`${i} holdings CSV schema changed: Weight (%) column not found`);
  const r = a[s].map((f) => f.toLowerCase().replace(/[\s%()/#]+/g, "")), c = (f) => r.indexOf(f), u = [];
  for (const f of a.slice(s + 1)) {
    const y = (w) => {
      const l = c(w);
      return l >= 0 ? f[l]?.trim() ?? "" : "";
    }, k = y("ticker") || void 0, v = y("name") || k || "", b = Pe(y("weight"));
    !v || b === null || u.push({
      symbol: k,
      name: v,
      weight: b,
      country: y("location") || y("country") || void 0,
      currency: y("currency") || void 0,
      sector: y("sector") || void 0,
      assetClass: y("assetclass") || void 0,
      underlyingType: Ke(y("assetclass"))
    });
  }
  return Fe(t, i, u);
}
function Re(e, t) {
  return [
    new be("ishares", e, "https://www.ishares.com/us/products/"),
    new be("betashares", e, "https://www.betashares.com.au/files/csv/"),
    new At(e, t.alphaVantageApiKey)
  ];
}
async function ze(e, t, i) {
  const a = i.mode === "auto" || i.cached?.provider === i.pinnedProvider;
  if (i.cached && a && !i.force) {
    const c = Date.parse(i.cached.fetchedAt);
    if (Number.isFinite(c) && Date.now() - c <= 1440 * 60 * 1e3)
      return { snapshot: i.cached, provider: i.cached.provider };
  }
  const s = i.mode === "pinned" ? t.filter((c) => c.id === i.pinnedProvider) : t;
  let r = "No provider can handle this ETF";
  for (const c of s)
    try {
      if (!await c.canHandle(e)) continue;
      return { snapshot: await c.fetchHoldings(e), provider: c.id };
    } catch (u) {
      r = u instanceof Error ? u.message : "Provider failed";
    }
  return {
    snapshot: a ? i.cached ?? null : null,
    provider: a ? i.cached?.provider ?? null : null,
    failureReason: r
  };
}
async function Ct(e, t, i) {
  const a = new Array(e.length);
  let s = 0;
  async function r() {
    for (; s < e.length; ) {
      const c = s;
      s += 1, a[c] = await i(e[c]);
    }
  }
  return await Promise.all(Array.from({ length: Math.min(t, e.length) }, () => r())), a;
}
function It(e) {
  return {
    id: e.id,
    name: e.name,
    currency: e.currency,
    isActive: e.isActive,
    isArchived: e.isArchived
  };
}
async function Et(e) {
  return (await e.api.accounts.getAll()).filter((i) => i.isActive && !i.isArchived).map(It);
}
async function Dt(e, t, i) {
  const a = t.filter((u) => i.includes(u.id)), s = await Promise.all(
    a.map(async (u) => ({
      account: u,
      holdings: await e.api.portfolio.getHoldings(u.id)
    }))
  ), r = /* @__PURE__ */ new Map(), c = [];
  for (const u of s)
    for (const f of u.holdings) {
      const y = f.instrument?.id;
      let k = null;
      if (y) {
        if (!r.has(y))
          try {
            const v = await e.api.assets.getProfile(y);
            r.set(y, gt(v, f.instrument?.symbol));
          } catch {
            r.set(y, null);
          }
        k = r.get(y) ?? null;
      }
      c.push({ holding: f, account: u.account, profile: k });
    }
  return c;
}
async function Tt(e) {
  return (await e.api.settings.get()).baseCurrency.toUpperCase();
}
const $t = {
  schemaVersion: 1,
  selectionInitialized: !1,
  selectedAccountIds: [],
  acknowledgedAccountIds: [],
  liveFxPolling: !0,
  providerModes: {},
  pinnedProviders: {},
  providerIdentities: {},
  typeOverrides: {},
  aliases: {}
}, Pt = Ie([], []), Kt = Ae({ holdings: [], snapshots: /* @__PURE__ */ new Map(), totalAud: null });
async function Me(e, t) {
  try {
    return await e.api.secrets.get(t);
  } catch {
    return null;
  }
}
async function xe(e, t) {
  return !!await Me(e, t);
}
function Ft() {
  return {
    loading: !0,
    error: null,
    baseCurrency: null,
    activeAccounts: [],
    selectedAccounts: [],
    settings: $t,
    holdings: [],
    portfolio: Pt,
    exposure: Kt,
    fxQuote: null,
    snapshots: /* @__PURE__ */ new Map(),
    etfData: [],
    newlyIncludedAccounts: [],
    hasTwelveDataKey: !1,
    hasAlphaVantageKey: !1,
    lastLoadedAt: null,
    automaticFailures: {}
  };
}
function Ut(e) {
  if (!e) return !1;
  const t = Date.parse(e.fetchedAt);
  return Number.isFinite(t) && Date.now() - t <= 1440 * 60 * 1e3;
}
async function Rt(e, t, i, a) {
  const s = new _(e), r = new Map(a.map((v) => [v.etfKey, v])), c = await Me(e, "alphaVantage.apiKey"), u = Re(e, { alphaVantageApiKey: c }), f = t.filter((v) => {
    const b = r.get(v.etfKey), w = i.providerModes[v.etfKey] ?? "auto", l = i.pinnedProviders[v.etfKey];
    return !b?.snapshot || !Ut(b.snapshot) || w === "pinned" && b.snapshot.provider !== l;
  }), y = await Ct(f, 2, async (v) => {
    const b = r.get(v.etfKey);
    try {
      const w = await ze(v, u, {
        mode: i.providerModes[v.etfKey] ?? "auto",
        pinnedProvider: i.pinnedProviders[v.etfKey],
        cached: b?.snapshot
      });
      return { asset: v, current: b, result: w };
    } catch (w) {
      return {
        asset: v,
        current: b,
        result: { snapshot: null, provider: null, failureReason: w instanceof Error ? w.message : "Provider failed" }
      };
    }
  }), k = {};
  for (const v of y) {
    const { asset: b, current: w, result: l } = v;
    if (l.snapshot && (!w?.snapshot || l.snapshot.fetchedAt !== w.snapshot.fetchedAt || l.snapshot.provider !== w.snapshot.provider))
      try {
        await s.save(l.snapshot, { expectedVersion: w?.version });
      } catch (m) {
        k[b.etfKey] = m instanceof Error ? m.message : "Snapshot could not be published";
      }
    l.failureReason && (!l.snapshot || l.snapshot.fetchedAt === w?.snapshot?.fetchedAt) && (k[b.etfKey] = l.failureReason);
  }
  return { records: await s.list(), failures: k };
}
function zt(e) {
  const [t, i] = $(Ft), [a, s] = $(0), r = Oe(!0), c = F(async (d = {}) => {
    i((g) => ({ ...g, loading: !0, error: null }));
    try {
      const [g, p, x, I, K] = await Promise.all([
        Et(e),
        ft(e),
        Tt(e),
        xe(e, $e),
        xe(e, "alphaVantage.apiKey")
      ]), E = vt(p, g);
      JSON.stringify(E.settings) !== JSON.stringify(p) && await M(e, E.settings);
      const O = await new Nt(e).getQuote({ force: d.forceFx }), L = (await Dt(e, g, E.settings.selectedAccountIds)).map((C) => {
        const R = C.profile?.instrumentKey || C.profile?.id || C.holding.instrument?.id;
        return ut(C.holding, C.account, C.profile, O, R ? E.settings.typeOverrides[R] : void 0);
      }), G = Ie(L, E.settings.selectedAccountIds), W = {
        ...G,
        etfs: G.etfs.map((C) => ({
          ...C,
          providerSymbol: E.settings.providerIdentities[C.etfKey] || void 0
        }))
      }, Z = await new _(e).list(), j = await Rt(e, W.etfs, E.settings, Z), X = j.records, J = new Map(X.filter((C) => C.snapshot !== null).map((C) => [C.etfKey, C.snapshot])), ee = Ae({
        holdings: L,
        snapshots: J,
        totalAud: W.totalAud,
        aliases: E.settings.aliases
      }), te = W.etfs.map((C) => {
        const R = J.get(C.etfKey) ?? null, h = X.find((A) => A.etfKey === C.etfKey);
        return {
          asset: C,
          snapshot: R,
          version: h?.version,
          status: h?.invalid ? "Invalid" : R ? it(R) : j.failures[C.etfKey]?.startsWith("No provider") ? "Unsupported" : "Missing",
          resolvedWeight: R?.weightSum ?? 0,
          failureReason: h?.failureReason ?? j.failures[C.etfKey] ?? R?.failureReason
        };
      });
      r.current && i({
        loading: !1,
        error: null,
        baseCurrency: x,
        activeAccounts: g,
        selectedAccounts: E.selectedAccounts,
        settings: E.settings,
        holdings: L,
        portfolio: W,
        exposure: ee,
        fxQuote: O,
        snapshots: J,
        etfData: te,
        newlyIncludedAccounts: E.newlyIncludedAccounts,
        hasTwelveDataKey: I,
        hasAlphaVantageKey: K,
        lastLoadedAt: (/* @__PURE__ */ new Date()).toISOString(),
        automaticFailures: j.failures
      });
    } catch (g) {
      r.current && i((p) => ({
        ...p,
        loading: !1,
        error: g instanceof Error ? g.message : "Unable to read Wealthfolio data"
      }));
    }
  }, [e]);
  B(() => (r.current = !0, c(), () => {
    r.current = !1;
  }), [c, a]), B(() => {
    let d = !1;
    const g = [];
    async function p() {
      const x = await Promise.all([
        e.api.events.portfolio.onUpdateComplete(() => {
          c();
        }),
        e.api.events.market.onSyncComplete(() => {
          c();
        })
      ]);
      d ? x.forEach((I) => I()) : g.push(...x);
    }
    return p().catch((x) => {
      e.api.logger.warn(`Portfolio X-Ray event listeners unavailable: ${x instanceof Error ? x.message : "permission denied"}`);
    }), () => {
      d = !0, g.forEach((x) => x());
    };
  }, [e, c]), B(() => {
    if (!t.settings.liveFxPolling) return;
    const d = () => {
      document.visibilityState === "visible" && c();
    }, g = window.setInterval(d, 300 * 1e3);
    return document.addEventListener("visibilitychange", d), () => {
      window.clearInterval(g), document.removeEventListener("visibilitychange", d);
    };
  }, [c, t.settings.liveFxPolling]);
  const u = F(async (d, g) => {
    await new _(e).save(d, { expectedVersion: g }), s((p) => p + 1);
  }, [e]), f = F(async (d) => {
    await new _(e).disable(d), s((g) => g + 1);
  }, [e]), y = F(async (d) => {
    const g = t.portfolio.etfs.find((E) => E.etfKey === d);
    if (!g) return;
    const p = await new _(e).get(d);
    let x = null;
    try {
      x = await e.api.secrets.get("alphaVantage.apiKey");
    } catch {
      x = null;
    }
    const I = Re(e, { alphaVantageApiKey: x }), K = await ze(g, I, {
      mode: t.settings.providerModes[d] ?? "auto",
      pinnedProvider: t.settings.pinnedProviders[d],
      cached: p?.snapshot
    });
    if (!K.snapshot) throw new Error(K.failureReason ?? "No ETF provider could resolve this fund");
    await new _(e).save({ ...K.snapshot, failureReason: K.failureReason }, { expectedVersion: p?.version }), s((E) => E + 1);
  }, [e, t.portfolio.etfs, t.settings.pinnedProviders, t.settings.providerModes]), k = F(async (d) => {
    const g = yt(t.settings, d);
    await M(e, g), s((p) => p + 1);
  }, [e, t.settings]), v = F(async (d, g) => {
    g.trim() ? await e.api.secrets.set(d, g.trim()) : await e.api.secrets.delete(d), s((p) => p + 1);
  }, [e]), b = F(async (d) => {
    await e.api.secrets.delete(d), s((g) => g + 1);
  }, [e]), w = F(async (d) => {
    const g = { ...t.settings, liveFxPolling: d };
    await M(e, g), i((p) => ({ ...p, settings: g }));
  }, [e, t.settings]), l = F(async (d, g) => {
    const p = { ...t.settings, typeOverrides: { ...t.settings.typeOverrides, [d]: g } };
    await M(e, p), s((x) => x + 1);
  }, [e, t.settings]), m = F(async (d, g) => {
    const p = { ...t.settings, providerModes: { ...t.settings.providerModes, [d]: g } };
    await M(e, p), i((x) => ({ ...x, settings: p }));
  }, [e, t.settings]), T = F(async (d, g) => {
    const p = { ...t.settings, pinnedProviders: { ...t.settings.pinnedProviders, [d]: g } };
    await M(e, p), i((x) => ({ ...x, settings: p }));
  }, [e, t.settings]), D = F(async (d, g) => {
    const p = { ...t.settings.providerIdentities };
    g.trim() ? p[d] = g.trim() : delete p[d];
    const x = { ...t.settings, providerIdentities: p };
    await M(e, x), s((I) => I + 1);
  }, [e, t.settings]), N = F(async (d, g, p, x) => {
    const I = Ne({ provider: d, etfKey: g }, p), K = { ...t.settings, aliases: { ...t.settings.aliases, [I]: x } };
    await M(e, K), s((E) => E + 1);
  }, [e, t.settings]), S = F(async (d) => {
    const g = { ...t.settings.aliases };
    delete g[d], await M(e, { ...t.settings, aliases: g }), s((p) => p + 1);
  }, [e, t.settings]);
  return We(() => ({
    ...t,
    refresh: c,
    refreshEtf: y,
    saveSnapshot: u,
    disableSnapshot: f,
    saveAccountSelection: k,
    saveSecret: v,
    deleteSecret: b,
    setLiveFxPolling: w,
    setTypeOverride: l,
    setProviderMode: m,
    setPinnedProvider: T,
    setProviderIdentity: D,
    setAliasMapping: N,
    removeAliasMapping: S
  }), [
    t,
    c,
    y,
    u,
    f,
    k,
    v,
    b,
    w,
    l,
    m,
    T,
    D,
    N,
    S
  ]);
}
function Mt({
  ctx: e,
  portfolio: t,
  exposure: i,
  fxQuote: a,
  etfData: s,
  baseCurrency: r,
  selectedAccounts: c,
  newlyIncludedAccounts: u,
  onNavigatePerformance: f,
  onRefreshFx: y,
  onGoToSettings: k
}) {
  const v = a ? ot(a.fetchedAt) : null, b = [...t.warnings];
  r && r !== "AUD" && b.unshift({ id: "base-currency", severity: "critical", title: "Wealthfolio base currency is not AUD", detail: `Portfolio X-Ray is designed for AUD valuation. Current Wealthfolio base currency: ${r}.` }), !a && t.holdings.some((m) => m.localCurrency === "USD") && b.unshift({ id: "missing-fx", severity: "critical", title: "USD/AUD quote unavailable", detail: "USD holdings remain visible in native currency, but AUD totals and percentages are incomplete. Configure Twelve Data or refresh Wealthfolio rates." }), u.length && b.unshift({ id: "new-accounts", severity: "info", title: "New active account included", detail: `${u.map((m) => m.name).join(", ")} was included for X-Ray analysis. You can change this in Settings.` });
  const w = t.holdings.length === 0, l = !w && t.totalAud === null;
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ n(Q, { eyebrow: "Portfolio intelligence", title: "Overview", detail: `${c.length} selected account${c.length === 1 ? "" : "s"} · current values from Wealthfolio`, action: /* @__PURE__ */ n(P, { onClick: y, variant: "quiet", children: "↻ Refresh X-Ray" }) }),
    w ? /* @__PURE__ */ n(Y, { icon: "◈", title: "No holdings in the selected accounts", detail: "Choose active Wealthfolio accounts in Settings to begin your Portfolio X-Ray.", action: /* @__PURE__ */ n(P, { onClick: k, variant: "primary", children: "Open Settings" }) }) : /* @__PURE__ */ o(ce, { children: [
      /* @__PURE__ */ o("div", { className: "metric-grid", children: [
        /* @__PURE__ */ n(ne, { label: "Total portfolio", value: t.totalAud === null ? "Incomplete" : U(t.totalAud), detail: l ? "Missing values remain visible" : "Supported holdings and cash in AUD", icon: "◎", tone: l ? "warning" : "green" }),
        /* @__PURE__ */ n(ne, { label: "USD / AUD", value: a ? a.rate.toFixed(4) : "—", detail: a ? `${a.provider === "twelvedata" ? "Twelve Data" : "Wealthfolio"} · ${lt(a.fetchedAt)}` : "No usable quote", icon: "↗", tone: v === "Warning" ? "warning" : "blue" }),
        /* @__PURE__ */ n(ne, { label: "ETFs", value: String(s.length), detail: `${s.filter((m) => m.snapshot).length} with constituent data`, icon: "◫", tone: "purple" }),
        /* @__PURE__ */ n(ne, { label: "Look-through coverage", value: i.coverage === null ? "—" : V(i.coverage), detail: i.eligibleValueAud > 0 ? `${U(i.coveredValueAud)} of eligible value` : "Cash excluded from coverage", icon: "⌁", tone: i.coverage !== null && i.coverage >= 0.95 ? "green" : "warning" })
      ] }),
      v && /* @__PURE__ */ o("div", { className: "quote-strip", children: [
        /* @__PURE__ */ n("span", { className: "quote-live-dot" }),
        /* @__PURE__ */ o("strong", { children: [
          "USD/AUD ",
          v.toLowerCase()
        ] }),
        /* @__PURE__ */ n("span", { children: a?.provider === "twelvedata" ? "Twelve Data" : "Wealthfolio fallback" }),
        /* @__PURE__ */ o("span", { children: [
          "Fetched ",
          a ? new Date(a.fetchedAt).toLocaleString() : "—"
        ] }),
        /* @__PURE__ */ n("button", { onClick: y, children: "Refresh" })
      ] }),
      /* @__PURE__ */ n(He, { warnings: b }),
      /* @__PURE__ */ o("div", { className: "chart-grid", children: [
        /* @__PURE__ */ n(fe, { title: "Instrument Allocation", subtitle: "What instruments did you buy? ETFs stay intact.", rows: Be(t.instrumentAllocation), valueLabel: "AUD value" }),
        /* @__PURE__ */ n(fe, { title: "True Exposure", subtitle: "What companies and asset classes move with you?", rows: Ge(i.rows), valueLabel: "Exposure" })
      ] }),
      /* @__PURE__ */ o("div", { className: "insight-row", children: [
        /* @__PURE__ */ o("div", { className: "panel insight-card", children: [
          /* @__PURE__ */ n("div", { className: "insight-icon", children: "✓" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("span", { className: "eyebrow", children: "Value conservation" }),
            /* @__PURE__ */ n("strong", { children: Math.abs(i.valueConservationDelta) < 0.5 ? "Balanced" : "Needs review" }),
            /* @__PURE__ */ n("p", { children: Math.abs(i.valueConservationDelta) < 0.5 ? "Every supported dollar is represented in True Exposure." : `${U(Math.abs(i.valueConservationDelta))} is not reconciled.` })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "panel insight-card", children: [
          /* @__PURE__ */ n("div", { className: "insight-icon", children: "↗" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("span", { className: "eyebrow", children: "Native performance" }),
            /* @__PURE__ */ n("strong", { children: "Keep benchmarks in Wealthfolio" }),
            /* @__PURE__ */ n("p", { children: "Portfolio X-Ray never replaces Wealthfolio's TWR, IRR, or benchmark engine." }),
            /* @__PURE__ */ n(P, { onClick: f, variant: "quiet", children: "Open Performance →" })
          ] })
        ] })
      ] })
    ] }),
    b.length > 0 && !w && /* @__PURE__ */ o("div", { className: "page-footnote", children: [
      /* @__PURE__ */ n(q, { value: "Disclosure", tone: "neutral" }),
      " X-Ray calculations use only supported, valued holdings; unresolved value remains visible in residual or opaque buckets."
    ] }),
    /* @__PURE__ */ n("span", { className: "visually-hidden", children: e.api ? "Wealthfolio connected" : "" })
  ] });
}
function Vt({ portfolio: e, onGoToSettings: t }) {
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ n(Q, { eyebrow: "Audit trail", title: "Holdings", detail: "Account-level rows stay untouched so every value can be traced back to Wealthfolio.", action: /* @__PURE__ */ o("span", { className: "data-source-pill", children: [
      /* @__PURE__ */ n("span", { className: "pulse-dot" }),
      "Wealthfolio source"
    ] }) }),
    e.holdings.length === 0 ? /* @__PURE__ */ n(Y, { icon: "▤", title: "No holdings to show", detail: "Select at least one active Wealthfolio account to see its raw holdings.", action: /* @__PURE__ */ n(P, { onClick: t, variant: "primary", children: "Choose accounts" }) }) : /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
      /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ o("strong", { children: [
            e.holdings.length,
            " holding",
            e.holdings.length === 1 ? "" : "s"
          ] }),
          /* @__PURE__ */ n("span", { children: "Same ticker in two accounts remains two rows." })
        ] }),
        /* @__PURE__ */ n("span", { className: "table-toolbar-note", children: "Portfolio weights use current AUD total only when complete" })
      ] }),
      /* @__PURE__ */ o(he, { children: [
        /* @__PURE__ */ n("thead", { children: /* @__PURE__ */ o("tr", { children: [
          /* @__PURE__ */ n("th", { children: "Ticker" }),
          /* @__PURE__ */ n("th", { children: "Name" }),
          /* @__PURE__ */ n("th", { children: "Account" }),
          /* @__PURE__ */ n("th", { children: "Type" }),
          /* @__PURE__ */ n("th", { className: "numeric", children: "Quantity" }),
          /* @__PURE__ */ n("th", { children: "Currency" }),
          /* @__PURE__ */ n("th", { className: "numeric", children: "Native value" }),
          /* @__PURE__ */ n("th", { className: "numeric", children: "AUD value" }),
          /* @__PURE__ */ n("th", { className: "numeric", children: "Weight" }),
          /* @__PURE__ */ n("th", { children: "Price updated" }),
          /* @__PURE__ */ n("th", { children: "Status" })
        ] }) }),
        /* @__PURE__ */ n("tbody", { children: e.holdings.map((i) => /* @__PURE__ */ n(Ot, { holding: i, totalAud: e.totalAud }, i.id)) })
      ] })
    ] })
  ] });
}
function Ot({ holding: e, totalAud: t }) {
  const i = e.audValue !== null && t && t > 0 && e.status === "valued" ? e.audValue / t : null, a = e.status === "valued" ? "good" : e.status === "unsupported-position" || e.status === "unsupported-currency" ? "critical" : "warning";
  return /* @__PURE__ */ o("tr", { children: [
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("strong", { className: "ticker-cell", children: e.ticker }) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("span", { className: "name-cell", children: e.name }) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ o("span", { className: "account-cell", children: [
      /* @__PURE__ */ n("span", { className: "account-avatar", children: e.accountName.slice(0, 1).toUpperCase() }),
      e.accountName
    ] }) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("span", { className: "type-label", children: e.type }) }),
    /* @__PURE__ */ n("td", { className: "numeric", children: Xe(e.quantity) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("span", { className: "currency-label", children: e.localCurrency }) }),
    /* @__PURE__ */ n("td", { className: "numeric", children: je(e.nativeValue, e.localCurrency) }),
    /* @__PURE__ */ n("td", { className: "numeric value-strong", children: e.audValue === null ? "—" : U(e.audValue) }),
    /* @__PURE__ */ n("td", { className: "numeric", children: V(i) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("span", { className: "date-cell", children: e.priceUpdatedAt ? new Date(e.priceUpdatedAt).toLocaleDateString() : "—" }) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n(q, { value: e.status === "valued" ? "Valued" : e.status.replace(/-/g, " "), tone: a }) })
  ] });
}
function Wt({ exposure: e, hasHoldings: t, onGoToSettings: i }) {
  const [a, s] = $(null), r = e.rows.find((c) => c.key === a) ?? null;
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ n(Q, { eyebrow: "Economic exposure", title: "X-Ray", detail: "Direct holdings and ETF-derived exposure are consolidated into one canonical view.", action: /* @__PURE__ */ o("div", { className: "coverage-pill", children: [
      /* @__PURE__ */ n("span", { children: "Coverage" }),
      /* @__PURE__ */ n("strong", { children: V(e.coverage) })
    ] }) }),
    t ? e.rows.length === 0 ? /* @__PURE__ */ n(Y, { icon: "⌁", title: "Exposure is incomplete", detail: "No holding has a usable AUD value yet. Native values remain available on Holdings." }) : /* @__PURE__ */ o(ce, { children: [
      /* @__PURE__ */ o("div", { className: "xray-summary", children: [
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ n("span", { className: "eyebrow", children: "Resolved value" }),
          /* @__PURE__ */ n("strong", { children: U(e.coveredValueAud) }),
          /* @__PURE__ */ o("span", { children: [
            "of ",
            U(e.eligibleValueAud),
            " eligible investable value"
          ] })
        ] }),
        /* @__PURE__ */ o("div", { children: [
          /* @__PURE__ */ n("span", { className: "eyebrow", children: "Reconciliation" }),
          /* @__PURE__ */ n("strong", { className: Math.abs(e.valueConservationDelta) < 0.5 ? "text-green" : "text-warning", children: Math.abs(e.valueConservationDelta) < 0.5 ? "Balanced" : U(Math.abs(e.valueConservationDelta)) }),
          /* @__PURE__ */ n("span", { children: "including cash, residuals, and opaque ETFs" })
        ] })
      ] }),
      /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
        /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ o("strong", { children: [
              e.rows.length,
              " canonical exposure",
              e.rows.length === 1 ? "" : "s"
            ] }),
            /* @__PURE__ */ n("span", { children: "Sources opens account- and ETF-level contributions." })
          ] }),
          /* @__PURE__ */ n("span", { className: "table-toolbar-note", children: "Cash is excluded from Coverage" })
        ] }),
        /* @__PURE__ */ o(he, { children: [
          /* @__PURE__ */ n("thead", { children: /* @__PURE__ */ o("tr", { children: [
            /* @__PURE__ */ n("th", { children: "Ticker / bucket" }),
            /* @__PURE__ */ n("th", { children: "Security / bucket" }),
            /* @__PURE__ */ n("th", { className: "numeric", children: "Direct" }),
            /* @__PURE__ */ n("th", { className: "numeric", children: "Via ETFs" }),
            /* @__PURE__ */ n("th", { className: "numeric", children: "Total exposure" }),
            /* @__PURE__ */ n("th", { className: "numeric", children: "Portfolio %" }),
            /* @__PURE__ */ n("th", { children: "Sources" }),
            /* @__PURE__ */ n("th", { children: "Sector" }),
            /* @__PURE__ */ n("th", { children: "Country" }),
            /* @__PURE__ */ n("th", { children: "Status" })
          ] }) }),
          /* @__PURE__ */ n("tbody", { children: e.rows.map((c) => /* @__PURE__ */ n(qt, { row: c, selected: c.key === a, onSelect: () => s(c.key === a ? null : c.key) }, c.key)) })
        ] })
      ] }),
      r && /* @__PURE__ */ n(Lt, { row: r, onClose: () => s(null) })
    ] }) : /* @__PURE__ */ n(Y, { icon: "⌁", title: "Nothing to X-Ray yet", detail: "Add holdings to the selected Wealthfolio accounts, then return here.", action: /* @__PURE__ */ n(P, { onClick: i, variant: "primary", children: "Choose accounts" }) })
  ] });
}
function qt({ row: e, selected: t, onSelect: i }) {
  const a = e.sources.some((s) => s.kind === "opaque" || s.kind === "residual") ? "warning" : "good";
  return /* @__PURE__ */ o("tr", { className: t ? "row-selected" : "", children: [
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("strong", { className: "ticker-cell", children: e.ticker ?? "—" }) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n("span", { className: "name-cell", children: e.label }) }),
    /* @__PURE__ */ n("td", { className: "numeric", children: e.directAud ? U(e.directAud) : "—" }),
    /* @__PURE__ */ n("td", { className: "numeric", children: e.viaEtfsAud ? U(e.viaEtfsAud) : "—" }),
    /* @__PURE__ */ n("td", { className: "numeric value-strong", children: U(e.totalAud) }),
    /* @__PURE__ */ n("td", { className: "numeric", children: V(e.portfolioWeight) }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ o("button", { className: "source-button", onClick: i, children: [
      /* @__PURE__ */ n("span", { className: "source-count", children: e.sources.length }),
      " View Sources"
    ] }) }),
    /* @__PURE__ */ n("td", { children: e.sector ?? "—" }),
    /* @__PURE__ */ n("td", { children: e.country ?? "—" }),
    /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n(q, { value: e.status ?? (e.type === "cash" ? "Cash" : "Resolved"), tone: e.status ? a : "good" }) })
  ] });
}
function Lt({ row: e, onClose: t }) {
  const i = e.sources.filter((r) => r.kind === "direct"), a = e.sources.filter((r) => r.kind === "etf"), s = e.sources.filter((r) => r.kind === "residual" || r.kind === "opaque");
  return /* @__PURE__ */ o("div", { className: "source-drawer panel", children: [
    /* @__PURE__ */ o("div", { className: "drawer-head", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("span", { className: "eyebrow", children: "Exposure sources" }),
        /* @__PURE__ */ n("h2", { children: e.label }),
        /* @__PURE__ */ n("strong", { children: U(e.totalAud) })
      ] }),
      /* @__PURE__ */ n(P, { onClick: t, variant: "quiet", children: "Close" })
    ] }),
    /* @__PURE__ */ o("div", { className: "source-columns", children: [
      /* @__PURE__ */ n(pe, { title: "Direct", sources: i.map((r) => ({ label: r.accountName, amountAud: r.amountAud })) }),
      /* @__PURE__ */ n(pe, { title: "Via ETFs", sources: a.map((r) => ({ label: `${r.etfSymbol}${r.path.length > 1 ? ` · ${r.path.join(" → ")}` : ""}`, amountAud: r.amountAud })) }),
      /* @__PURE__ */ n(pe, { title: "Residual / opaque", sources: s.map((r) => ({ label: r.reason, amountAud: r.amountAud })) })
    ] })
  ] });
}
function pe({ title: e, sources: t }) {
  return /* @__PURE__ */ o("div", { className: "source-group", children: [
    /* @__PURE__ */ n("span", { className: "eyebrow", children: e }),
    t.length === 0 ? /* @__PURE__ */ n("p", { className: "muted", children: "None" }) : t.map((i, a) => /* @__PURE__ */ o("div", { className: "source-line", children: [
      /* @__PURE__ */ n("span", { children: i.label }),
      /* @__PURE__ */ n("strong", { children: U(i.amountAud) })
    ] }, `${i.label}-${a}`))
  ] });
}
function jt({
  etfData: e,
  onRefreshEtf: t,
  onSaveSnapshot: i,
  onDisableSnapshot: a
}) {
  const [s, r] = $(e[0]?.asset.etfKey ?? ""), [c, u] = $(""), [f, y] = $(null), [k, v] = $(!1), [b, w] = $(null), l = e.find((d) => d.asset.etfKey === s) ?? e[0] ?? null;
  B(() => {
    !l && e[0] && r(e[0].asset.etfKey);
  }, [e, l]);
  const m = () => {
    if (!l) return;
    const d = nt(c, {
      etfKey: l.asset.etfKey,
      provider: "manual",
      asOfDate: (/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
      fetchedAt: (/* @__PURE__ */ new Date()).toISOString()
    });
    y(d), w(null);
  }, T = async () => {
    if (!(!l || !f?.validation.snapshot)) {
      v(!0), w(null);
      try {
        await i(f.validation.snapshot, l.version), w("Manual snapshot saved. It is now the pinned local source for this ETF."), y(null), u("");
      } catch (d) {
        w(d instanceof Error ? d.message : "Unable to save the snapshot");
      } finally {
        v(!1);
      }
    }
  }, D = async () => {
    if (l) {
      v(!0), w(null);
      try {
        await t(l.asset.etfKey), w("ETF data refreshed from the configured resolver.");
      } catch (d) {
        w(d instanceof Error ? d.message : "ETF refresh failed; the last valid snapshot is still active.");
      } finally {
        v(!1);
      }
    }
  }, N = () => {
    if (!l?.snapshot) return;
    const d = new Blob([at(l.snapshot)], { type: "text/csv;charset=utf-8" }), g = URL.createObjectURL(d), p = document.createElement("a");
    p.href = g, p.download = `${l.asset.symbol.toLowerCase()}-holdings.csv`, p.click(), URL.revokeObjectURL(g);
  }, S = (d) => {
    if (!d) return;
    const g = new FileReader();
    g.onload = () => u(typeof g.result == "string" ? g.result : ""), g.readAsText(d);
  };
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ n(Q, { eyebrow: "Look-through sources", title: "ETF Data", detail: "Keep provider snapshots separate from current portfolio values. As-of date and fetched time are always distinct.", action: /* @__PURE__ */ n("span", { className: "data-source-pill", children: "Local cache · 24 hr TTL" }) }),
    e.length ? /* @__PURE__ */ o(ce, { children: [
      /* @__PURE__ */ o("div", { className: "panel table-panel", children: [
        /* @__PURE__ */ o("div", { className: "table-toolbar", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ o("strong", { children: [
              e.length,
              " ETF",
              e.length === 1 ? "" : "s"
            ] }),
            /* @__PURE__ */ n("span", { children: "Refresh only missing or stale automatic snapshots." })
          ] }),
          /* @__PURE__ */ n("span", { className: "table-toolbar-note", children: "Manual CSV paste works in self-hosted Web/Docker" })
        ] }),
        /* @__PURE__ */ o(he, { children: [
          /* @__PURE__ */ n("thead", { children: /* @__PURE__ */ o("tr", { children: [
            /* @__PURE__ */ n("th", { children: "ETF" }),
            /* @__PURE__ */ n("th", { children: "Provider" }),
            /* @__PURE__ */ n("th", { children: "Holdings" }),
            /* @__PURE__ */ n("th", { children: "As of" }),
            /* @__PURE__ */ n("th", { children: "Fetched" }),
            /* @__PURE__ */ n("th", { children: "Resolved weight" }),
            /* @__PURE__ */ n("th", { children: "Status" }),
            /* @__PURE__ */ n("th", { children: "Actions" })
          ] }) }),
          /* @__PURE__ */ n("tbody", { children: e.map((d) => /* @__PURE__ */ o("tr", { className: l?.asset.etfKey === d.asset.etfKey ? "row-selected" : "", onClick: () => r(d.asset.etfKey), children: [
            /* @__PURE__ */ o("td", { children: [
              /* @__PURE__ */ n("strong", { className: "ticker-cell", children: d.asset.symbol }),
              /* @__PURE__ */ n("span", { className: "table-subtext", children: d.asset.name })
            ] }),
            /* @__PURE__ */ n("td", { children: d.snapshot?.provider ?? "—" }),
            /* @__PURE__ */ n("td", { children: d.snapshot ? d.snapshot.holdings.length : "—" }),
            /* @__PURE__ */ n("td", { children: d.snapshot?.asOfDate ?? "—" }),
            /* @__PURE__ */ n("td", { children: d.snapshot ? new Date(d.snapshot.fetchedAt).toLocaleString() : "—" }),
            /* @__PURE__ */ n("td", { children: V(d.resolvedWeight) }),
            /* @__PURE__ */ n("td", { children: /* @__PURE__ */ n(q, { value: d.status, tone: Xt(d.status) }) }),
            /* @__PURE__ */ n("td", { children: /* @__PURE__ */ o("div", { className: "row-actions", children: [
              /* @__PURE__ */ n(P, { onClick: () => {
                r(d.asset.etfKey), t(d.asset.etfKey);
              }, variant: "quiet", children: "Refresh" }),
              /* @__PURE__ */ n(P, { onClick: () => {
                r(d.asset.etfKey);
              }, variant: "quiet", children: "View" })
            ] }) })
          ] }, d.asset.etfKey)) })
        ] })
      ] }),
      l && /* @__PURE__ */ o("div", { className: "etf-workspace", children: [
        /* @__PURE__ */ o("div", { className: "panel etf-detail-card", children: [
          /* @__PURE__ */ o("div", { className: "detail-heading", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "Selected ETF" }),
              /* @__PURE__ */ o("h2", { children: [
                l.asset.symbol,
                " ",
                /* @__PURE__ */ n("span", { children: l.asset.name })
              ] })
            ] }),
            /* @__PURE__ */ o("div", { className: "row-actions", children: [
              /* @__PURE__ */ n(P, { onClick: () => {
                D();
              }, variant: "secondary", disabled: k, children: "↻ Refresh" }),
              l.snapshot && /* @__PURE__ */ n(P, { onClick: N, variant: "quiet", children: "Export CSV" }),
              l.snapshot && /* @__PURE__ */ n(P, { onClick: () => {
                l && a(l.asset.etfKey);
              }, variant: "danger", children: "Disable snapshot" })
            ] })
          ] }),
          l.snapshot ? /* @__PURE__ */ o("div", { className: "snapshot-meta", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "Provider" }),
              /* @__PURE__ */ n("strong", { children: l.snapshot.provider })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "As of" }),
              /* @__PURE__ */ n("strong", { children: l.snapshot.asOfDate })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "Fetched" }),
              /* @__PURE__ */ n("strong", { children: new Date(l.snapshot.fetchedAt).toLocaleString() })
            ] }),
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "Weight outcome" }),
              /* @__PURE__ */ n("strong", { children: l.snapshot.normalized ? "Normalized" : l.snapshot.weightSum < 1 ? `${V(1 - l.snapshot.weightSum)} residual` : "100% resolved" })
            ] })
          ] }) : /* @__PURE__ */ o("div", { className: "missing-inline", children: [
            /* @__PURE__ */ n(q, { value: "Missing", tone: "warning" }),
            /* @__PURE__ */ n("span", { children: "No valid snapshot yet. Paste the issuer holdings CSV to preserve the ETF as an opaque exposure until resolved." })
          ] }),
          l.snapshot && /* @__PURE__ */ o("div", { className: "underlying-preview", children: [
            /* @__PURE__ */ n("span", { className: "eyebrow", children: "Current constituents" }),
            /* @__PURE__ */ n("div", { className: "mini-constituents", children: l.snapshot.holdings.slice(0, 8).map((d) => /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { children: d.symbol ?? "—" }),
              /* @__PURE__ */ n("strong", { children: d.name }),
              /* @__PURE__ */ n("em", { children: V(d.weight) })
            ] }, `${d.symbol}-${d.name}`)) }),
            l.snapshot.holdings.length > 8 && /* @__PURE__ */ o("span", { className: "muted", children: [
              "+ ",
              l.snapshot.holdings.length - 8,
              " more retained in the snapshot"
            ] })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "panel csv-card", children: [
          /* @__PURE__ */ o("div", { className: "detail-heading", children: [
            /* @__PURE__ */ o("div", { children: [
              /* @__PURE__ */ n("span", { className: "eyebrow", children: "Universal fallback" }),
              /* @__PURE__ */ n("h2", { children: "Import or paste CSV" }),
              /* @__PURE__ */ o("p", { children: [
                "Required: ",
                /* @__PURE__ */ n("code", { children: "symbol" }),
                " or ",
                /* @__PURE__ */ n("code", { children: "name" }),
                ", plus ",
                /* @__PURE__ */ n("code", { children: "weight" }),
                ". Fractional values, percentages, and bare percentages are previewed before saving."
              ] })
            ] }),
            /* @__PURE__ */ o("label", { className: "file-button", children: [
              "Choose file",
              /* @__PURE__ */ n("input", { type: "file", accept: ".csv,text/csv", onChange: (d) => S(d.target.files?.[0]) })
            ] })
          ] }),
          /* @__PURE__ */ n("textarea", { value: c, onChange: (d) => u(d.target.value), placeholder: `symbol,name,weight,isin,mic,country,currency,sector,assetClass
NVDA,NVIDIA Corp,0.084,US67066G1040,XNAS,US,USD,Technology,Equity`, rows: 8 }),
          /* @__PURE__ */ o("div", { className: "form-actions", children: [
            /* @__PURE__ */ n(P, { onClick: m, variant: "secondary", disabled: !c.trim(), children: "Preview" }),
            f?.validation.accepted && /* @__PURE__ */ n(P, { onClick: () => {
              T();
            }, variant: "primary", disabled: k, children: k ? "Saving…" : "Save Manual Snapshot" })
          ] }),
          f && /* @__PURE__ */ n(Ht, { preview: f }),
          b && /* @__PURE__ */ n("div", { className: "inline-message", children: b })
        ] })
      ] })
    ] }) : /* @__PURE__ */ n(Y, { icon: "◫", title: "No ETFs in the selected accounts", detail: "ETF Data appears when Wealthfolio reports an ETF holding. Direct securities do not need constituent data." })
  ] });
}
function Xt(e) {
  return e === "Fresh" ? "good" : e === "Critical" || e === "Invalid" ? "critical" : e === "Missing" || e === "Warning" || e === "Stale" ? "warning" : "neutral";
}
function Ht({ preview: e }) {
  return /* @__PURE__ */ o("div", { className: "csv-preview", children: [
    /* @__PURE__ */ o("div", { className: "preview-summary", children: [
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("span", { className: "eyebrow", children: "Parsed rows" }),
        /* @__PURE__ */ n("strong", { children: e.rows.length })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("span", { className: "eyebrow", children: "Detected unit" }),
        /* @__PURE__ */ n("strong", { children: e.detectedUnit })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("span", { className: "eyebrow", children: "Weight sum" }),
        /* @__PURE__ */ n("strong", { children: V(e.weightSum) })
      ] }),
      /* @__PURE__ */ o("div", { children: [
        /* @__PURE__ */ n("span", { className: "eyebrow", children: "Outcome" }),
        /* @__PURE__ */ n(q, { value: e.validation.status, tone: e.validation.accepted ? "good" : "critical" })
      ] })
    ] }),
    e.missingFields.length > 0 && /* @__PURE__ */ o("p", { className: "preview-error", children: [
      "Missing columns: ",
      e.missingFields.join(", ")
    ] }),
    e.issues.length > 0 && /* @__PURE__ */ n("p", { className: "preview-warning", children: e.issues.join(" ") }),
    e.validation.message && /* @__PURE__ */ n("p", { className: e.validation.accepted ? "preview-note" : "preview-error", children: e.validation.message }),
    /* @__PURE__ */ n("div", { className: "preview-table", children: /* @__PURE__ */ o("table", { children: [
      /* @__PURE__ */ n("thead", { children: /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ n("th", { children: "Symbol" }),
        /* @__PURE__ */ n("th", { children: "Name" }),
        /* @__PURE__ */ n("th", { children: "Weight" }),
        /* @__PURE__ */ n("th", { children: "Country" }),
        /* @__PURE__ */ n("th", { children: "Sector" })
      ] }) }),
      /* @__PURE__ */ n("tbody", { children: e.rows.slice(0, 12).map((t, i) => /* @__PURE__ */ o("tr", { children: [
        /* @__PURE__ */ n("td", { children: t.symbol ?? "—" }),
        /* @__PURE__ */ n("td", { children: t.name }),
        /* @__PURE__ */ n("td", { children: V(t.weight) }),
        /* @__PURE__ */ n("td", { children: t.country ?? "—" }),
        /* @__PURE__ */ n("td", { children: t.sector ?? "—" })
      ] }, `${t.symbol}-${t.name}-${i}`)) })
    ] }) })
  ] });
}
const _t = ["stock", "etf", "cash", "fixed-income", "derivative", "other", "unknown"];
function Bt({
  activeAccounts: e,
  selectedAccounts: t,
  settings: i,
  holdings: a,
  etfData: s,
  hasTwelveDataKey: r,
  hasAlphaVantageKey: c,
  onSaveAccountSelection: u,
  onSaveSecret: f,
  onDeleteSecret: y,
  onSetLiveFxPolling: k,
  onSetTypeOverride: v,
  onSetProviderMode: b,
  onSetPinnedProvider: w,
  onSetProviderIdentity: l,
  onSetAliasMapping: m,
  onRemoveAliasMapping: T
}) {
  const [D, N] = $(t.map((h) => h.id)), [S, d] = $(""), [g, p] = $(""), [x, I] = $(i.providerIdentities), [K, E] = $(""), [O, me] = $(""), [L, G] = $(""), [W, Z] = $(""), [j, X] = $(null);
  B(() => N(t.map((h) => h.id)), [t]), B(() => I(i.providerIdentities), [i.providerIdentities]);
  const J = async () => {
    await u(D), X("Account selection saved.");
  }, ee = async (h, A, H) => {
    await f(h, A), X(`${H} key saved securely through Wealthfolio.`), h.includes("twelvedata") ? d("") : p("");
  }, te = async (h, A) => {
    await y(h), X(`${A} key removed.`);
  }, C = async () => {
    !K.trim() || !O.trim() || !L.trim() || !W.trim() || (await m(K, O, L, W), X("Scoped alias saved. It applies only to this provider, ETF, and original identifier."), G(""), Z(""));
  }, R = a.filter((h) => h.status === "unknown-instrument" || h.type === "unknown");
  return /* @__PURE__ */ o("div", { className: "page-stack", children: [
    /* @__PURE__ */ n(Q, { eyebrow: "Addon-owned preferences", title: "Settings", detail: "Only Portfolio X-Ray configuration lives here. Wealthfolio remains the source of truth for accounts, holdings, prices, and performance." }),
    /* @__PURE__ */ o("div", { className: "settings-grid", children: [
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "◎" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "Included accounts" }),
            /* @__PURE__ */ n("p", { children: "New active accounts are included once. Explicit deselections remain deselected." })
          ] })
        ] }),
        /* @__PURE__ */ n("div", { className: "account-select-list", children: e.length === 0 ? /* @__PURE__ */ n("p", { className: "muted", children: "No active Wealthfolio accounts found." }) : e.map((h) => /* @__PURE__ */ o("label", { className: "account-select", children: [
          /* @__PURE__ */ n("input", { type: "checkbox", checked: D.includes(h.id), onChange: (A) => N((H) => A.target.checked ? [...H, h.id] : H.filter((Ve) => Ve !== h.id)) }),
          /* @__PURE__ */ n("span", { className: "account-avatar", children: h.name.slice(0, 1).toUpperCase() }),
          /* @__PURE__ */ o("span", { children: [
            /* @__PURE__ */ n("strong", { children: h.name }),
            /* @__PURE__ */ o("em", { children: [
              h.currency,
              " · ",
              h.isActive ? "Active" : "Inactive"
            ] })
          ] }),
          /* @__PURE__ */ n("span", { className: "checkmark", children: "✓" })
        ] }, h.id)) }),
        /* @__PURE__ */ n("div", { className: "form-actions", children: /* @__PURE__ */ n(P, { onClick: () => {
          J();
        }, variant: "primary", children: "Save account selection" }) })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "↗" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "Live USD / AUD" }),
            /* @__PURE__ */ n("p", { children: "Refresh while Portfolio X-Ray is visible. The quote is shared through addon storage for five-minute reuse." })
          ] })
        ] }),
        /* @__PURE__ */ n(_e, { checked: i.liveFxPolling, onChange: (h) => {
          k(h);
        }, label: "Enable visible-page polling" }),
        /* @__PURE__ */ o("div", { className: "privacy-note", children: [
          /* @__PURE__ */ n("span", { className: "pulse-dot" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("strong", { children: "Provider-safe request" }),
            /* @__PURE__ */ n("p", { children: "External requests include only USD/AUD and provider authentication — never account, quantity, value, cost basis, or transaction data." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "⌘" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "Provider keys" }),
            /* @__PURE__ */ o("p", { children: [
              "Optional keys are stored through ",
              /* @__PURE__ */ n("code", { children: "ctx.api.secrets" }),
              ". Missing keys never block cached or Manual CSV data."
            ] })
          ] })
        ] }),
        /* @__PURE__ */ n(we, { label: "Twelve Data", hasKey: r, value: S, onChange: d, onSave: () => {
          ee("twelvedata.apiKey", S, "Twelve Data");
        }, onRemove: () => {
          te("twelvedata.apiKey", "Twelve Data");
        } }),
        /* @__PURE__ */ n(we, { label: "Alpha Vantage", hasKey: c, value: g, onChange: p, onSave: () => {
          ee("alphaVantage.apiKey", g, "Alpha Vantage");
        }, onRemove: () => {
          te("alphaVantage.apiKey", "Alpha Vantage");
        } })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "◫" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "ETF provider modes" }),
            /* @__PURE__ */ n("p", { children: "Auto follows cache → issuer → Alpha Vantage → Manual. Pinned mode never silently changes source." })
          ] })
        ] }),
        s.length === 0 ? /* @__PURE__ */ n("p", { className: "muted", children: "ETF provider controls appear when ETFs are held." }) : /* @__PURE__ */ n("div", { className: "provider-list", children: s.map((h) => /* @__PURE__ */ o("div", { className: "provider-row", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("strong", { children: h.asset.symbol }),
            /* @__PURE__ */ n("span", { children: h.snapshot?.provider ?? "No snapshot" })
          ] }),
          /* @__PURE__ */ n("input", { className: "provider-identity", value: x[h.asset.etfKey] ?? "", onChange: (A) => I((H) => ({ ...H, [h.asset.etfKey]: A.target.value })), onBlur: (A) => {
            l(h.asset.etfKey, A.target.value);
          }, placeholder: "Issuer ID", title: "iShares product ID or Betashares ticker" }),
          /* @__PURE__ */ o("select", { value: i.providerModes[h.asset.etfKey] ?? "auto", onChange: (A) => {
            b(h.asset.etfKey, A.target.value);
          }, children: [
            /* @__PURE__ */ n("option", { value: "auto", children: "Auto" }),
            /* @__PURE__ */ n("option", { value: "pinned", children: "Pinned" })
          ] }),
          (i.providerModes[h.asset.etfKey] ?? "auto") === "pinned" && /* @__PURE__ */ o("select", { value: i.pinnedProviders[h.asset.etfKey] ?? "alpha-vantage", onChange: (A) => {
            w(h.asset.etfKey, A.target.value);
          }, children: [
            /* @__PURE__ */ n("option", { value: "ishares", children: "iShares" }),
            /* @__PURE__ */ n("option", { value: "betashares", children: "Betashares" }),
            /* @__PURE__ */ n("option", { value: "alpha-vantage", children: "Alpha Vantage" })
          ] }),
          /* @__PURE__ */ n(q, { value: h.status, tone: h.status === "Fresh" ? "good" : "warning" })
        ] }, h.asset.etfKey)) })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "⌁" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "Type overrides" }),
            /* @__PURE__ */ n("p", { children: "Use a local override when an instrument profile is unresolved. Overrides affect only X-Ray classification." })
          ] })
        ] }),
        R.length === 0 ? /* @__PURE__ */ n("p", { className: "muted", children: "All current instrument types are resolved." }) : /* @__PURE__ */ n("div", { className: "override-list", children: R.map((h) => /* @__PURE__ */ o("div", { className: "override-row", children: [
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("strong", { children: h.ticker }),
            /* @__PURE__ */ o("span", { children: [
              h.name,
              " · ",
              h.identityKey ?? h.id
            ] })
          ] }),
          /* @__PURE__ */ n("select", { value: i.typeOverrides[h.profileId ?? h.identityKey ?? h.id] ?? h.type, onChange: (A) => {
            v(h.profileId ?? h.identityKey ?? h.id, A.target.value);
          }, children: _t.map((A) => /* @__PURE__ */ n("option", { value: A, children: A }, A)) })
        ] }, h.id)) })
      ] }),
      /* @__PURE__ */ o("section", { className: "panel settings-card", children: [
        /* @__PURE__ */ o("div", { className: "settings-heading", children: [
          /* @__PURE__ */ n("div", { className: "settings-icon", children: "↔" }),
          /* @__PURE__ */ o("div", { children: [
            /* @__PURE__ */ n("h2", { children: "Scoped identity aliases" }),
            /* @__PURE__ */ n("p", { children: "Map a provider's original identifier to a canonical key without affecting unrelated ETFs or providers." })
          ] })
        ] }),
        /* @__PURE__ */ o("div", { className: "alias-form", children: [
          /* @__PURE__ */ n("input", { value: K, onChange: (h) => E(h.target.value), placeholder: "Provider, e.g. manual" }),
          /* @__PURE__ */ n("input", { value: O, onChange: (h) => me(h.target.value), placeholder: "ETF key, e.g. XNAS:IVV" }),
          /* @__PURE__ */ n("input", { value: L, onChange: (h) => G(h.target.value), placeholder: "Original identity key" }),
          /* @__PURE__ */ n("input", { value: W, onChange: (h) => Z(h.target.value), placeholder: "Target canonical key" }),
          /* @__PURE__ */ n(P, { onClick: () => {
            C();
          }, variant: "secondary", children: "Save alias" })
        ] }),
        Object.entries(i.aliases).length === 0 ? /* @__PURE__ */ n("p", { className: "muted", children: "No aliases configured." }) : /* @__PURE__ */ n("div", { className: "alias-list", children: Object.entries(i.aliases).map(([h, A]) => /* @__PURE__ */ o("div", { className: "alias-row", children: [
          /* @__PURE__ */ n("span", { children: h }),
          /* @__PURE__ */ o("strong", { children: [
            "→ ",
            A
          ] }),
          /* @__PURE__ */ n("button", { type: "button", onClick: () => {
            T(h);
          }, children: "Remove" })
        ] }, h)) })
      ] })
    ] }),
    j && /* @__PURE__ */ n("div", { className: "inline-message", children: j }),
    /* @__PURE__ */ o("div", { className: "settings-footer", children: [
      /* @__PURE__ */ n(q, { value: "Local-first", tone: "good" }),
      /* @__PURE__ */ n("span", { children: "Settings, aliases, Manual datasets, and valid ETF caches are persisted through Wealthfolio addon storage. Secrets never enter JSON, localStorage, or source code." })
    ] })
  ] });
}
function we({ label: e, hasKey: t, value: i, onChange: a, onSave: s, onRemove: r }) {
  return /* @__PURE__ */ o("div", { className: "secret-field", children: [
    /* @__PURE__ */ o("label", { children: [
      /* @__PURE__ */ n("span", { children: e }),
      /* @__PURE__ */ n("span", { className: t ? "secret-status secret-set" : "secret-status", children: t ? "Configured" : "Not configured" })
    ] }),
    /* @__PURE__ */ o("div", { className: "secret-input-row", children: [
      /* @__PURE__ */ n("input", { type: "password", value: i, onChange: (c) => a(c.target.value), placeholder: t ? "Enter a new key to replace" : "Paste optional API key", autoComplete: "off" }),
      /* @__PURE__ */ n(P, { onClick: s, variant: "secondary", disabled: !i.trim(), children: "Save" }),
      t && /* @__PURE__ */ n(P, { onClick: r, variant: "quiet", children: "Remove" })
    ] })
  ] });
}
function Gt({ ctx: e }) {
  const [t, i] = $("overview"), a = zt(e), s = () => {
    e.api.navigation.navigate("/performance").catch((c) => {
      e.api.toast.error(c instanceof Error ? c.message : "Unable to open Wealthfolio Performance");
    });
  }, r = a.loading && !a.lastLoadedAt ? /* @__PURE__ */ o("div", { className: "loading-state", children: [
    /* @__PURE__ */ n("div", { className: "loading-orbit", children: "X" }),
    /* @__PURE__ */ n("h2", { children: "Reading Wealthfolio" }),
    /* @__PURE__ */ n("p", { children: "Loading selected accounts, current values, and cached ETF data…" })
  ] }) : a.error && !a.lastLoadedAt ? /* @__PURE__ */ o("div", { className: "error-state", children: [
    /* @__PURE__ */ n("div", { className: "empty-icon", children: "!" }),
    /* @__PURE__ */ n("h2", { children: "Portfolio X-Ray could not load" }),
    /* @__PURE__ */ n("p", { children: a.error }),
    /* @__PURE__ */ n(P, { onClick: () => {
      a.refresh();
    }, variant: "primary", children: "Retry" })
  ] }) : /* @__PURE__ */ o(ce, { children: [
    a.error && /* @__PURE__ */ o("div", { className: "global-error", children: [
      /* @__PURE__ */ n("span", { children: "!" }),
      a.error,
      /* @__PURE__ */ n("button", { onClick: () => {
        a.refresh();
      }, children: "Retry" })
    ] }),
    t === "overview" && /* @__PURE__ */ n(Mt, { ctx: e, portfolio: a.portfolio, exposure: a.exposure, fxQuote: a.fxQuote, etfData: a.etfData, baseCurrency: a.baseCurrency, selectedAccounts: a.selectedAccounts, newlyIncludedAccounts: a.newlyIncludedAccounts, onNavigatePerformance: s, onRefreshFx: () => {
      a.refresh({ forceFx: !0 });
    }, onGoToSettings: () => i("settings") }),
    t === "holdings" && /* @__PURE__ */ n(Vt, { portfolio: a.portfolio, onGoToSettings: () => i("settings") }),
    t === "xray" && /* @__PURE__ */ n(Wt, { exposure: a.exposure, hasHoldings: a.portfolio.holdings.length > 0, onGoToSettings: () => i("settings") }),
    t === "etf-data" && /* @__PURE__ */ n(jt, { etfData: a.etfData, onRefreshEtf: a.refreshEtf, onSaveSnapshot: a.saveSnapshot, onDisableSnapshot: a.disableSnapshot }),
    t === "settings" && /* @__PURE__ */ n(Bt, { activeAccounts: a.activeAccounts, selectedAccounts: a.selectedAccounts, settings: a.settings, holdings: a.holdings, etfData: a.etfData, hasTwelveDataKey: a.hasTwelveDataKey, hasAlphaVantageKey: a.hasAlphaVantageKey, onSaveAccountSelection: a.saveAccountSelection, onSaveSecret: a.saveSecret, onDeleteSecret: a.deleteSecret, onSetLiveFxPolling: a.setLiveFxPolling, onSetTypeOverride: a.setTypeOverride, onSetProviderMode: a.setProviderMode, onSetPinnedProvider: a.setPinnedProvider, onSetProviderIdentity: a.setProviderIdentity, onSetAliasMapping: a.setAliasMapping, onRemoveAliasMapping: a.removeAliasMapping })
  ] });
  return /* @__PURE__ */ n(Le, { page: t, onPageChange: i, accounts: a.selectedAccounts, children: r });
}
const Jt = '*{box-sizing:border-box}.app-shell{--ink: #e9eef7;--muted: #8794aa;--faint: #5f6c80;--surface: #121a28;--surface-2: #182235;--surface-3: #202d43;--line: rgba(155, 177, 212, .14);--line-strong: rgba(155, 177, 212, .24);--green: #65d6a7;--blue: #7ca7ff;--yellow: #f8c86b;--red: #ff887d;--purple: #d08dff;min-height:100vh;display:flex;background:#0c1320;color:var(--ink);font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;font-size:14px;line-height:1.45}.app-shell button,.app-shell input,.app-shell select,.app-shell textarea{font:inherit}.app-shell button{cursor:pointer}.app-shell button:disabled{cursor:not-allowed;opacity:.48}.app-shell h1,.app-shell h2,.app-shell p{margin:0}.app-shell h1{font-size:29px;letter-spacing:-.035em;line-height:1.1}.app-shell h2{font-size:16px;letter-spacing:-.02em}.app-shell code{color:#c7d8ff;font-size:.9em}.muted{color:var(--muted)}.text-green{color:var(--green)!important}.text-warning{color:var(--yellow)!important}.visually-hidden{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.sidebar{width:236px;flex:0 0 236px;min-height:100vh;padding:27px 16px 18px;border-right:1px solid var(--line);background:#0e1726;display:flex;flex-direction:column}.brand{display:flex;gap:11px;align-items:center;padding:0 11px 28px}.brand-mark{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;color:#092018;font-weight:800;background:linear-gradient(135deg,#8de6c1,#56b8cf);box-shadow:0 0 0 4px #65d6a714}.brand strong{display:block;font-size:13px;letter-spacing:-.01em}.brand span{display:block;color:var(--faint);font-size:11px;margin-top:1px}.main-nav{display:grid;gap:4px}.nav-item{width:100%;border:0;border-radius:9px;background:transparent;color:var(--muted);padding:10px 12px;text-align:left;display:flex;gap:12px;align-items:center;transition:.15s ease}.nav-item:hover{background:#7ca7ff14;color:var(--ink)}.nav-active{color:var(--ink);background:linear-gradient(90deg,#65d6a726,#65d6a70a);box-shadow:inset 2px 0 var(--green)}.nav-icon{width:16px;text-align:center;color:var(--faint);font-size:16px}.nav-active .nav-icon{color:var(--green)}.sidebar-bottom{margin-top:auto;display:grid;gap:12px}.account-summary{margin:4px 7px 0;padding:14px;border:1px solid var(--line);background:#ffffff06;border-radius:12px}.account-summary strong{display:block;font-size:23px;line-height:1.1;margin:4px 0 2px}.account-summary>span:last-child{color:var(--muted);font-size:11px}.local-first{color:var(--faint);font-size:11px;padding:0 11px;display:flex;gap:7px;align-items:center}.pulse-dot,.quote-live-dot{width:7px;height:7px;border-radius:50%;background:var(--green);display:inline-block;box-shadow:0 0 0 4px #65d6a71a}.main-content{width:calc(100% - 236px);min-width:0;background:radial-gradient(circle at 80% -15%,rgba(65,103,162,.13),transparent 35%),#0c1320}.page-stack{max-width:1440px;margin:0 auto;padding:36px 42px 54px;display:grid;gap:22px}.section-header{display:flex;justify-content:space-between;gap:20px;align-items:flex-end;padding-bottom:5px}.section-header h1{margin-top:5px}.section-header p{color:var(--muted);margin-top:8px}.eyebrow{display:block;color:var(--faint);text-transform:uppercase;font-size:10px;font-weight:700;letter-spacing:.12em}.button{border:1px solid transparent;border-radius:8px;padding:8px 12px;color:var(--ink);white-space:nowrap;transition:.15s ease}.button-primary{color:#082018;background:var(--green);border-color:var(--green);font-weight:700}.button-primary:hover{background:#8ce6c0}.button-secondary{background:var(--surface-3);border-color:var(--line-strong)}.button-secondary:hover,.button-quiet:hover{border-color:#7ca7ff8c;background:#7ca7ff1a}.button-quiet{background:transparent;color:#a8bff3;border-color:var(--line)}.button-danger{background:#ff887d12;color:var(--red);border-color:#ff887d3b}.data-source-pill,.coverage-pill{display:inline-flex;gap:8px;align-items:center;border:1px solid var(--line);border-radius:999px;color:var(--muted);padding:7px 11px;font-size:11px}.coverage-pill{gap:9px;padding:8px 13px}.coverage-pill strong{color:var(--green);font-size:15px}.metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.metric-card,.panel{background:linear-gradient(145deg,#1a2639eb,#0f1827f5);border:1px solid var(--line);border-radius:13px}.metric-card{min-height:143px;padding:17px 18px 15px;position:relative;overflow:hidden}.metric-card:after{content:"";position:absolute;width:100px;height:100px;right:-45px;bottom:-50px;border-radius:50%;background:#65d6a714}.metric-card-top{display:flex;gap:9px;align-items:center}.metric-icon{width:24px;height:24px;border-radius:7px;display:grid;place-items:center;color:var(--green);background:#65d6a71a;font-size:14px}.metric-blue .metric-icon{color:var(--blue);background:#7ca7ff1a}.metric-purple .metric-icon{color:var(--purple);background:#d08dff1a}.metric-warning .metric-icon{color:var(--yellow);background:#f8c86b1a}.metric-value{margin-top:21px;font-size:27px;font-weight:700;letter-spacing:-.04em}.metric-detail{color:var(--muted);font-size:11px;margin-top:5px}.quote-strip{display:flex;align-items:center;gap:9px;color:var(--muted);font-size:11px;border:1px solid var(--line);border-radius:9px;padding:9px 12px;background:#65d6a709}.quote-strip strong{color:var(--ink);font-size:12px}.quote-strip button{margin-left:auto;border:0;background:transparent;color:#a8bff3;font-size:11px}.warning-stack{display:grid;gap:8px}.warning-card{display:flex;gap:10px;align-items:flex-start;border:1px solid var(--line);border-radius:10px;padding:11px 13px;background:#f8c86b0b}.warning-card strong{font-size:12px}.warning-card p{margin-top:2px;color:var(--muted);font-size:12px}.warning-mark{flex:0 0 19px;width:19px;height:19px;border-radius:50%;display:grid;place-items:center;color:var(--yellow);background:#f8c86b21;font-weight:800;font-size:11px}.warning-critical{border-color:#ff887d33;background:#ff887d0b}.warning-critical .warning-mark{color:var(--red);background:#ff887d21}.warning-info{border-color:#7ca7ff33;background:#7ca7ff0b}.warning-info .warning-mark{color:var(--blue);background:#7ca7ff21}.chart-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.chart-panel{padding:19px;min-height:310px}.panel-heading,.table-toolbar,.detail-heading,.settings-heading{display:flex;justify-content:space-between;gap:15px;align-items:flex-start}.panel-heading p,.settings-heading p,.detail-heading p{color:var(--muted);font-size:12px;margin-top:4px}.chart-note{color:var(--faint);font-size:10px;border:1px solid var(--line);padding:4px 7px;border-radius:5px}.chart-list{margin-top:21px;display:grid;gap:12px}.chart-row-head{display:flex;align-items:center;gap:7px;font-size:12px}.legend-dot{width:7px;height:7px;border-radius:2px;flex:0 0 7px}.chart-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.chart-value{margin-left:auto;color:var(--ink);font-weight:700}.chart-track{height:5px;margin-top:7px;background:#ffffff0f;border-radius:5px;overflow:hidden}.chart-track span{display:block;height:100%;min-width:3px;border-radius:inherit}.chart-meta{display:flex;gap:7px;color:var(--faint);font-size:10px;margin-top:4px}.chart-meta strong{margin-left:auto;color:var(--muted);font-weight:600}.empty-chart{min-height:210px;display:grid;place-items:center;color:var(--muted)}.insight-row{display:grid;grid-template-columns:1fr 1fr;gap:14px}.insight-card{display:flex;gap:12px;padding:16px}.insight-icon{width:29px;height:29px;border-radius:9px;flex:0 0 29px;display:grid;place-items:center;color:var(--green);background:#65d6a71a}.insight-card strong{display:block;margin-top:3px}.insight-card p{color:var(--muted);font-size:11px;margin:4px 0 9px}.page-footnote{display:flex;align-items:center;gap:8px;color:var(--faint);font-size:11px}.table-panel{overflow:hidden}.table-toolbar{padding:17px 19px;align-items:center;border-bottom:1px solid var(--line)}.table-toolbar strong{display:block}.table-toolbar span{display:block;color:var(--muted);font-size:11px;margin-top:3px}.table-toolbar-note{color:var(--faint)!important;margin-top:0!important;text-align:right}.table-shell{overflow-x:auto}.table-shell table{width:100%;border-collapse:collapse;font-size:12px;min-width:1100px}.table-shell th{color:var(--faint);text-transform:uppercase;letter-spacing:.09em;font-size:9px;font-weight:700;text-align:left;padding:11px 14px;background:#070e1940;white-space:nowrap}.table-shell td{border-top:1px solid rgba(155,177,212,.09);padding:13px 14px;color:var(--muted);vertical-align:middle;white-space:nowrap}.table-shell tbody tr{transition:background .12s ease}.table-shell tbody tr:hover,.table-shell tbody tr.row-selected{background:#7ca7ff0e}.numeric{text-align:right!important}.ticker-cell{color:var(--ink);letter-spacing:.025em}.name-cell{color:#b8c5d8;max-width:185px;display:inline-block;overflow:hidden;text-overflow:ellipsis;vertical-align:bottom}.account-cell{display:inline-flex;gap:7px;align-items:center;color:#b8c5d8}.account-avatar{display:inline-grid;place-items:center;width:22px;height:22px;border-radius:7px;background:#263550;color:#a9c3f5;font-size:10px;font-weight:700}.type-label,.currency-label{color:#9eafd0;text-transform:capitalize}.value-strong{color:var(--ink)!important;font-weight:600}.date-cell{color:var(--faint);font-size:11px}.status-badge{display:inline-flex;border-radius:999px;padding:4px 7px;text-transform:capitalize;color:var(--muted);background:#9bb1d41a;font-size:10px;line-height:1;white-space:nowrap}.status-good,.status-valued,.status-fresh,.status-accepted{color:var(--green);background:#65d6a71a}.status-warning,.status-stale,.status-residual,.status-missing{color:var(--yellow);background:#f8c86b1a}.status-critical,.status-unsupported-currency,.status-unsupported-position,.status-rejected,.status-invalid{color:var(--red);background:#ff887d1a}.status-normalized{color:var(--blue);background:#7ca7ff1a}.row-actions{display:flex;gap:5px}.row-actions .button{padding:5px 7px;font-size:11px}.source-button{border:0;background:transparent;color:#a8bff3;padding:0;display:inline-flex;gap:6px;align-items:center}.source-count{display:grid;place-items:center;width:20px;height:20px;border-radius:6px;background:#7ca7ff1f;color:var(--blue);font-size:10px}.table-subtext{display:block;max-width:160px;overflow:hidden;text-overflow:ellipsis;color:var(--faint);font-size:10px;margin-top:2px}.xray-summary{display:grid;grid-template-columns:1fr 1fr;gap:12px}.xray-summary>div{border:1px solid var(--line);border-radius:10px;padding:14px 16px;background:#65d6a709}.xray-summary strong{display:block;margin-top:4px;font-size:20px;letter-spacing:-.03em}.xray-summary span:last-child{display:block;color:var(--muted);font-size:11px;margin-top:2px}.source-drawer{padding:20px}.drawer-head{display:flex;justify-content:space-between;align-items:flex-start;padding-bottom:16px;border-bottom:1px solid var(--line)}.drawer-head h2{margin-top:3px}.drawer-head strong{display:block;margin-top:4px;font-size:22px;color:var(--green)}.source-columns{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;padding-top:18px}.source-group{display:grid;gap:8px;align-content:start}.source-line{display:flex;justify-content:space-between;gap:10px;color:var(--muted);font-size:12px;border-bottom:1px dashed var(--line);padding-bottom:7px}.source-line strong{color:var(--ink);font-weight:600}.etf-workspace{display:grid;grid-template-columns:1fr 1fr;gap:14px}.etf-detail-card,.csv-card{padding:19px;min-width:0}.detail-heading h2{margin-top:4px}.detail-heading h2 span{color:var(--muted);font-weight:400;font-size:13px}.snapshot-meta{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;padding:16px 0;margin-top:14px;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}.snapshot-meta strong{display:block;font-size:12px;margin-top:3px;color:#c3d0e2}.missing-inline{display:flex;gap:9px;align-items:center;margin-top:19px;padding:10px;border-radius:8px;background:#f8c86b0e;color:var(--muted);font-size:12px}.underlying-preview{padding-top:16px}.mini-constituents{display:grid;gap:5px;margin-top:9px}.mini-constituents>div{display:grid;grid-template-columns:48px minmax(0,1fr) 43px;gap:7px;align-items:center;padding:5px 0;border-bottom:1px solid rgba(155,177,212,.08);font-size:11px}.mini-constituents span{color:#a8bff3}.mini-constituents strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--muted);font-weight:500}.mini-constituents em{text-align:right;color:var(--ink);font-style:normal}.file-button{display:inline-flex;align-items:center;border:1px solid var(--line-strong);color:#a8bff3;background:var(--surface-3);border-radius:8px;padding:8px 11px;cursor:pointer;font-size:11px}.file-button input{display:none}.csv-card textarea{resize:vertical;width:100%;margin-top:17px;padding:12px;min-height:162px;color:#c6d5eb;background:#0c1421;border:1px solid var(--line-strong);border-radius:8px;outline:0;font:12px/1.55 ui-monospace,SFMono-Regular,Menlo,monospace}.csv-card textarea:focus{border-color:#7ca7ffb3;box-shadow:0 0 0 3px #7ca7ff14}.form-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:12px}.csv-preview{margin-top:16px;padding-top:15px;border-top:1px solid var(--line)}.preview-summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.preview-summary strong{display:block;color:var(--ink);font-size:14px;margin-top:3px}.preview-error,.preview-warning,.preview-note{border-radius:7px;padding:8px 10px;margin-top:10px!important;font-size:11px}.preview-error{color:var(--red);background:#ff887d12}.preview-warning{color:var(--yellow);background:#f8c86b12}.preview-note{color:var(--green);background:#65d6a712}.preview-table{overflow-x:auto;margin-top:12px;max-height:240px}.preview-table table{width:100%;border-collapse:collapse;font-size:11px}.preview-table th{color:var(--faint);text-align:left;font-size:9px;text-transform:uppercase;padding:7px 5px}.preview-table td{border-top:1px solid var(--line);padding:7px 5px;color:var(--muted);white-space:nowrap}.inline-message{color:var(--green);border:1px solid rgba(101,214,167,.2);background:#65d6a70f;border-radius:8px;padding:9px 11px;font-size:12px}.settings-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.settings-card{padding:19px;min-width:0}.settings-heading{align-items:flex-start}.settings-heading>div:last-child{flex:1}.settings-icon{width:29px;height:29px;border-radius:8px;display:grid;place-items:center;flex:0 0 29px;color:var(--blue);background:#7ca7ff1c}.account-select-list{display:grid;gap:6px;margin-top:17px}.account-select{display:flex;align-items:center;gap:9px;padding:9px;border:1px solid var(--line);border-radius:8px;cursor:pointer}.account-select:hover{border-color:var(--line-strong);background:#ffffff05}.account-select input{accent-color:var(--green)}.account-select>span:nth-of-type(2){display:grid}.account-select strong{font-size:12px}.account-select em{color:var(--faint);font-size:10px;font-style:normal;margin-top:1px}.checkmark{margin-left:auto;color:var(--green);opacity:0}.account-select input:checked~.checkmark{opacity:1}.privacy-note{display:flex;gap:10px;align-items:flex-start;margin-top:20px;padding:11px;border-radius:8px;border:1px solid rgba(101,214,167,.16);background:#65d6a70b}.privacy-note p{color:var(--muted);font-size:11px;margin-top:3px}.toggle-row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:19px;color:#b9c6d9;font-size:12px}.toggle{width:36px;height:20px;padding:2px;border-radius:999px;border:0;background:#324158;text-align:left}.toggle span{width:16px;height:16px;display:block;border-radius:50%;background:#8b98aa;transition:.15s ease}.toggle-on{background:#65d6a773}.toggle-on span{transform:translate(16px);background:var(--green)}.secret-field{margin-top:17px}.secret-field label{display:flex;justify-content:space-between;color:#b8c5d8;font-size:11px}.secret-status{color:var(--faint);font-size:10px}.secret-set{color:var(--green)}.secret-input-row{display:flex;gap:6px;margin-top:6px}.secret-input-row input{min-width:0;flex:1;color:var(--ink);background:#0c1421;border:1px solid var(--line-strong);border-radius:7px;padding:8px 9px;outline:0}.secret-input-row input:focus{border-color:#7ca7ffb3}.secret-input-row .button{padding:7px 9px;font-size:11px}.provider-list,.override-list{display:grid;gap:7px;margin-top:17px}.provider-row,.override-row{display:flex;align-items:center;gap:7px;padding:9px;border:1px solid var(--line);border-radius:8px}.provider-row>div:first-child,.override-row>div:first-child{min-width:0;margin-right:auto;display:grid}.provider-row strong,.override-row strong{font-size:12px}.provider-row span,.override-row span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:var(--faint);font-size:10px}.provider-row select,.override-row select{color:#c2d0e4;background:var(--surface-3);border:1px solid var(--line-strong);border-radius:6px;padding:6px;font-size:11px}.provider-identity{width:82px;min-width:0;color:#c2d0e4;background:#0c1421;border:1px solid var(--line-strong);border-radius:6px;padding:6px;font-size:10px}.alias-form{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:17px}.alias-form input{min-width:0;color:var(--ink);background:#0c1421;border:1px solid var(--line-strong);border-radius:7px;padding:8px 9px;outline:0;font-size:11px}.alias-form .button{grid-column:1 / -1;justify-self:end}.alias-list{display:grid;gap:6px;margin-top:12px}.alias-row{display:flex;align-items:center;gap:7px;min-width:0;padding:8px;border:1px solid var(--line);border-radius:7px;color:var(--muted);font-size:10px}.alias-row span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.alias-row strong{color:var(--ink);white-space:nowrap}.alias-row button{margin-left:auto;border:0;background:transparent;color:var(--red);font-size:10px}.settings-footer{color:var(--faint);display:flex;gap:8px;align-items:center;font-size:11px}.empty-state,.loading-state,.error-state{min-height:380px;display:grid;place-items:center;align-content:center;text-align:center;border:1px dashed var(--line-strong);border-radius:13px;padding:30px}.empty-icon{width:52px;height:52px;display:grid;place-items:center;border-radius:16px;color:var(--green);background:#65d6a71a;font-size:26px;margin-bottom:14px}.empty-state h2,.loading-state h2,.error-state h2{font-size:18px}.empty-state p,.loading-state p,.error-state p{max-width:420px;color:var(--muted);margin:7px 0 16px}.loading-orbit{width:52px;height:52px;display:grid;place-items:center;color:#082018;background:var(--green);border-radius:16px;font-weight:800;animation:orbit 1.35s ease-in-out infinite;margin-bottom:15px}@keyframes orbit{0%,to{transform:translateY(0) rotate(-5deg)}50%{transform:translateY(-5px) rotate(5deg)}}.global-error{margin:0 0 -7px;color:var(--red);background:#ff887d14;border:1px solid rgba(255,136,125,.2);border-radius:8px;padding:9px 11px;font-size:12px;display:flex;gap:8px;align-items:center}.global-error span{width:17px;height:17px;display:grid;place-items:center;border-radius:50%;background:#ff887d2b}.global-error button{margin-left:auto;color:#ffb3aa;background:transparent;border:0;font-size:11px}@media(max-width:1100px){.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.etf-workspace,.settings-grid{grid-template-columns:1fr}}@media(max-width:760px){.app-shell{display:block}.sidebar{width:100%;min-height:auto;padding:14px;border-right:0;border-bottom:1px solid var(--line)}.brand{padding:0 5px 12px}.main-nav{display:flex;overflow-x:auto}.nav-item{width:auto;white-space:nowrap;padding:8px 10px}.sidebar-bottom{margin-top:8px;display:flex;align-items:center}.sidebar-bottom>.nav-item{width:auto}.account-summary,.local-first{display:none}.main-content{width:100%}.page-stack{padding:23px 16px 38px}.section-header{align-items:flex-start;flex-direction:column}.metric-grid,.chart-grid,.insight-row,.xray-summary,.source-columns{grid-template-columns:1fr}.metric-card{min-height:125px}.snapshot-meta,.preview-summary{grid-template-columns:repeat(2,1fr)}}';
function Yt(e) {
  if (e.querySelector("style[data-portfolio-xray]")) return () => {
  };
  const i = e.createElement("style");
  return i.dataset.portfolioXray = "true", i.textContent = Jt, e.head.appendChild(i), () => i.remove();
}
const en = (e) => {
  const t = Yt(e.ui.root.ownerDocument);
  return e.router.add({
    id: "portfolio-xray",
    path: "",
    component: () => /* @__PURE__ */ n(Gt, { ctx: e })
  }), { disable: t };
};
export {
  en as default,
  en as enable
};
//# sourceMappingURL=addon.js.map
